# Nextone — loyiha xotirasi (yangi sessiyada AVVAL shuni o'qing)

Foydalanuvchi: faqat Android telefon, bepul Claude rejasi (limit tez tugaydi), o'zbekcha, qisqa javob, hammasini bir yo'la qilishni xohlaydi.
Reklama postlari INGLIZ tilida, "Discord" so'zini ISHLATMANG. Yangilanish rasmi har safar bir xil: /home/claude/nextone_update_fixed.png (yo'qolsa PIL bilan qayta chizing: Nextone ikonka, "NEXTONE", "NEW UPDATE", "Open the app and tap Update", t.me/nextoneapp).
Yetkazish: zip -> SendUserFile; foydalanuvchi GitHub'ga yuklaydi (eski nextone.zip o'chirib), Actions yashil -> ilovada "Yangilash".

## Identifikatorlar
- Supabase project: wgufjdcopzeeskezrwup (anon kalit lib/supabase_config.dart). Admin uid: 6dd1cb07-2694-4b7f-806b-071abfd79bb2 (Behruz). Rasmiy server: 8c070154-ddf2-4f01-a804-bb97c1c712e5 ("Nextone | Community Platform", egasi Behruz)
- GitHub repo retwobehruz/nextone (public), Telegram kanal t.me/nextoneapp
- Firebase project nextone-1ca7e, Android package com.nextone.nextone, google-services.json zip ichida (repo ildizida). Push: Supabase edge function `push` + secret FCM_SERVICE_ACCOUNT (foydalanuvchi qo'yadi), trigger messages_push (pg_net), jadval device_tokens, rpc register_device.
- Edge function sms-webhook (eskirgan, avto-to'lov bekor qilingan) qoldi, zararsiz.

## Qilingan
Google kirish, serverlar/kanallar/rollar/xabarlar/reaksiya/pin/tahrir, DM, taklif kodi (server), Plus(6600)/Prime(12000) qo'lda admin tasdiqlashi bilan (payment_requests, approve_payment), karta ma'lumoti app_settings jadvalida, in-app yangilash banneri, username + username bo'yicha qidirish (DM bo'limi), Aurora dizayn + pastki navigatsiya, rasm yuborish (chat-images), profil rasmi (avatars), server rasmi/tavsifi (server-icons, faqat ega), push (kod tayyor), Plus/Prime avatar ramkalari.
CI: ci/build.sh (flutter create, manifest, lint o'chirilgan init.gradle, google-services patch).

Yangilanish #N (taklif/do'stlar): do'stlar (friendships, rpc friend_request/respond/remove, screens/friends_screen.dart), bloklash+shikoyat (blocks, reports, messages_block_guard), rasmiy serverga avto-qo'shilish (trigger profiles_join_official, app_settings.official_server), onboarding (profiles.onboarded), TAKLIF tizimi (profiles.ref_code/referred_by, referrals, rpc claim_referral: taklif qiluvchiga +3 kun Plus, 30 taklifdan keyin mukofot yo'q, kod faqat 7 kundan yosh akkauntlar uchun; screens/referral_screen.dart). Ilovada xabarga javob (reply) allaqachon bor edi.

Yangilanish (katalog/fayl/havola): server katalogi (servers.is_public, rpc public_servers, screens/catalog_screen.dart), fayl yuborish (file_picker, bucket chat-files, messages.file_url/file_name/file_size), server havolasi nextone://join/KOD (app_links, ci/build.sh manifest) + sayt /home/claude/site (index.html landing, join.html) -> foydalanuvchi 'media' repo'ga yuklab GitHub Pages yoqadi: https://retwobehruz.github.io/media/join.html?c=KOD.
KEYINGI: ovozli xabar (record + audioplayers paketlari; build xavfi sababli alohida yangilanishda), yengil mavzu, xabar qidirish, Google Play, haqiqiy ovozli kanallar.

## Muhim texnik eslatmalar
- UI'da joriy foydalanuvchi har doim 'me' kaliti; _k(uid)/_u(key). DM kaliti 'dm_<uid>'.
- Uzbekcha matn kalit; kEn/kRu'ga yangi kalit qo'shing (mavjudini qaytarmang: dublikat const map xatosi beradi).
- Storage bucket'larda SELECT policy kerak (aks holda upload 403).
- profiles_guard plan/is_admin ni client'dan o'zgartirishni bloklaydi; SECURITY DEFINER ichida set_config('nextone.bypass','1',true).
- Kompilyator yo'q: faqat qavs tekshiruvi; build GitHub'da.

## Reja (foydalanuvchi tasdiqlagan)
1) Do'stlar ro'yxati, bloklash+shikoyat, rasmiy serverga avto-qo'shilish, onboarding, TAKLIF TIZIMI (har taklif qilingan do'st uchun taklif qiluvchiga 3 kun Plus).
2) Keyin: server katalogi, fayl/ovozli xabar, yengil mavzu, xabar qidiruvi, ulashish, landing sahifa, Google Play, haqiqiy ovozli kanallar.
Maqsad: professional daraja, kuniga 1000+ yuklash (asosiy to'siq: APK, Google Play kerak).


Yangilanish (ovozli xabar): record ^6 + audioplayers ^6; xabar fayl sifatida (chat-files, file_name='voice_<soniya>.m4a'), widgets/voice.dart VoiceBubble, chat_page mikrofon tugmasi (matn bo'sh bo'lsa), RECORD_AUDIO manifest (ci/build.sh). DB o'zgarishsiz. Build natijasi kutilmoqda.

Yangilanish (qidiruv/yozmoqda/forward/ulashish): state.searchMessages (messages.ilike), typingStart/Stop/Ping/typingNames (realtime broadcast kanal 'typing-<kanal>' / 'typing-dm-<id>-<id>'), chat_page: showChatSearch, showForwardPicker, "Ulashish" (t.me/share/url), chat_area: qidiruv tugmasi. Onlayn holat avvaldan bor (presence-global). Yangi paket yo'q. Build natijasi kutilmoqda (ovozli xabar build'i ham).
