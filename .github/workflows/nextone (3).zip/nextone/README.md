# Nextone

A Discord-like messaging app for people from all countries, built with Flutter / Dart.
Multilingual from the start. **English** and **Uzbek** are the main languages; Russian is included too.

## Languages

- The language follows the device language; if it isn't supported, the app starts in English.
- You can switch it any time on the sign-in screen or in Profile → Language.
- All translations live in `lib/l10n_strings.dart`. Code uses Uzbek text as the key, other languages are looked up in tables (`kEn`, `kRu`).
- **Add a language:** add a new table (e.g. `kTr`) to `l10n_strings.dart`, then register it in `L10n.names` and `L10n.tables` in `lib/l10n.dart`. Missing strings fall back to the Uzbek text.
- Language choice is not saved between launches yet (comes with the account system).

## Current state (v0.1, demo data)

- **Servers**: create, delete / leave, unread badges
- **Channels**: text, voice, announcement; categories; create and delete (long-press)
- **Chat**: send, reply, reactions, edit, delete, pin, emoji, day separators
- **Roles**: create, color, permissions, reorder (drag), assign to members; permissions are enforced (who can create channels, post, delete messages)
- **Bots**: NextBot, MusicBot, ModBot; add/remove from the catalog; `/commands` (`/help`, `/ping`, `/roll`, `/coin`, `/8ball`, `/time`, `/play`, `/clear`, ...) with suggestions
- **Profile**: name, status, bio, avatar and banner color; other members' profiles; direct messages
- **Voice channel**: interface only (join, mic, headphones, camera, disconnect)
- Wide screens get a 4-column layout; phones get drawers

## Run

Needs the Flutter SDK (3.22+ recommended): https://docs.flutter.dev/get-started/install

```bash
cd nextone
flutter create --platforms=android,ios,web .   # generates platform folders (keeps lib/ and pubspec.yaml)
flutter pub get
flutter run
```

Note: `flutter create .` can overwrite `lib/main.dart`. If that happens, restore the one from this project.

## Next steps

1. Firebase Auth + Firestore: real accounts and real-time messages (and saved language)
2. Images and files (Firebase Storage)
3. Voice channels (LiveKit or Agora)
4. Push notifications
5. External API for bots
6. More languages (Turkish, Arabic, Spanish, ...)

## Structure

```
lib/
  main.dart            app entry
  state.dart           AppState: all app state and logic
  models.dart          Server, Channel, Role, Member, Message ...
  mock_data.dart       demo data
  bots.dart            bot catalog
  l10n.dart            language system (tr, trf, L10n)
  l10n_strings.dart    translation tables
  theme.dart, util.dart
  screens/             sign-in, home, profile, roles, bots
  widgets/             server rail, channels, chat, members, voice, tr_text (translating Text)
assets/icon.png        app icon
```

---

## O'zbekcha qisqacha

Nextone: butun dunyo uchun Discord'ga o'xshash ilova. Til qurilma tiliga qarab tanlanadi (topilmasa ingliz tili), kirish ekrani yoki Profil bo'limida o'zgartiriladi. Yangi til qo'shish uchun `lib/l10n_strings.dart` ga yangi jadval qo'shib, `lib/l10n.dart` da ro'yxatdan o'tkazing. Ishga tushirish yo'riqnomasi yuqorida.
