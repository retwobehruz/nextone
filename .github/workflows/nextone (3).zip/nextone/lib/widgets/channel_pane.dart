import 'package:flutter/material.dart' hide Text;
import 'tr_text.dart';

import '../models.dart';
import '../screens/bots_screen.dart';
import '../screens/profile_screen.dart';
import '../screens/roles_screen.dart';
import '../state.dart';
import '../theme.dart';
import 'common.dart';

/// Kanallar (yoki bosh sahifada suhbatlar) paneli + pastdagi foydalanuvchi paneli.
class ChannelPane extends StatelessWidget {
  const ChannelPane({super.key, this.onNavigate});

  final VoidCallback? onNavigate;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final server = s.server;

    return Container(
      color: NX.side,
      child: SafeArea(
        child: Column(
          children: [
            if (server == null)
              const _PaneHeader(title: 'Xabarlar')
            else
              InkWell(
                onTap: () => _showServerMenu(context, server),
                child: _PaneHeader(title: server.name, dropdown: true),
              ),
            Expanded(
              child: server == null
                  ? _DmList(onNavigate: onNavigate)
                  : _ChannelList(server: server, onNavigate: onNavigate),
            ),
            if (s.voiceChannelId != null) const _VoiceStrip(),
            const UserPanel(),
          ],
        ),
      ),
    );
  }
}

class _PaneHeader extends StatelessWidget {
  const _PaneHeader({required this.title, this.dropdown = false});
  final String title;
  final bool dropdown;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 52,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.black.withAlpha(70))),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
            ),
          ),
          if (dropdown) const Icon(Icons.keyboard_arrow_down_rounded, size: 22),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- DM ro'yxati

class _DmList extends StatelessWidget {
  const _DmList({this.onNavigate});
  final VoidCallback? onNavigate;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return ListView(
      padding: const EdgeInsets.symmetric(vertical: 8),
      children: [
        const SectionLabel(
          'TO\'G\'RIDAN-TO\'G\'RI XABARLAR',
          padding: EdgeInsets.fromLTRB(16, 8, 16, 6),
        ),
        for (final id in s.dmIds) _DmTile(memberId: id, onNavigate: onNavigate),
        if (s.dmIds.isEmpty)
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              "Hozircha suhbat yo'q. A'zo profilidan «Xabar yozish» ni bosing.",
              style: TextStyle(color: NX.dim),
            ),
          ),
      ],
    );
  }
}

class _DmTile extends StatelessWidget {
  const _DmTile({required this.memberId, this.onNavigate});
  final String memberId;
  final VoidCallback? onNavigate;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final m = s.member(memberId);
    final selected = s.dmId == memberId && s.serverId == null;
    final unread = s.unread['dm_$memberId'] ?? 0;
    return InkWell(
      onTap: () {
        s.openDm(memberId);
        onNavigate?.call();
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 1),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? NX.raised : null,
          borderRadius: BorderRadius.circular(6),
        ),
        child: Row(
          children: [
            Avatar(member: m, size: 34, showStatus: true),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          m.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: selected || unread > 0 ? NX.text : NX.muted,
                          ),
                        ),
                      ),
                      if (m.isBot) ...[
                        const SizedBox(width: 6),
                        const BotTag(),
                      ],
                    ],
                  ),
                  if (m.customStatus.isNotEmpty)
                    Text(
                      m.customStatus,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: NX.dim, fontSize: 12),
                    ),
                ],
              ),
            ),
            if (unread > 0) UnreadBadge(unread),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------- Kanallar ro'yxati

class _ChannelList extends StatelessWidget {
  const _ChannelList({required this.server, this.onNavigate});
  final Server server;
  final VoidCallback? onNavigate;

  @override
  Widget build(BuildContext context) {
    final canManage = server.can('me', Permission.manageChannels);
    return ListView(
      padding: const EdgeInsets.only(bottom: 8),
      children: [
        for (final cat in server.categories) ...[
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 8, 4),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    cat.name,
                    style: const TextStyle(
                      color: NX.dim,
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
                if (canManage)
                  InkWell(
                    onTap: () => showCreateChannel(context, server, category: cat),
                    borderRadius: BorderRadius.circular(12),
                    child: const Padding(
                      padding: EdgeInsets.all(4),
                      child: Icon(Icons.add_rounded, size: 18, color: NX.dim),
                    ),
                  ),
              ],
            ),
          ),
          for (final ch in cat.channels)
            _ChannelTile(
              server: server,
              channel: ch,
              canManage: canManage,
              onNavigate: onNavigate,
            ),
        ],
        if (server.categories.isEmpty)
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('Kanallar yo\'q', style: TextStyle(color: NX.dim)),
          ),
      ],
    );
  }
}

IconData _iconFor(ChannelType t) {
  switch (t) {
    case ChannelType.text:
      return Icons.tag;
    case ChannelType.voice:
      return Icons.volume_up_rounded;
    case ChannelType.announcement:
      return Icons.campaign_rounded;
  }
}

class _ChannelTile extends StatelessWidget {
  const _ChannelTile({
    required this.server,
    required this.channel,
    required this.canManage,
    this.onNavigate,
  });

  final Server server;
  final Channel channel;
  final bool canManage;
  final VoidCallback? onNavigate;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final selected = s.channelId == channel.id && s.dmId == null;
    final unread = s.unread[channel.id] ?? 0;
    final isVoice = channel.type == ChannelType.voice;
    final inVoice = s.voiceChannelId == channel.id;
    final participants = (s.voice[channel.id] ?? <String>{}).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        InkWell(
          onTap: () {
            if (isVoice) {
              s.joinVoice(channel.id);
            } else {
              s.selectChannel(channel.id);
            }
            onNavigate?.call();
          },
          onLongPress: canManage ? () => _channelMenu(context, s) : null,
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 1),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
            decoration: BoxDecoration(
              color: selected ? NX.raised : null,
              borderRadius: BorderRadius.circular(6),
            ),
            child: Row(
              children: [
                Icon(
                  _iconFor(channel.type),
                  size: 20,
                  color: inVoice
                      ? NX.green
                      : (selected || unread > 0 ? NX.text : NX.dim),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    channel.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: unread > 0 ? FontWeight.w800 : FontWeight.w500,
                      color: selected || unread > 0 ? NX.text : NX.muted,
                    ),
                  ),
                ),
                if (unread > 0) UnreadBadge(unread),
              ],
            ),
          ),
        ),
        if (isVoice)
          for (final id in participants)
            Padding(
              padding: const EdgeInsets.fromLTRB(40, 2, 12, 2),
              child: Row(
                children: [
                  Avatar(member: s.member(id), size: 22),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      s.member(id).name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: NX.muted, fontSize: 13),
                    ),
                  ),
                  if (id == 'me' && (s.micMuted || s.deafened))
                    const Icon(Icons.mic_off_rounded, size: 14, color: NX.dim),
                ],
              ),
            ),
      ],
    );
  }

  void _channelMenu(BuildContext context, AppState s) {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.delete_outline_rounded, color: NX.red),
              title: Text(
                trf('«{name}» kanalini o\'chirish', {'name': tr(channel.name)}),
                style: const TextStyle(color: NX.red),
              ),
              onTap: () async {
                Navigator.pop(ctx);
                final ok = await confirmDialog(
                  context,
                  title: "Kanalni o'chirish",
                  body: trf('«{name}» kanali va undagi xabarlar o\'chiriladi.', {'name': tr(channel.name)}),
                  action: "O'chirish",
                  danger: true,
                );
                if (ok) s.deleteChannel(server, channel);
              },
            ),
          ],
        ),
      ),
    );
  }
}

// ------------------------------------------------------ Kanal yaratish dialogi

Future<void> showCreateChannel(
  BuildContext context,
  Server server, {
  Category? category,
}) async {
  final s = AppScope.read(context);
  final c = TextEditingController();
  var type = ChannelType.text;
  await showDialog<void>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSt) => AlertDialog(
        title: const Text('Kanal yaratish'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SegmentedButton<ChannelType>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(value: ChannelType.text, label: Text('Matn')),
                ButtonSegment(value: ChannelType.voice, label: Text('Ovoz')),
                ButtonSegment(
                  value: ChannelType.announcement,
                  label: Text("E'lon"),
                ),
              ],
              selected: {type},
              onSelectionChanged: (v) => setSt(() => type = v.first),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: c,
              autofocus: true,
              decoration: InputDecoration(hintText: tr('kanal-nomi')),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Bekor qilish'),
          ),
          FilledButton(
            onPressed: () {
              final name = c.text.trim();
              if (name.isEmpty) return;
              s.createChannel(server, name, type, category: category);
              Navigator.pop(ctx);
            },
            child: const Text('Yaratish'),
          ),
        ],
      ),
    ),
  );
}

// ----------------------------------------------------------- Server menyusi

void _showServerMenu(BuildContext context, Server server) {
  final s = AppScope.read(context);
  final canChannels = server.can('me', Permission.manageChannels);
  final canRoles = server.can('me', Permission.manageRoles);
  final canBots = server.can('me', Permission.manageBots);
  final isOwner = server.ownerId == 'me';

  showModalBottomSheet<void>(
    context: context,
    builder: (ctx) => SafeArea(
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: Text(
                server.name,
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18),
              ),
              subtitle: Text(server.description),
            ),
            const Divider(height: 1),
            if (canChannels)
              ListTile(
                leading: const Icon(Icons.add_circle_outline_rounded),
                title: const Text('Kanal yaratish'),
                onTap: () {
                  Navigator.pop(ctx);
                  showCreateChannel(context, server);
                },
              ),
            if (canRoles)
              ListTile(
                leading: const Icon(Icons.shield_outlined),
                title: const Text('Rollar'),
                onTap: () {
                  Navigator.pop(ctx);
                  Navigator.push(
                    context,
                    MaterialPageRoute<void>(
                      builder: (_) => RolesScreen(serverId: server.id),
                    ),
                  );
                },
              ),
            if (canBots)
              ListTile(
                leading: const Icon(Icons.smart_toy_outlined),
                title: const Text('Botlar'),
                onTap: () {
                  Navigator.pop(ctx);
                  Navigator.push(
                    context,
                    MaterialPageRoute<void>(
                      builder: (_) => BotsScreen(serverId: server.id),
                    ),
                  );
                },
              ),
            ListTile(
              leading: const Icon(Icons.info_outline_rounded),
              title: const Text('Server haqida'),
              onTap: () {
                Navigator.pop(ctx);
                showDialog<void>(
                  context: context,
                  builder: (dctx) => AlertDialog(
                    title: Text(server.name),
                    content: Text([
                      tr(server.description),
                      '',
                      trf('A\'zolar: {n}', {'n': server.memberRoles.length}),
                      trf('Kanallar: {n}', {'n': server.allChannels.length}),
                      trf('Rollar: {n}', {'n': server.roles.length - 1}),
                      trf('Egasi: {name}', {'name': s.member(server.ownerId).name}),
                    ].join('\n')),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(dctx),
                        child: const Text('Yopish'),
                      ),
                    ],
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.logout_rounded, color: NX.red),
              title: Text(
                isOwner ? "Serverni o'chirish" : 'Serverni tark etish',
                style: const TextStyle(color: NX.red),
              ),
              onTap: () async {
                Navigator.pop(ctx);
                final ok = await confirmDialog(
                  context,
                  title: isOwner ? "Serverni o'chirish" : 'Serverni tark etish',
                  body: isOwner
                      ? trf('«{name}» serveri butunlay o\'chiriladi.', {'name': server.name})
                      : trf('«{name}» serveridan chiqasiz.', {'name': server.name}),
                  action: isOwner ? "O'chirish" : 'Tark etish',
                  danger: true,
                );
                if (ok) s.removeServer(server);
              },
            ),
          ],
        ),
      ),
    ),
  );
}

// ---------------------------------------------------- Ovozli ulanish chizig'i

class _VoiceStrip extends StatelessWidget {
  const _VoiceStrip();

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    String name = 'Ovozli kanal';
    final sv = s.server;
    if (sv != null) {
      for (final ch in sv.allChannels) {
        if (ch.id == s.voiceChannelId) name = ch.name;
      }
    }
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 8, 8),
      decoration: const BoxDecoration(
        color: NX.panel,
        border: Border(bottom: BorderSide(color: NX.divider)),
      ),
      child: Row(
        children: [
          const Icon(Icons.graphic_eq_rounded, color: NX.green, size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Ovozli ulangan',
                  style: TextStyle(
                    color: NX.green,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                ),
                Text(
                  name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: NX.muted, fontSize: 12),
                ),
              ],
            ),
          ),
          IconButton(
            tooltip: tr('Uzilish'),
            icon: const Icon(Icons.call_end_rounded, color: NX.red),
            onPressed: s.leaveVoice,
          ),
        ],
      ),
    );
  }
}

// ----------------------------------------------------------- Foydalanuvchi paneli

class UserPanel extends StatelessWidget {
  const UserPanel({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final me = s.me;
    void openProfile() => Navigator.push(
          context,
          MaterialPageRoute<void>(builder: (_) => const ProfileScreen()),
        );

    return Container(
      color: NX.panel,
      padding: const EdgeInsets.fromLTRB(8, 8, 4, 8),
      child: Row(
        children: [
          Expanded(
            child: InkWell(
              onTap: openProfile,
              borderRadius: BorderRadius.circular(6),
              child: Row(
                children: [
                  Avatar(
                    member: me,
                    size: 34,
                    showStatus: true,
                    ringColor: NX.panel,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          me.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 14,
                          ),
                        ),
                        Text(
                          me.customStatus.isEmpty
                              ? me.status.label
                              : me.customStatus,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: NX.dim, fontSize: 11.5),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          _PanelButton(
            icon: s.micMuted ? Icons.mic_off_rounded : Icons.mic_rounded,
            danger: s.micMuted,
            tooltip: tr('Mikrofon'),
            onTap: s.toggleMic,
          ),
          _PanelButton(
            icon: s.deafened ? Icons.headset_off_rounded : Icons.headset_rounded,
            danger: s.deafened,
            tooltip: tr('Quloqchin'),
            onTap: s.toggleDeafen,
          ),
          _PanelButton(
            icon: Icons.settings_rounded,
            tooltip: tr('Profil sozlamalari'),
            onTap: openProfile,
          ),
        ],
      ),
    );
  }
}

class _PanelButton extends StatelessWidget {
  const _PanelButton({
    required this.icon,
    required this.onTap,
    required this.tooltip,
    this.danger = false,
  });

  final IconData icon;
  final VoidCallback onTap;
  final String tooltip;
  final bool danger;

  @override
  Widget build(BuildContext context) {
    return IconButton(
      tooltip: tr(tooltip),
      onPressed: onTap,
      iconSize: 20,
      padding: EdgeInsets.zero,
      constraints: const BoxConstraints.tightFor(width: 32, height: 32),
      icon: Icon(icon, color: danger ? NX.red : NX.muted),
    );
  }
}
