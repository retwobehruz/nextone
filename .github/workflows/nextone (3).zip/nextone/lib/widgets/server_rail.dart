import 'package:flutter/material.dart' hide Text;
import 'tr_text.dart';

import '../state.dart';
import '../theme.dart';
import 'common.dart';

/// Chap tarafdagi serverlar ustuni.
class ServerRail extends StatelessWidget {
  const ServerRail({super.key, this.onNavigate});

  final VoidCallback? onNavigate;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final dmUnread =
        s.dmIds.fold<int>(0, (a, id) => a + (s.unread['dm_$id'] ?? 0));

    return Container(
      width: 72,
      color: NX.rail,
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(vertical: 12),
          children: [
            RailButton(
              label: 'Bosh sahifa',
              selected: s.serverId == null,
              badge: dmUnread,
              color: NX.accent,
              onTap: s.selectHome,
              child: Image.asset(
                'assets/icon.png',
                width: 48,
                height: 48,
                fit: BoxFit.cover,
              ),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 6, horizontal: 20),
              child: Divider(height: 2, thickness: 2),
            ),
            for (final sv in s.servers)
              RailButton(
                label: sv.name,
                selected: s.serverId == sv.id,
                badge: s.serverUnread(sv),
                color: sv.color,
                onTap: () => s.selectServer(sv.id),
                child: Text(
                  sv.initials,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 16,
                  ),
                ),
              ),
            RailButton(
              label: 'Server yaratish',
              selected: false,
              color: NX.side,
              onTap: () async {
                final name = await promptText(
                  context,
                  title: 'Server yaratish',
                  hint: 'Server nomi',
                  action: 'Yaratish',
                );
                if (name != null && name.trim().isNotEmpty) {
                  s.createServer(name.trim());
                  onNavigate?.call();
                }
              },
              child: const Icon(Icons.add_rounded, color: NX.green, size: 28),
            ),
          ],
        ),
      ),
    );
  }
}

class RailButton extends StatelessWidget {
  const RailButton({
    super.key,
    required this.label,
    required this.selected,
    required this.onTap,
    required this.child,
    this.color = NX.side,
    this.badge = 0,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;
  final Widget child;
  final Color color;
  final int badge;

  @override
  Widget build(BuildContext context) {
    final pillHeight = selected ? 36.0 : (badge > 0 ? 8.0 : 0.0);
    return Tooltip(
      message: tr(label),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: SizedBox(
          height: 48,
          child: Stack(
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  width: 4,
                  height: pillHeight,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.horizontal(
                      right: Radius.circular(4),
                    ),
                  ),
                ),
              ),
              Center(
                child: GestureDetector(
                  onTap: onTap,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 150),
                    width: 48,
                    height: 48,
                    clipBehavior: Clip.antiAlias,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: color,
                      borderRadius: BorderRadius.circular(selected ? 16 : 24),
                    ),
                    child: child,
                  ),
                ),
              ),
              if (badge > 0)
                Positioned(right: 6, bottom: 0, child: UnreadBadge(badge)),
            ],
          ),
        ),
      ),
    );
  }
}
