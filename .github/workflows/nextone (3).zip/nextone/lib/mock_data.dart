import 'package:flutter/material.dart';

import 'bots.dart';
import 'models.dart';
import 'theme.dart';

class MockData {
  MockData({
    required this.members,
    required this.servers,
    required this.messages,
    required this.dmIds,
    required this.voice,
  });

  final Map<String, Member> members;
  final List<Server> servers;
  final Map<String, List<Message>> messages;
  final List<String> dmIds;
  final Map<String, Set<String>> voice;
}

MockData buildMockData() {
  final now = DateTime.now();
  var seq = 0;

  Message m(
    String author,
    String text,
    int minsAgo, {
    Map<String, List<String>> react = const {},
    bool pinned = false,
  }) {
    final msg = Message(
      id: 'm${seq++}',
      authorId: author,
      text: text,
      time: now.subtract(Duration(minutes: minsAgo)),
    );
    msg.pinned = pinned;
    react.forEach((emoji, users) => msg.reactions[emoji] = users.toSet());
    return msg;
  }

  // ---- A'zolar ----
  final members = <String, Member>{
    'me': Member(id: 'me', name: 'Siz', color: NX.accent),
    'u1': Member(
      id: 'u1',
      name: 'Azizbek',
      color: const Color(0xFFEB459E),
      customStatus: 'Kod yozyapman 💻',
      bio: 'Flutter dasturchi. Kofe va kod 🙂',
      joined: DateTime(2026, 2, 3),
      banner: const Color(0xFFEB459E),
    ),
    'u2': Member(
      id: 'u2',
      name: 'Madina',
      color: const Color(0xFF3BA55D),
      bio: 'UI/UX dizayner va Flutter ishqibozi.',
      joined: DateTime(2026, 2, 10),
      banner: const Color(0xFF3BA55D),
    ),
    'u3': Member(
      id: 'u3',
      name: 'Jasur',
      color: const Color(0xFFFAA61A),
      status: PresenceStatus.idle,
      customStatus: 'Birozdan keyin qaytaman',
      bio: "O'yinlar va texnologiyalar haqida gaplashishni yaxshi ko'raman.",
      joined: DateTime(2026, 3, 1),
      banner: const Color(0xFFFAA61A),
    ),
    'u4': Member(
      id: 'u4',
      name: 'Dilnoza',
      color: const Color(0xFF9B59B6),
      status: PresenceStatus.dnd,
      customStatus: 'Imtihonga tayyorlanyapman',
      joined: DateTime(2026, 3, 15),
      banner: const Color(0xFF9B59B6),
    ),
    'u5': Member(
      id: 'u5',
      name: 'Sardor',
      color: const Color(0xFF1ABC9C),
      bio: 'Backend va serverlar.',
      joined: DateTime(2026, 4, 2),
      banner: const Color(0xFF1ABC9C),
    ),
    'u6': Member(
      id: 'u6',
      name: 'Malika',
      color: const Color(0xFFE67E22),
      status: PresenceStatus.offline,
      joined: DateTime(2026, 4, 20),
      banner: const Color(0xFFE67E22),
    ),
    'u7': Member(
      id: 'u7',
      name: 'Bekzod',
      color: const Color(0xFFED4245),
      customStatus: "O'ynayapman 🎮",
      joined: DateTime(2026, 5, 5),
      banner: const Color(0xFFED4245),
    ),
    'u8': Member(
      id: 'u8',
      name: 'Nilufar',
      color: const Color(0xFF3B82F6),
      status: PresenceStatus.offline,
      joined: DateTime(2026, 5, 18),
      banner: const Color(0xFF3B82F6),
    ),
  };
  for (final b in botCatalog) {
    members[b.id] = b.toMember();
  }

  // ---- 1-server: Nextone HQ (egasi: siz) ----
  final s1 = Server(
    id: 's1',
    name: 'Nextone HQ',
    color: NX.accent,
    ownerId: 'me',
    description: 'Nextone jamoasining rasmiy serveri.',
    roles: [
      Role(
        id: 'admin',
        name: 'Admin',
        color: NX.red,
        hoist: true,
        permissions: {Permission.admin},
      ),
      Role(
        id: 'mod',
        name: 'Moderator',
        color: NX.green,
        hoist: true,
        permissions: {Permission.sendMessages, Permission.manageMessages},
      ),
      Role(
        id: 'dev',
        name: 'Dasturchi',
        color: const Color(0xFF3B82F6),
        hoist: true,
        permissions: {Permission.sendMessages},
      ),
      Role(
        id: 'everyone',
        name: '@everyone',
        color: NX.muted,
        permissions: {Permission.sendMessages},
      ),
    ],
    categories: [
      Category(id: 's1c1', name: 'MATN KANALLARI', channels: [
        Channel(id: 'c1', name: 'umumiy', topic: "Hamma uchun umumiy suhbat"),
        Channel(
          id: 'c2',
          name: "e'lonlar",
          type: ChannelType.announcement,
          topic: 'Yangiliklar va muhim xabarlar',
        ),
        Channel(id: 'c3', name: 'dasturlash', topic: 'Kod, Dart va Flutter'),
        Channel(id: 'c4', name: 'memlar', topic: 'Kulgi vaqti 😂'),
      ]),
      Category(id: 's1c2', name: 'OVOZLI KANALLAR', channels: [
        Channel(id: 'v1', name: 'Umumiy ovoz', type: ChannelType.voice),
        Channel(id: 'v2', name: "O'yin xonasi", type: ChannelType.voice),
      ]),
    ],
  );
  s1.memberRoles.addAll({
    'me': {'admin'},
    'u1': {'mod'},
    'u2': {'dev'},
    'u3': {'dev'},
    'u4': <String>{},
    'u5': <String>{},
    'u6': <String>{},
    'bot_nextbot': <String>{},
    'bot_music': <String>{},
  });

  // ---- 2-server: Gaming Uz (siz oddiy a'zosiz) ----
  final s2 = Server(
    id: 's2',
    name: 'Gaming Uz',
    color: NX.red,
    ownerId: 'u3',
    description: "O'zbek gamerlar jamoasi.",
    roles: [
      Role(
        id: 'g_admin',
        name: 'Admin',
        color: NX.red,
        hoist: true,
        permissions: {Permission.admin},
      ),
      Role(
        id: 'g_vip',
        name: 'VIP',
        color: NX.gold,
        hoist: true,
        permissions: {Permission.sendMessages},
      ),
      Role(
        id: 'everyone',
        name: '@everyone',
        color: NX.muted,
        permissions: {Permission.sendMessages},
      ),
    ],
    categories: [
      Category(id: 's2c1', name: 'MATN KANALLARI', channels: [
        Channel(id: 'g1', name: 'umumiy', topic: "O'yinlar haqida suhbat"),
        Channel(id: 'g2', name: 'jamoa-qidiruv', topic: "Jamoadosh qidiring"),
        Channel(id: 'g3', name: 'kliplar', topic: "Eng zo'r lahzalar"),
      ]),
      Category(id: 's2c2', name: 'OVOZLI KANALLAR', channels: [
        Channel(id: 'gv1', name: 'Squad 1', type: ChannelType.voice),
      ]),
    ],
  );
  s2.memberRoles.addAll({
    'me': <String>{},
    'u3': {'g_admin'},
    'u5': {'g_vip'},
    'u7': <String>{},
    'u8': <String>{},
    'bot_nextbot': <String>{},
  });

  // ---- 3-server: Dasturchilar ----
  final s3 = Server(
    id: 's3',
    name: 'Dasturchilar',
    color: const Color(0xFF9B59B6),
    ownerId: 'u2',
    description: "Dasturchilar uchun ta'lim va yordam.",
    roles: [
      Role(
        id: 'd_admin',
        name: 'Admin',
        color: NX.red,
        hoist: true,
        permissions: {Permission.admin},
      ),
      Role(
        id: 'd_flutter',
        name: 'Flutter',
        color: const Color(0xFF3B82F6),
        hoist: true,
        permissions: {Permission.sendMessages},
      ),
      Role(
        id: 'everyone',
        name: '@everyone',
        color: NX.muted,
        permissions: {Permission.sendMessages},
      ),
    ],
    categories: [
      Category(id: 's3c1', name: 'MATN KANALLARI', channels: [
        Channel(id: 'd1', name: 'umumiy'),
        Channel(id: 'd2', name: 'flutter', topic: 'Flutter savollari va javoblari'),
        Channel(id: 'd3', name: 'dart-savollar', topic: 'Dart tili bo\'yicha'),
        Channel(
          id: 'd4',
          name: 'resurslar',
          type: ChannelType.announcement,
          topic: 'Foydali havolalar',
        ),
      ]),
      Category(id: 's3c2', name: 'OVOZLI KANALLAR', channels: [
        Channel(id: 'dv1', name: 'Kod sessiya', type: ChannelType.voice),
      ]),
    ],
  );
  s3.memberRoles.addAll({
    'me': {'d_flutter'},
    'u1': {'d_flutter'},
    'u2': {'d_admin'},
    'u4': <String>{},
    'u6': <String>{},
    'u8': <String>{},
    'bot_nextbot': <String>{},
    'bot_mod': <String>{},
  });

  // ---- Xabarlar ----
  final messages = <String, List<Message>>{
    'c1': [
      m('u1', 'Hammaga salom! Nextone serveriga xush kelibsiz 👋', 180),
      m('u2', "Salom! Yangi dizayn juda zo'r chiqibdi 🔥", 175, react: {
        '🔥': ['u1', 'me'],
        '❤️': ['u3'],
      }),
      m('u3', 'Flutter bilan qilinganmi?', 170),
      m('u1', 'Ha, bitta kod bilan Android, iOS va web.', 168),
      m('u4', 'Ovozli kanallar qachon bo\'ladi?', 120),
      m('u2', 'Keyingi bosqichda LiveKit ulaymiz 🎙️', 118, react: {
        '👍': ['u4', 'u5'],
      }),
      m('bot_nextbot', 'Salom! Buyruqlar uchun /help yozing.', 100),
      m('u5', "/roll 20 ni sinab ko'rdim, 17 tushdi 😄", 30),
    ],
    'c2': [
      m(
        'u1',
        "📢 Nextone 0.1: serverlar, kanallar, rollar va botlar tayyor!",
        600,
        react: {
          '🎉': ['u2', 'u3', 'u4', 'me'],
        },
      ),
      m(
        'u1',
        "📌 Qoidalar: bir-biringizni hurmat qiling va spam yubormang.",
        590,
        pinned: true,
      ),
    ],
    'c3': [
      m('u2', 'Dart\'da null safety bilan ishlash juda qulay.', 90),
      m('u3', 'StatefulWidget yoki Provider — qaysi biri yaxshi?', 85),
      m('u2', 'Kichik ilovada setState yetadi, kattasida Provider/Riverpod.', 80),
    ],
    'c4': [
      m('u5', "Bug topdim... keyin bu feature ekanini bilib qoldim 😂", 60,
          react: {
            '😂': ['u1', 'u2', 'u4'],
          }),
      m('u4', '😂😂😂', 58),
    ],
    'g1': [
      m('u3', "Bugun kechqurun turnir bor, kim qatnashadi?", 70),
      m('u5', "Men tayyorman! 🎮", 65),
      m('u7', "Men ham, faqat internet yaxshi bo'lsa.", 60),
    ],
    'g2': [
      m('u8', "4-kishilik jamoaga 1 kishi kerak.", 200),
    ],
    'g3': [
      m('u7', 'Mana kechagi eng zo\'r lahza 🔥', 300, react: {
        '🔥': ['u3', 'u5'],
      }),
    ],
    'd1': [
      m('u2', "Salom, Dasturchilar serveriga xush kelibsiz!", 400),
      m('u1', 'Savollar bo\'lsa #flutter kanaliga yozing.', 395),
    ],
    'd2': [
      m('u1', 'ListView.builder katta ro\'yxatlar uchun eng yaxshi tanlov.', 150),
      m('u4', 'Rahmat, endi tushundim 🙏', 140),
    ],
    'd3': [
      m('u6', "Dart'da late kalit so'zi qachon kerak bo'ladi?", 110),
      m('u2', "Qiymat keyinroq beriladigan, lekin null bo'lmasligi kerak maydonlar uchun.", 105),
    ],
    'd4': [
      m('u2', '📚 dart.dev va flutter.dev — rasmiy hujjatlar.', 500, pinned: true),
    ],
    'v1': <Message>[],
    'dm_u2': [
      m('u2', 'Salom! Nextone loyihasi qanday ketyapti?', 45),
    ],
    'dm_bot_nextbot': [
      m('bot_nextbot', 'Men NextBot. Buyruqlar uchun /help yozing.', 10),
    ],
  };
  // Ovozli kanallarda xabar saqlanmaydi.
  messages.remove('v1');

  return MockData(
    members: members,
    servers: [s1, s2, s3],
    messages: messages,
    dmIds: ['u2', 'bot_nextbot'],
    voice: {
      'v1': {'u2', 'u3'},
      'gv1': {'u5', 'u7'},
    },
  );
}
