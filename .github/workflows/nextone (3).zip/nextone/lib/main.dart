import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'l10n.dart';
import 'screens/home_shell.dart';
import 'screens/login_screen.dart';
import 'state.dart';
import 'theme.dart';

void main() => runApp(const NextoneApp());

class NextoneApp extends StatefulWidget {
  const NextoneApp({super.key});

  @override
  State<NextoneApp> createState() => _NextoneAppState();
}

class _NextoneAppState extends State<NextoneApp> {
  final AppState _state = AppState();

  @override
  void dispose() {
    _state.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: L10n.notifier,
      builder: (context, lang, _) => LangScope(
        lang: lang,
        child: AppScope(
          state: _state,
          child: MaterialApp(
            title: 'Nextone',
            debugShowCheckedModeBanner: false,
            theme: buildTheme(),
            locale: Locale(lang),
            supportedLocales: [for (final c in L10n.names.keys) Locale(c)],
            localizationsDelegates: const [
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            home: const _Root(),
          ),
        ),
      ),
    );
  }
}

class _Root extends StatelessWidget {
  const _Root();

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return s.loggedIn ? const HomeShell() : const LoginScreen();
  }
}
