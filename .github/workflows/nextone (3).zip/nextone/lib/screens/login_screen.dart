import 'package:flutter/material.dart' hide Text;
import '../widgets/tr_text.dart';

import '../state.dart';
import '../theme.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _name = TextEditingController();

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  void _enter() => AppScope.read(context).login(_name.text);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF1F1B6B), NX.rail],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 380),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(28),
                      child: Image.asset('assets/icon.png', width: 110, height: 110),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'Nextone',
                      style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      "Do'stlar, jamoa va jamiyat uchun makon",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: NX.muted),
                    ),
                    const SizedBox(height: 28),
                    TextField(
                      controller: _name,
                      autofocus: true,
                      textInputAction: TextInputAction.done,
                      onSubmitted: (_) => _enter(),
                      decoration: InputDecoration(
                        labelText: tr('Ismingiz'),
                        filled: true,
                        fillColor: NX.rail,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        style: FilledButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                        ),
                        onPressed: _enter,
                        child: const Text('Kirish'),
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      "Demo rejim: ma'lumotlar qurilmada saqlanmaydi.\nHisob va real vaqtli chat keyingi bosqichda (Firebase).",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: NX.dim, fontSize: 12),
                    ),
                    const SizedBox(height: 20),
                    const LanguagePicker(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
