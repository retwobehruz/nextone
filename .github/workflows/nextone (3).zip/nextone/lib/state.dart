import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import 'bots.dart';
import 'l10n.dart';
import 'mock_data.dart';
import 'models.dart';
import 'theme.dart';
import 'util.dart';

/// Ilovaning umumiy holatiga (AppState) har qanday joydan kirish uchun.
class AppScope extends InheritedNotifier<AppState> {
  const AppScope({
    super.key,
    required AppState state,
    required super.child,
  }) : super(notifier: state);

  /// build ichida: holat o'zgarganda vidjet qayta chiziladi.
  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope topilmadi');
    return scope!.notifier!;
  }

  /// Tugma bosilganda va hodisalarda: qayta chizishni talab qilmaydi.
  static AppState read(BuildContext context) {
    final scope = context.getInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope topilmadi');
    return scope!.notifier!;
  }
}

class MemberGroup {
  const MemberGroup(this.title, this.ids);
  final String title;
  final List<String> ids;
}

typedef CommandHint = ({BotInfo bot, BotCommand cmd});

class AppState extends ChangeNotifier {
  AppState() {
    final d = buildMockData();
    members.addAll(d.members);
    servers.addAll(d.servers);
    messages.addAll(d.messages);
    dmIds.addAll(d.dmIds);
    d.voice.forEach((k, v) => voice[k] = {...v});
    me = members['me']!;
  }

  // ---------------- Ma'lumotlar ----------------
  final Map<String, Member> members = {};
  final List<Server> servers = [];
  final Map<String, List<Message>> messages = {};
  final Map<String, int> unread = {};
  final Map<String, Set<String>> voice = {};
  final List<String> dmIds = [];
  late final Member me;

  // ---------------- Holat ----------------
  bool loggedIn = false;
  String? serverId; // null = bosh sahifa (DM)
  String? channelId;
  String? dmId;
  bool micMuted = false;
  bool deafened = false;
  bool camera = false;
  String? voiceChannelId;
  final List<String> musicQueue = [];

  Timer? _timer;
  bool _disposed = false;
  final Random _rng = Random();
  int _idSeq = 1000;

  Member get _unknown =>
      Member(id: '?', name: tr("Noma'lum"), color: NX.dim);

  String newId() => 'n${_idSeq++}';

  String get lang => L10n.lang;

  void setLang(String code) {
    L10n.set(code);
    notifyListeners();
  }

  // ---------------- Getterlar ----------------
  Server? get server => serverById(serverId);

  Channel? get channel {
    final sv = server;
    if (sv == null) return null;
    for (final ch in sv.allChannels) {
      if (ch.id == channelId) return ch;
    }
    return null;
  }

  /// Hozir ochiq turgan chat kaliti (ovozli kanal bo'lsa null).
  String? get activeKey {
    if (dmId != null) return 'dm_$dmId';
    final ch = channel;
    if (ch != null && ch.type != ChannelType.voice) return ch.id;
    return null;
  }

  Member member(String id) => members[id] ?? _unknown;

  Server? serverById(String? id) {
    if (id == null) return null;
    for (final s in servers) {
      if (s.id == id) return s;
    }
    return null;
  }

  Server? serverOfChannel(String chId) {
    for (final s in servers) {
      for (final ch in s.allChannels) {
        if (ch.id == chId) return s;
      }
    }
    return null;
  }

  int serverUnread(Server sv) {
    var n = 0;
    for (final ch in sv.allChannels) {
      n += unread[ch.id] ?? 0;
    }
    return n;
  }

  bool canPost(Channel ch, Server sv) {
    if (ch.type == ChannelType.announcement) {
      return sv.can('me', Permission.manageChannels);
    }
    return sv.can('me', Permission.sendMessages);
  }

  Color nameColor(String memberId, Server? sv) =>
      sv?.topRole(memberId)?.color ?? NX.text;

  Message? findMessage(String key, String id) {
    final list = messages[key];
    if (list == null) return null;
    for (final m in list) {
      if (m.id == id) return m;
    }
    return null;
  }

  void touch() => notifyListeners();

  // ---------------- Kirish / chiqish ----------------
  void login(String name) {
    final n = name.trim();
    me.name = n.isEmpty ? tr('Mehmon') : n;
    loggedIn = true;
    if (servers.isNotEmpty) selectServer(servers.first.id);
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 22), (_) => _simulate());
    notifyListeners();
  }

  void logout() {
    _timer?.cancel();
    leaveVoice();
    loggedIn = false;
    serverId = null;
    channelId = null;
    dmId = null;
    notifyListeners();
  }

  // ---------------- Navigatsiya ----------------
  void selectHome() {
    serverId = null;
    channelId = null;
    if (dmId == null && dmIds.isNotEmpty) dmId = dmIds.first;
    if (dmId != null) unread.remove('dm_$dmId');
    notifyListeners();
  }

  void selectServer(String id) {
    final sv = serverById(id);
    if (sv == null) return;
    serverId = id;
    dmId = null;
    Channel? first;
    for (final ch in sv.allChannels) {
      if (ch.type != ChannelType.voice) {
        first = ch;
        break;
      }
    }
    channelId = first?.id;
    if (first != null) unread.remove(first.id);
    notifyListeners();
  }

  void selectChannel(String id) {
    channelId = id;
    dmId = null;
    unread.remove(id);
    notifyListeners();
  }

  void openDm(String memberId) {
    serverId = null;
    channelId = null;
    dmId = memberId;
    if (!dmIds.contains(memberId)) dmIds.insert(0, memberId);
    messages.putIfAbsent('dm_$memberId', () => []);
    unread.remove('dm_$memberId');
    notifyListeners();
  }

  // ---------------- Xabarlar ----------------
  void _add(String key, Message msg) {
    messages.putIfAbsent(key, () => []).add(msg);
  }

  void send(String key, String text, {String? replyTo}) {
    final t = text.trim();
    if (t.isEmpty) return;
    final msg = Message(id: newId(), authorId: 'me', text: t, replyToId: replyTo);
    _add(key, msg);

    if (key.startsWith('dm_')) {
      final other = key.substring(3);
      final m = members[other];
      if (m != null && m.isBot) {
        _handleCommand(key, t, msg.id);
      } else {
        Future.delayed(const Duration(milliseconds: 1200), () {
          if (_disposed) return;
          _add(key, Message(id: newId(), authorId: other, text: _dmReplies[_rng.nextInt(_dmReplies.length)]));
          if (activeKey != key) unread[key] = (unread[key] ?? 0) + 1;
          notifyListeners();
        });
      }
    } else if (t.startsWith('/')) {
      _handleCommand(key, t, msg.id);
    }
    notifyListeners();
  }

  void toggleReaction(String key, String msgId, String emoji) {
    final m = findMessage(key, msgId);
    if (m == null) return;
    final set = m.reactions.putIfAbsent(emoji, () => <String>{});
    if (!set.add('me')) set.remove('me');
    if (set.isEmpty) m.reactions.remove(emoji);
    notifyListeners();
  }

  void deleteMessage(String key, String msgId) {
    messages[key]?.removeWhere((m) => m.id == msgId);
    notifyListeners();
  }

  void editMessage(String key, String msgId, String text) {
    final m = findMessage(key, msgId);
    final t = text.trim();
    if (m == null || t.isEmpty) return;
    m.text = t;
    m.edited = true;
    notifyListeners();
  }

  void togglePin(String key, String msgId) {
    final m = findMessage(key, msgId);
    if (m == null) return;
    m.pinned = !m.pinned;
    notifyListeners();
  }

  int purge(String key, int n) {
    final l = messages[key];
    if (l == null) return 0;
    final count = min(n, l.length);
    l.removeRange(l.length - count, l.length);
    return count;
  }

  // ---------------- Botlar ----------------
  List<BotInfo> botsFor(String key) {
    if (key.startsWith('dm_')) {
      final b = botById(key.substring(3));
      return b == null ? [] : [b];
    }
    final sv = serverOfChannel(key);
    if (sv == null) return [];
    return [
      for (final b in botCatalog)
        if (sv.memberRoles.containsKey(b.id)) b,
    ];
  }

  List<CommandHint> commandsFor(String key, String prefix) {
    final out = <CommandHint>[];
    final p = prefix.toLowerCase();
    for (final b in botsFor(key)) {
      for (final c in b.commands) {
        if (c.name.startsWith(p)) out.add((bot: b, cmd: c));
      }
    }
    return out;
  }

  void _handleCommand(String key, String text, String cmdMsgId) {
    final parts = text.substring(1).split(RegExp(r'\s+'));
    final name = parts.first.toLowerCase();
    final args = parts.skip(1).join(' ');
    final bots = botsFor(key);
    if (bots.isEmpty) return;

    BotInfo? owner;
    for (final b in bots) {
      if (b.commands.any((c) => c.name == name)) {
        owner = b;
        break;
      }
    }

    Future.delayed(const Duration(milliseconds: 450), () {
      if (_disposed) return;
      final bot = owner ?? bots.first;
      final reply = owner == null
          ? trf('❓ Noma\'lum buyruq: /{name}. Buyruqlar ro\'yxati uchun /help yozing.', {'name': name})
          : _run(bot, name, args, key);
      _add(
        key,
        Message(
          id: newId(),
          authorId: bot.id,
          text: reply,
          replyToId: cmdMsgId,
        ),
      );
      if (activeKey != key) unread[key] = (unread[key] ?? 0) + 1;
      notifyListeners();
    });
  }

  String _helpText(String key) {
    final b = StringBuffer('${tr('📖 Mavjud buyruqlar:')}\n');
    for (final bot in botsFor(key)) {
      for (final c in bot.commands) {
        final usage = c.usage.isEmpty ? '' : ' ${tr(c.usage)}';
        b.writeln('/${c.name}$usage — ${tr(c.description)}');
      }
    }
    return b.toString().trimRight();
  }

  String _run(BotInfo bot, String cmd, String args, String key) {
    final a = args.trim();
    switch (bot.id) {
      case 'bot_nextbot':
        switch (cmd) {
          case 'help':
            return _helpText(key);
          case 'ping':
            return '🏓 Pong! ${12 + _rng.nextInt(40)} ms';
          case 'roll':
            {
              final max = (int.tryParse(a) ?? 6).clamp(2, 1000000).toInt();
              return trf('🎲 Tushgan son: {n} (1–{max})', {'n': 1 + _rng.nextInt(max), 'max': max});
            }
          case 'coin':
            return _rng.nextBool() ? tr('🪙 Gerb!') : tr('🪙 Raqam!');
          case '8ball':
            {
              if (a.isEmpty) return tr('🔮 Savol bering: /8ball <savol>');
              return '🔮 ${tr(_ball[_rng.nextInt(_ball.length)])}';
            }
          case 'time':
            {
              final t = DateTime.now();
              return trf('🕒 Hozir {time} ({date})', {'time': fmtTime(t), 'date': fmtDate(t)});
            }
          case 'about':
            return tr('ℹ️ Nextone — barcha uchun muloqot ilovasi: serverlar, kanallar, rollar va botlar bilan.');
        }
        break;
      case 'bot_music':
        switch (cmd) {
          case 'play':
            {
              if (a.isEmpty) return tr('🎵 Foydalanish: /play <qo\'shiq nomi>');
              musicQueue.add(a);
              if (musicQueue.length == 1) return trf('▶️ Hozir ijro etilmoqda: {name}', {'name': a});
              return trf('🎵 Navbatga qo\'shildi: {name} (#{n})', {'name': a, 'n': musicQueue.length});
            }
          case 'queue':
            {
              if (musicQueue.isEmpty) return tr('📭 Navbat bo\'sh.');
              final lines = <String>[
                for (var i = 0; i < musicQueue.length; i++)
                  '${i + 1}. ${musicQueue[i]}',
              ];
              return '${tr('🎶 Navbat:')}\n${lines.join('\n')}';
            }
          case 'skip':
            {
              if (musicQueue.isEmpty) return tr('📭 Navbat bo\'sh.');
              final skipped = musicQueue.removeAt(0);
              if (musicQueue.isEmpty) return trf('⏭ O\'tkazildi: {name}. Navbat tugadi.', {'name': skipped});
              return trf('⏭ O\'tkazildi: {name}. Endi: {next}', {'name': skipped, 'next': musicQueue.first});
            }
          case 'stop':
            {
              musicQueue.clear();
              return tr('⏹ Navbat tozalandi.');
            }
        }
        break;
      case 'bot_mod':
        switch (cmd) {
          case 'rules':
            return [tr('📜 Server qoidalari:'), tr('1. Bir-biringizni hurmat qiling.'), tr('2. Spam va reklama taqiqlanadi.'), tr("3. Har bir kanalni o'z mavzusida ishlating.")].join('\n');
          case 'clear':
            {
              final sv = serverOfChannel(key);
              if (sv == null) return tr('⚠️ Bu buyruq faqat serverda ishlaydi.');
              if (!sv.can('me', Permission.manageMessages)) {
                return tr('⛔ Sizda xabarlarni boshqarish huquqi yo\'q.');
              }
              final n = (int.tryParse(a) ?? 5).clamp(1, 50).toInt();
              final removed = purge(key, n + 1); // buyruq xabari ham o'chadi
              return trf('🧹 {n} ta xabar tozalandi.', {'n': max(0, removed - 1)});
            }
        }
        break;
    }
    return trf('❓ Noma\'lum buyruq: /{name}. Buyruqlar ro\'yxati uchun /help yozing.', {'name': cmd});
  }

  // ---------------- Serverlar va kanallar ----------------
  void createServer(String name) {
    final id = newId();
    final adminId = 'admin_$id';
    final textCh = Channel(id: newId(), name: 'umumiy', topic: 'Umumiy suhbat');
    final voiceCh = Channel(id: newId(), name: 'Umumiy ovoz', type: ChannelType.voice);
    final sv = Server(
      id: id,
      name: name,
      color: NX.palette[servers.length % NX.palette.length],
      ownerId: 'me',
      description: 'Yangi server',
      roles: [
        Role(
          id: adminId,
          name: 'Admin',
          color: NX.red,
          hoist: true,
          permissions: {Permission.admin},
        ),
        Role(
          id: 'everyone',
          name: '@everyone',
          color: NX.muted,
          permissions: {Permission.sendMessages},
        ),
      ],
      categories: [
        Category(id: newId(), name: 'MATN KANALLARI', channels: [textCh]),
        Category(id: newId(), name: 'OVOZLI KANALLAR', channels: [voiceCh]),
      ],
    );
    sv.memberRoles['me'] = {adminId};
    sv.memberRoles['bot_nextbot'] = <String>{};
    messages[textCh.id] = [
      Message(
        id: newId(),
        authorId: 'bot_nextbot',
        text: trf('👋 "{name}" serveri tayyor! Buyruqlar uchun /help yozing.', {'name': name}),
      ),
    ];
    servers.add(sv);
    selectServer(id);
  }

  void removeServer(Server sv) {
    if (voiceChannelId != null && sv.allChannels.any((c) => c.id == voiceChannelId)) {
      leaveVoice();
    }
    for (final ch in sv.allChannels) {
      messages.remove(ch.id);
      unread.remove(ch.id);
      voice.remove(ch.id);
    }
    servers.remove(sv);
    if (serverId == sv.id) {
      selectHome();
    } else {
      notifyListeners();
    }
  }

  Channel createChannel(
    Server sv,
    String rawName,
    ChannelType type, {
    Category? category,
  }) {
    final trimmed = rawName.trim();
    final name = type == ChannelType.voice
        ? trimmed
        : trimmed.toLowerCase().replaceAll(RegExp(r'\s+'), '-');
    final ch = Channel(id: newId(), name: name, type: type);

    Category? target = category;
    if (target == null) {
      final wantVoice = type == ChannelType.voice;
      for (final c in sv.categories) {
        if (c.channels.any((x) => (x.type == ChannelType.voice) == wantVoice)) {
          target = c;
          break;
        }
      }
      if (target == null && sv.categories.isNotEmpty) target = sv.categories.first;
    }
    if (target == null) {
      target = Category(id: newId(), name: 'KANALLAR');
      sv.categories.add(target);
    }
    target.channels.add(ch);
    if (type != ChannelType.voice) messages[ch.id] = [];
    notifyListeners();
    return ch;
  }

  void deleteChannel(Server sv, Channel ch) {
    for (final c in sv.categories) {
      c.channels.removeWhere((x) => x.id == ch.id);
    }
    messages.remove(ch.id);
    unread.remove(ch.id);
    voice.remove(ch.id);
    if (voiceChannelId == ch.id) voiceChannelId = null;
    if (channelId == ch.id) {
      Channel? first;
      for (final x in sv.allChannels) {
        if (x.type != ChannelType.voice) {
          first = x;
          break;
        }
      }
      channelId = first?.id;
    }
    notifyListeners();
  }

  // ---------------- Rollar ----------------
  Role createRole(Server sv, String name) {
    final r = Role(
      id: newId(),
      name: name,
      color: NX.palette[_rng.nextInt(NX.palette.length)],
      hoist: false,
    );
    final idx = sv.roles.indexWhere((x) => x.id == 'everyone');
    sv.roles.insert(idx < 0 ? sv.roles.length : idx, r);
    notifyListeners();
    return r;
  }

  void deleteRole(Server sv, Role r) {
    if (r.id == 'everyone') return;
    sv.roles.remove(r);
    for (final set in sv.memberRoles.values) {
      set.remove(r.id);
    }
    notifyListeners();
  }

  void reorderRoles(Server sv, int oldIndex, int newIndex) {
    final list = sv.roles.where((r) => r.id != 'everyone').toList();
    if (oldIndex < 0 || oldIndex >= list.length) return;
    final item = list.removeAt(oldIndex);
    final target = newIndex.clamp(0, list.length).toInt();
    list.insert(target, item);
    final every = sv.everyone;
    sv.roles
      ..clear()
      ..addAll(list)
      ..add(every);
    notifyListeners();
  }

  void toggleMemberRole(Server sv, String memberId, String roleId) {
    final set = sv.memberRoles.putIfAbsent(memberId, () => <String>{});
    if (!set.add(roleId)) set.remove(roleId);
    notifyListeners();
  }

  // ---------------- Botlarni boshqarish ----------------
  void addBot(Server sv, String botId) {
    sv.memberRoles.putIfAbsent(botId, () => <String>{});
    notifyListeners();
  }

  void removeBot(Server sv, String botId) {
    sv.memberRoles.remove(botId);
    notifyListeners();
  }

  // ---------------- Ovoz ----------------
  void joinVoice(String chId) {
    if (voiceChannelId != null) voice[voiceChannelId!]?.remove('me');
    voice.putIfAbsent(chId, () => <String>{}).add('me');
    voiceChannelId = chId;
    channelId = chId;
    dmId = null;
    notifyListeners();
  }

  void leaveVoice() {
    if (voiceChannelId != null) voice[voiceChannelId!]?.remove('me');
    voiceChannelId = null;
    notifyListeners();
  }

  void toggleMic() {
    micMuted = !micMuted;
    if (!micMuted) deafened = false;
    notifyListeners();
  }

  void toggleDeafen() {
    deafened = !deafened;
    if (deafened) micMuted = true;
    notifyListeners();
  }

  void toggleCamera() {
    camera = !camera;
    notifyListeners();
  }

  // ---------------- Profil ----------------
  void updateProfile({
    String? name,
    String? bio,
    String? customStatus,
    PresenceStatus? status,
    Color? color,
    Color? banner,
  }) {
    if (name != null && name.trim().isNotEmpty) me.name = name.trim();
    if (bio != null) me.bio = bio.trim();
    if (customStatus != null) me.customStatus = customStatus.trim();
    if (status != null) me.status = status;
    if (color != null) me.color = color;
    if (banner != null) me.banner = banner;
    notifyListeners();
  }

  // ---------------- A'zolar guruhlari ----------------
  List<MemberGroup> memberGroups(Server sv) {
    bool isBot(String id) => members[id]?.isBot ?? false;
    bool online(String id) =>
        (members[id]?.status ?? PresenceStatus.offline) != PresenceStatus.offline;

    final placed = <String>{};
    final groups = <MemberGroup>[];

    for (final r in sv.roles) {
      if (!r.hoist || r.id == 'everyone') continue;
      final ids = <String>[];
      for (final e in sv.memberRoles.entries) {
        if (e.value.contains(r.id) &&
            !placed.contains(e.key) &&
            !isBot(e.key) &&
            online(e.key)) {
          ids.add(e.key);
        }
      }
      if (ids.isNotEmpty) {
        placed.addAll(ids);
        groups.add(MemberGroup(tr(r.name).toUpperCase(), ids));
      }
    }

    final bots = [
      for (final id in sv.memberRoles.keys)
        if (isBot(id)) id,
    ];
    if (bots.isNotEmpty) groups.add(MemberGroup('BOTLAR', bots));

    final onlineRest = [
      for (final id in sv.memberRoles.keys)
        if (!placed.contains(id) && !isBot(id) && online(id)) id,
    ];
    final offline = [
      for (final id in sv.memberRoles.keys)
        if (!isBot(id) && !online(id)) id,
    ];
    if (onlineRest.isNotEmpty) groups.add(MemberGroup('ONLAYN', onlineRest));
    if (offline.isNotEmpty) groups.add(MemberGroup('OFLAYN', offline));
    return groups;
  }

  // ---------------- Jonli faollik (demo) ----------------
  static const _dmReplies = [
    "Xo'p, tushundim 👍",
    "Ha, to'g'ri aytasiz!",
    'Hozir bandman, keyinroq yozaman 🙂',
    "Ajoyib g'oya! 🔥",
    'Hahaha 😂',
    'Yaxshi, kelishdik!',
  ];

  static const _chatter = [
    'Hammaga salom! 👋',
    'Bugun ob-havo juda yaxshi ☀️',
    "Kim yangi Flutter versiyasini sinab ko'rdi?",
    'Bu funksiya ajoyib chiqibdi 🔥',
    'Menimcha, buni boshqacha qilish kerak.',
    "Hahaha, zo'r edi 😂",
    "Kimda qiziq g'oya bor?",
    'Kechqurun ovozli kanalda uchrashamizmi? 🎙️',
    "Men hozir bug'ni tuzatyapman 🐛",
    'Rahmat, juda yordam berdingiz!',
    'Yangi dizayn menga yoqdi ❤️',
    'Dart tili kundan-kunga yaxshilanyapti.',
  ];

  static const _ball = [
    'Ha, albatta!',
    "Yo'q.",
    'Ehtimol.',
    "Aniq emas, yana so'rang.",
    "Menimcha, ha.",
    "Buning ehtimoli juda kam.",
    'Hech shubhasiz!',
  ];

  void _simulate() {
    if (_disposed || !loggedIn || servers.isEmpty) return;
    final sv = servers[_rng.nextInt(servers.length)];
    final humans = [
      for (final id in sv.memberRoles.keys)
        if (id != 'me' &&
            members[id] != null &&
            !members[id]!.isBot &&
            members[id]!.status != PresenceStatus.offline)
          id,
    ];
    final chans = [
      for (final ch in sv.allChannels)
        if (ch.type == ChannelType.text) ch,
    ];
    if (humans.isEmpty || chans.isEmpty) return;
    final ch = chans[_rng.nextInt(chans.length)];
    final author = humans[_rng.nextInt(humans.length)];
    _add(
      ch.id,
      Message(
        id: newId(),
        authorId: author,
        text: _chatter[_rng.nextInt(_chatter.length)],
      ),
    );
    if (activeKey != ch.id) unread[ch.id] = (unread[ch.id] ?? 0) + 1;
    notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _timer?.cancel();
    super.dispose();
  }
}
