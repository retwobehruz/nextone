import 'package:flutter_test/flutter_test.dart';
import 'package:nextone/l10n.dart';
import 'package:nextone/main.dart';

void main() {
  testWidgets('Login screen shows in the current language', (tester) async {
    await tester.pumpWidget(const NextoneApp());
    expect(find.text('Nextone'), findsWidgets);
    expect(find.text(tr('Kirish')), findsOneWidget);
  });

  test('Every language has the main strings', () {
    for (final table in L10n.tables.values) {
      expect(table.containsKey('Kirish'), isTrue);
      expect(table.containsKey('Bekor qilish'), isTrue);
    }
  });
}
