import 'package:flutter/material.dart' hide Text;
import '../widgets/tr_text.dart';

import '../state.dart';
import '../theme.dart';
import '../widgets/channel_pane.dart';
import '../widgets/chat_area.dart';
import '../widgets/member_pane.dart';
import '../widgets/server_rail.dart';

/// Keng ekranda 4 ustun, telefonda esa yon menyu (drawer) bilan.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  final _key = GlobalKey<ScaffoldState>();
  bool _members = true;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final wide = MediaQuery.sizeOf(context).width >= 900;
    final hasServer = s.server != null;

    final toast = s.toast;
    if (toast != null) {
      s.toast = null;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          ScaffoldMessenger.of(context)
            ..hideCurrentSnackBar()
            ..showSnackBar(SnackBar(content: Text(toast)));
        }
      });
    }

    if (wide) {
      return Scaffold(
        body: Row(
          children: [
            const ServerRail(),
            const SizedBox(width: 250, child: ChannelPane()),
            Expanded(
              child: ChatArea(
                onMembers: hasServer
                    ? () => setState(() => _members = !_members)
                    : null,
                membersOpen: _members,
              ),
            ),
            if (_members && hasServer) const SizedBox(width: 240, child: MemberPane()),
          ],
        ),
      );
    }

    return Scaffold(
      key: _key,
      drawer: Drawer(
        width: 336,
        backgroundColor: NX.side,
        shape: const RoundedRectangleBorder(),
        child: Row(
          children: [
            const ServerRail(),
            Expanded(
              child: ChannelPane(
                onNavigate: () => _key.currentState?.closeDrawer(),
              ),
            ),
          ],
        ),
      ),
      endDrawer: Drawer(
        width: 290,
        backgroundColor: NX.side,
        shape: const RoundedRectangleBorder(),
        child: MemberPane(
          onNavigate: () => _key.currentState?.closeEndDrawer(),
        ),
      ),
      body: SafeArea(
        child: ChatArea(
          onMenu: () => _key.currentState?.openDrawer(),
          onMembers: hasServer ? () => _key.currentState?.openEndDrawer() : null,
        ),
      ),
    );
  }
}
