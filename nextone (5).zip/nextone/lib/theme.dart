import 'package:flutter/material.dart';

/// Nextone ranglari (Discord'ga o'xshash qorong'u tema).
class NX {
  NX._();

  static const rail = Color(0xFF1E1F22);
  static const side = Color(0xFF2B2D31);
  static const main = Color(0xFF313338);
  static const raised = Color(0xFF383A40);
  static const panel = Color(0xFF232428);
  static const accent = Color(0xFF5865F2);
  static const green = Color(0xFF23A55A);
  static const red = Color(0xFFF23F43);
  static const gold = Color(0xFFF0B232);
  static const text = Color(0xFFF2F3F5);
  static const muted = Color(0xFFB5BAC1);
  static const dim = Color(0xFF80848E);
  static const divider = Color(0xFF3F4147);

  static const palette = <Color>[
    Color(0xFF5865F2),
    Color(0xFF3BA55D),
    Color(0xFFEB459E),
    Color(0xFFFAA61A),
    Color(0xFFED4245),
    Color(0xFF3B82F6),
    Color(0xFF9B59B6),
    Color(0xFF1ABC9C),
    Color(0xFFE67E22),
    Color(0xFF95A5A6),
  ];
}

ThemeData buildTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: NX.main,
    colorScheme: base.colorScheme.copyWith(
      primary: NX.accent,
      secondary: NX.accent,
      surface: NX.side,
    ),
    dividerColor: NX.divider,
    appBarTheme: const AppBarTheme(
      backgroundColor: NX.main,
      elevation: 0,
      scrolledUnderElevation: 0,
    ),
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: NX.side,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
    ),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
  );
}
