#!/usr/bin/env bash
# GitHub Actions ichida ishlaydi: Android loyihasini yaratadi va APK quradi.
set -euxo pipefail
cd "$(dirname "$0")/.."

# 1) Android papkasini yaratish (bizning kodimizga tegmasdan)
mkdir -p /tmp/bak
cp -r lib /tmp/bak/lib
cp -r test /tmp/bak/test
cp pubspec.yaml /tmp/bak/pubspec.yaml
flutter create --platforms=android --project-name nextone --org com.nextone .
rm -rf lib test
cp -r /tmp/bak/lib lib
cp -r /tmp/bak/test test
cp /tmp/bak/pubspec.yaml pubspec.yaml

# 2) Ilova nomi va internet ruxsati
MANIFEST=android/app/src/main/AndroidManifest.xml
sed -i 's/android:label="[^"]*"/android:label="Nextone"/' "$MANIFEST"
grep -q 'android.permission.REQUEST_INSTALL_PACKAGES' "$MANIFEST" || \
  sed -i 's|<application|<uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES"/>\n    <application|' "$MANIFEST"
grep -q 'android.permission.INTERNET' "$MANIFEST" || \
  sed -i 's|<application|<uses-permission android:name="android.permission.INTERNET"/>\n    <application|' "$MANIFEST"

# 2b) Google kirishdan keyin ilovaga qaytish (deep link: nextone://login-callback)
python3 - "$MANIFEST" <<'PY'
import sys
p = sys.argv[1]
s = open(p).read()
if 'login-callback' not in s:
    block = '''
            <meta-data android:name="flutter_deeplinking_enabled" android:value="false" />
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="nextone" android:host="login-callback" />
            </intent-filter>
'''
    i = s.index('</activity>')
    s = s[:i] + block + '        ' + s[i:]
    open(p, 'w').write(s)
PY
grep -n "login-callback" "$MANIFEST"
grep -n "INTERNET" "$MANIFEST"


# 2c) Bildirishnomalar uchun ruxsat (Android 13+)
grep -q 'android.permission.POST_NOTIFICATIONS' "$MANIFEST" || \
  sed -i 's|<application|<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>\n    <application|' "$MANIFEST"

# 2d) Firebase (push): faqat google-services.json repoda bo'lsa yoqiladi
if [ -f google-services.json ]; then
  cp google-services.json android/app/google-services.json
  python3 - <<'PY'
import os,re
def patch(files, marker, make):
    for f in files:
        if os.path.exists(f):
            s=open(f).read()
            if 'google-services' in s: return
            lines=s.split('\n'); out=[]; done=False
            for l in lines:
                out.append(l)
                if not done and marker in l:
                    kts=f.endswith('.kts')
                    out.append(make(kts)); done=True
            if done: open(f,'w').write('\n'.join(out)); print('patched',f)
            return
patch(['android/settings.gradle.kts','android/settings.gradle'],'org.jetbrains.kotlin.android',
  lambda k: '    id("com.google.gms.google-services") version "4.4.2" apply false' if k else '    id "com.google.gms.google-services" version "4.4.2" apply false')
patch(['android/app/build.gradle.kts','android/app/build.gradle'],'dev.flutter.flutter-gradle-plugin',
  lambda k: '    id("com.google.gms.google-services")' if k else '    id "com.google.gms.google-services"')
PY
fi


# 2e) Server havolasi: nextone://join/KOD
python3 - "$MANIFEST" <<'PY'
import sys
p = sys.argv[1]
s = open(p).read()
if 'android:host="join"' not in s:
    block = '''
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="nextone" android:host="join" />
            </intent-filter>
'''
    i = s.index('</activity>')
    s = s[:i] + block + '        ' + s[i:]
    open(p, 'w').write(s)
PY

# 3) Ilova ikonkasi
rm -rf android/app/src/main/res/mipmap-anydpi*
cp -r android_res/* android/app/src/main/res/

# 4) Doimiy imzo kaliti (Google bilan kirish uchun barmoq izi o'zgarmasligi kerak)
mkdir -p ~/.android
cp keystore/debug.keystore ~/.android/debug.keystore

# 5) minSdk 24
for f in android/app/build.gradle android/app/build.gradle.kts; do
  if [ -f "$f" ]; then
    sed -i -E 's/minSdk(Version)?( =|) ?flutter\.minSdkVersion/minSdk\1\2 24/' "$f"
  fi
done

# 6) Qurish
flutter pub get
# Plaginlardagi lint ishdan chiqishini oldini olish (Java versiyasi mos kelmaydi)
mkdir -p "$HOME/.gradle/init.d"
cat > "$HOME/.gradle/init.d/nolint.gradle" <<'GRADLE'
allprojects {
  tasks.configureEach { t ->
    if (t.name.startsWith('lint')) { t.enabled = false }
  }
}
GRADLE
flutter build apk --release --build-number="${GITHUB_RUN_NUMBER:-1}" --dart-define=BUILD="${GITHUB_RUN_NUMBER:-0}"
