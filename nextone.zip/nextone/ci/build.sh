#!/usr/bin/env bash
# GitHub Actions ichida ishlaydi: Android loyihasini yaratadi va APK quradi.
set -euxo pipefail
cd "$(dirname "$0")/.."

# 1) Android papkasini yaratish (bizning kodimizga tegmasdan)
mkdir -p /tmp/bak
cp -r lib /tmp/bak/lib
cp -r test /tmp/bak/test
cp pubspec.yaml /tmp/bak/pubspec.yaml
flutter create --platforms=android --project-name nextone --org com.nextone .
rm -rf lib test
cp -r /tmp/bak/lib lib
cp -r /tmp/bak/test test
cp /tmp/bak/pubspec.yaml pubspec.yaml

# 2) Ilova nomi va internet ruxsati
MANIFEST=android/app/src/main/AndroidManifest.xml
sed -i 's/android:label="[^"]*"/android:label="Nextone"/' "$MANIFEST"
grep -q 'android.permission.INTERNET' "$MANIFEST" || \
  sed -i 's|<application|<uses-permission android:name="android.permission.INTERNET"/>\n    <application|' "$MANIFEST"

# 2b) Google kirishdan keyin ilovaga qaytish (deep link: nextone://login-callback)
python3 - "$MANIFEST" <<'PY'
import sys
p = sys.argv[1]
s = open(p).read()
if 'login-callback' not in s:
    block = '''
            <meta-data android:name="flutter_deeplinking_enabled" android:value="false" />
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="nextone" android:host="login-callback" />
            </intent-filter>
'''
    i = s.index('</activity>')
    s = s[:i] + block + '        ' + s[i:]
    open(p, 'w').write(s)
PY
grep -n "login-callback" "$MANIFEST"

# 3) Ilova ikonkasi
rm -rf android/app/src/main/res/mipmap-anydpi*
cp -r android_res/* android/app/src/main/res/

# 4) Doimiy imzo kaliti (Google bilan kirish uchun barmoq izi o'zgarmasligi kerak)
mkdir -p ~/.android
cp keystore/debug.keystore ~/.android/debug.keystore

# 5) minSdk 24
for f in android/app/build.gradle android/app/build.gradle.kts; do
  if [ -f "$f" ]; then
    sed -i -E 's/minSdk(Version)?( =|) ?flutter\.minSdkVersion/minSdk\1\2 24/' "$f"
  fi
done

# 6) Qurish
flutter pub get
flutter build apk --release
