import 'package:flutter/material.dart' hide Text;
import 'package:image_picker/image_picker.dart';
import 'referral_screen.dart';
import '../widgets/tr_text.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'plans_screen.dart';

/// Mening profilim: ism, status, bio, ranglar.
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late final TextEditingController _name;
  late final TextEditingController _user;
  late final TextEditingController _custom;
  late final TextEditingController _bio;
  late PresenceStatus _status;
  late Color _color;
  late Color _banner;

  @override
  void initState() {
    super.initState();
    final me = AppScope.read(context).me;
    _name = TextEditingController(text: me.name);
    _user = TextEditingController(text: me.username);
    _custom = TextEditingController(text: me.customStatus);
    _bio = TextEditingController(text: me.bio);
    _status = me.status;
    _color = me.color;
    _banner = me.banner;
  }

  @override
  void dispose() {
    _name.dispose();
    _user.dispose();
    _custom.dispose();
    _bio.dispose();
    super.dispose();
  }

  Future<void> _pickAvatar() async {
    final s = AppScope.read(context);
    try {
      final f = await ImagePicker().pickImage(
          source: ImageSource.gallery,
          maxWidth: 512,
          maxHeight: 512,
          imageQuality: 85);
      if (f == null) return;
      final bytes = await f.readAsBytes();
      final dot = f.name.lastIndexOf('.');
      final ext = dot < 0 ? 'jpg' : f.name.substring(dot + 1).toLowerCase();
      await s.uploadAvatar(bytes, ext);
    } catch (e) {
      s.toast = tr('Rasm yuklab bo\'lmadi');
      s.notifyListeners();
    }
  }

  Future<void> _save() async {
    final err = await AppScope.read(context).updateProfile(
      username: _user.text,
      name: _name.text,
      bio: _bio.text,
      customStatus: _custom.text,
      status: _status,
      color: _color,
      banner: _banner,
    );
    if (!mounted) return;
    if (err != null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(err)));
      return;
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final preview = Member(
      avatarUrl: s.me.avatarUrl,
      plan: s.me.plan,
      id: 'me',
      name: _name.text.isEmpty ? tr('Siz') : _name.text,
      color: _color,
      status: _status,
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profil'),
        actions: [
          TextButton(onPressed: _save, child: const Text('Saqlash')),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 32),
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              Container(height: 110, color: _banner),
              Positioned(
                left: 20,
                bottom: -42,
                child: GestureDetector(
                  onTap: _pickAvatar,
                  child: Stack(
                    children: [
                      Avatar(
                        member: preview,
                        size: 92,
                        showStatus: true,
                        ringColor: NX.main,
                      ),
                      Positioned(
                        right: 0,
                        top: 0,
                        child: CircleAvatar(
                          radius: 14,
                          backgroundColor: NX.accent,
                          child: const Icon(Icons.photo_camera,
                              size: 15, color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 54),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: _name,
                  onChanged: (_) => setState(() {}),
                  decoration: InputDecoration(
                    labelText: tr('Ism'),
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _user,
                  autocorrect: false,
                  decoration: InputDecoration(
                    labelText: tr('Username'),
                    prefixText: '@',
                    helperText: tr('Do\'stlar sizni shu orqali topadi'),
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _custom,
                  decoration: InputDecoration(
                    labelText: tr('Maxsus status'),
                    hintText: tr('Masalan: Kod yozyapman 💻'),
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _bio,
                  maxLines: 3,
                  maxLength: 190,
                  decoration: InputDecoration(
                    labelText: tr("O'zingiz haqingizda"),
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 4),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.local_fire_department_rounded,
                      color: Color(0xFFFF7A3D)),
                  title: Text(
                      trf('Kunlik seriya: {n} kun', {'n': AppScope.of(context).streak})),
                  subtitle: const Text(
                      "Har 7 kun ketma-ket kirsangiz 1 kun bepul Plus"),
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.star_rounded, color: Color(0xFFF0B232)),
                  title: const Text('Nextone Plus / Prime'),
                  subtitle: const Text('Obunalar va imkoniyatlar'),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute<void>(builder: (_) => const PlansScreen()),
                  ),
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.card_giftcard_rounded, color: Color(0xFF3FA9FF)),
                  title: const Text("Do'stlarni taklif qilish"),
                  subtitle: const Text("Har bir do'st uchun 3 kun bepul Plus"),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute<void>(builder: (_) => const ReferralScreen()),
                  ),
                ),
                const SectionLabel('TIL', padding: EdgeInsets.fromLTRB(0, 8, 0, 8)),
                const LanguagePicker(),
                const SectionLabel('HOLAT', padding: EdgeInsets.fromLTRB(0, 20, 0, 8)),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final st in PresenceStatus.values)
                      ChoiceChip(
                        selected: _status == st,
                        avatar: CircleAvatar(backgroundColor: st.color, radius: 6),
                        label: Text(st.label),
                        onSelected: (_) => setState(() => _status = st),
                      ),
                  ],
                ),
                const SectionLabel('AVATAR RANGI', padding: EdgeInsets.fromLTRB(0, 20, 0, 8)),
                ColorPicker(value: _color, onChanged: (c) => setState(() => _color = c)),
                const SectionLabel('PROFIL FONI', padding: EdgeInsets.fromLTRB(0, 20, 0, 8)),
                ColorPicker(value: _banner, onChanged: (c) => setState(() => _banner = c)),
                const SizedBox(height: 28),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: _save,
                    child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 4),
                      child: Text('Saqlash'),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(foregroundColor: NX.red),
                    onPressed: () async {
                      final ok = await confirmDialog(
                        context,
                        title: 'Chiqish',
                        body: 'Akkauntdan chiqmoqchimisiz?',
                        action: 'Chiqish',
                        danger: true,
                      );
                      if (!ok || !context.mounted) return;
                      Navigator.pop(context);
                      s.logout();
                    },
                    icon: const Icon(Icons.logout_rounded),
                    label: const Text('Chiqish'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
