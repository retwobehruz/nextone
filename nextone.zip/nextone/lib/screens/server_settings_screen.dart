import 'package:flutter/material.dart' hide Text;
import 'package:image_picker/image_picker.dart';

import '../l10n.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/tr_text.dart';

/// Server sozlamalari: rasm, nom va tavsif (faqat server egasi).
class ServerSettingsScreen extends StatefulWidget {
  const ServerSettingsScreen({super.key, required this.serverId});
  final String serverId;

  @override
  State<ServerSettingsScreen> createState() => _ServerSettingsScreenState();
}

class _ServerSettingsScreenState extends State<ServerSettingsScreen> {
  late final TextEditingController _name;
  late final TextEditingController _desc;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final sv = AppScope.read(context).serverById(widget.serverId)!;
    _name = TextEditingController(text: sv.name);
    _desc = TextEditingController(text: sv.description);
  }

  @override
  void dispose() {
    _name.dispose();
    _desc.dispose();
    super.dispose();
  }

  Future<void> _pickIcon() async {
    final s = AppScope.read(context);
    final sv = s.serverById(widget.serverId)!;
    try {
      final f = await ImagePicker().pickImage(
          source: ImageSource.gallery,
          maxWidth: 512,
          maxHeight: 512,
          imageQuality: 88);
      if (f == null) return;
      setState(() => _busy = true);
      final bytes = await f.readAsBytes();
      final dot = f.name.lastIndexOf('.');
      final ext = dot < 0 ? 'jpg' : f.name.substring(dot + 1).toLowerCase();
      final err = await s.uploadServerIcon(sv, bytes, ext);
      if (mounted && err != null) snack(context, err);
    } catch (e) {
      if (mounted) snack(context, tr('Rasm yuklab bo\'lmadi'));
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _save() async {
    final s = AppScope.read(context);
    final sv = s.serverById(widget.serverId)!;
    setState(() => _busy = true);
    final err = await s.updateServer(sv, name: _name.text, description: _desc.text);
    if (!mounted) return;
    setState(() => _busy = false);
    if (err != null) {
      snack(context, err);
    } else {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final sv = s.serverById(widget.serverId);
    if (sv == null) return const Scaffold();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Server sozlamalari'),
        actions: [
          TextButton(
              onPressed: _busy ? null : _save, child: const Text('Saqlash')),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: GestureDetector(
              onTap: _busy ? null : _pickIcon,
              child: Stack(
                children: [
                  Container(
                    width: 96,
                    height: 96,
                    clipBehavior: Clip.antiAlias,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: sv.color,
                      borderRadius: BorderRadius.circular(26),
                    ),
                    child: (sv.iconUrl != null && sv.iconUrl!.isNotEmpty)
                        ? Image.network(sv.iconUrl!,
                            width: 96, height: 96, fit: BoxFit.cover)
                        : Text(sv.initials,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 30,
                                fontWeight: FontWeight.w800)),
                  ),
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: CircleAvatar(
                      radius: 15,
                      backgroundColor: NX.accent,
                      child: _busy
                          ? const SizedBox(
                              width: 14,
                              height: 14,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white))
                          : const Icon(Icons.photo_camera,
                              size: 16, color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Center(
            child: Text(tr('Server rasmini o\'zgartirish uchun bosing'),
                style: const TextStyle(color: NX.dim, fontSize: 12)),
          ),
          const SizedBox(height: 20),
          TextField(
            controller: _name,
            maxLength: 40,
            decoration: InputDecoration(
              labelText: tr('Server nomi'),
              border: const OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _desc,
            maxLines: 4,
            maxLength: 300,
            decoration: InputDecoration(
              labelText: tr('Tavsif'),
              hintText: tr('Bu server nima haqida?'),
              border: const OutlineInputBorder(),
            ),
          ),
        ],
      ),
    );
  }
}
