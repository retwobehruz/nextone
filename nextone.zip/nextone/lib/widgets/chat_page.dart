import 'package:flutter/material.dart' hide Text;
import 'tr_text.dart';
import 'package:flutter/services.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../util.dart';
import 'common.dart';
import 'member_pane.dart';

const _emojis = [
  '😀', '😂', '🤣', '😊', '😍', '😘', '😎', '🤔',
  '😮', '😢', '😭', '😡', '🥳', '😴', '🤯', '🙄',
  '👍', '👎', '👏', '🙌', '🙏', '💪', '👋', '🤝',
  '❤️', '💔', '🔥', '⭐', '🎉', '🎮', '🎵', '💻',
  '☕', '🍕', '🍔', '⚽', '🚀', '💡', '✅', '❌',
];

/// Bitta chat (kanal yoki shaxsiy suhbat): xabarlar + yozish paneli.
class ChatPage extends StatefulWidget {
  const ChatPage({
    super.key,
    required this.chatKey,
    required this.title,
    this.isDm = false,
    this.canPost = true,
    this.lockedHint = '',
  });

  final String chatKey;
  final String title;
  final bool isDm;
  final bool canPost;
  final String lockedHint;

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final _controller = TextEditingController();
  final _focus = FocusNode();
  Message? _replyTo;

  @override
  void dispose() {
    _controller.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _send() {
    final t = _controller.text.trim();
    if (t.isEmpty) return;
    AppScope.read(context).send(widget.chatKey, t, replyTo: _replyTo?.id);
    _controller.clear();
    setState(() => _replyTo = null);
  }

  void _insert(String e) {
    final t = _controller.text;
    final sel = _controller.selection;
    final start = sel.isValid ? sel.start : t.length;
    final end = sel.isValid ? sel.end : t.length;
    _controller.value = TextEditingValue(
      text: t.replaceRange(start, end, e),
      selection: TextSelection.collapsed(offset: start + e.length),
    );
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final list = s.messages[widget.chatKey] ?? const <Message>[];
    final server = s.serverOfChannel(widget.chatKey);

    return Column(
      children: [
        Expanded(
          child: list.isEmpty
              ? _EmptyChat(title: widget.title, isDm: widget.isDm)
              : ListView.builder(
                  reverse: true,
                  padding: const EdgeInsets.only(top: 12, bottom: 8),
                  itemCount: list.length,
                  itemBuilder: (ctx, i) {
                    final idx = list.length - 1 - i;
                    final msg = list[idx];
                    final prev = idx > 0 ? list[idx - 1] : null;
                    final newDay = prev == null || !sameDay(prev.time, msg.time);
                    final head = prev == null ||
                        newDay ||
                        prev.authorId != msg.authorId ||
                        msg.time.difference(prev.time).inMinutes >= 5 ||
                        msg.replyToId != null;
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        if (newDay) _DaySeparator(msg.time),
                        MessageTile(
                          msg: msg,
                          head: head,
                          chatKey: widget.chatKey,
                          server: server,
                          onReply: (m) {
                            setState(() => _replyTo = m);
                            _focus.requestFocus();
                          },
                        ),
                      ],
                    );
                  },
                ),
        ),
        if (_replyTo != null) _replyBar(s),
        _hints(s),
        _inputBar(),
      ],
    );
  }

  Widget _replyBar(AppState s) {
    final r = _replyTo!;
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 0),
      padding: const EdgeInsets.fromLTRB(12, 8, 4, 8),
      decoration: const BoxDecoration(
        color: NX.side,
        borderRadius: BorderRadius.vertical(top: Radius.circular(10)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text.rich(
              TextSpan(
                children: [
                  TextSpan(
                    text: tr('Javob: '),
                    style: TextStyle(color: NX.dim),
                  ),
                  TextSpan(
                    text: s.member(r.authorId).name,
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  TextSpan(
                    text: '  ${tr(r.text)}',
                    style: const TextStyle(color: NX.muted),
                  ),
                ],
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          IconButton(
            iconSize: 18,
            visualDensity: VisualDensity.compact,
            onPressed: () => setState(() => _replyTo = null),
            icon: const Icon(Icons.close_rounded),
          ),
        ],
      ),
    );
  }

  Widget _hints(AppState s) {
    final t = _controller.text;
    if (!t.startsWith('/') || t.contains(' ')) return const SizedBox.shrink();
    final list = s.commandsFor(widget.chatKey, t.substring(1));
    if (list.isEmpty) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 6),
      constraints: const BoxConstraints(maxHeight: 190),
      decoration: BoxDecoration(
        color: NX.side,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: NX.divider),
      ),
      child: ListView(
        shrinkWrap: true,
        padding: EdgeInsets.zero,
        children: [
          for (final h in list)
            ListTile(
              dense: true,
              leading: Avatar(member: s.member(h.bot.id), size: 28),
              title: Text('/${h.cmd.name} ${tr(h.cmd.usage)}'.trim()),
              subtitle: Text(h.cmd.description),
              onTap: () {
                _controller.value = TextEditingValue(
                  text: '/${h.cmd.name} ',
                  selection: TextSelection.collapsed(
                    offset: h.cmd.name.length + 2,
                  ),
                );
                setState(() {});
                _focus.requestFocus();
              },
            ),
        ],
      ),
    );
  }

  Widget _inputBar() {
    if (!widget.canPost) {
      return Container(
        margin: const EdgeInsets.fromLTRB(12, 4, 12, 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: NX.raised,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            const Icon(Icons.lock_outline_rounded, size: 18, color: NX.dim),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                widget.lockedHint,
                style: const TextStyle(color: NX.dim),
              ),
            ),
          ],
        ),
      );
    }

    final hint = widget.isDm
        ? trf('{title} ga xabar yozing', {'title': tr(widget.title)})
        : trf('#{title} ga xabar yozing', {'title': tr(widget.title)});

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
      child: Container(
        decoration: BoxDecoration(
          color: NX.raised,
          borderRadius: _replyTo != null
              ? const BorderRadius.vertical(bottom: Radius.circular(10))
              : BorderRadius.circular(10),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            IconButton(
              tooltip: tr("Biriktirish"),
              onPressed: _attachSheet,
              icon: const Icon(Icons.add_circle_rounded, color: NX.muted),
            ),
            Expanded(
              child: CallbackShortcuts(
                bindings: {
                  const SingleActivator(LogicalKeyboardKey.enter): _send,
                },
                child: TextField(
                  controller: _controller,
                  focusNode: _focus,
                  minLines: 1,
                  maxLines: 5,
                  textCapitalization: TextCapitalization.sentences,
                  onChanged: (_) => setState(() {}),
                  decoration: InputDecoration(
                    hintText: hint,
                    hintStyle: const TextStyle(color: NX.dim),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                ),
              ),
            ),
            IconButton(
              tooltip: tr('Emoji'),
              onPressed: _emojiSheet,
              icon: const Icon(Icons.emoji_emotions_outlined, color: NX.muted),
            ),
            IconButton(
              tooltip: tr('Yuborish'),
              onPressed: _send,
              icon: Icon(
                Icons.send_rounded,
                color: _controller.text.trim().isEmpty ? NX.dim : NX.accent,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _emojiSheet() {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: SizedBox(
          height: 260,
          child: GridView.count(
            crossAxisCount: 8,
            padding: const EdgeInsets.all(12),
            children: [
              for (final e in _emojis)
                InkWell(
                  borderRadius: BorderRadius.circular(8),
                  onTap: () {
                    Navigator.pop(ctx);
                    _insert(e);
                  },
                  child: Center(
                    child: Text(e, style: const TextStyle(fontSize: 24)),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  void _attachSheet() {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            for (final item in const [
              (Icons.image_outlined, 'Rasm yuborish'),
              (Icons.attach_file_rounded, 'Fayl yuborish'),
              (Icons.poll_outlined, "So'rovnoma"),
            ])
              ListTile(
                leading: Icon(item.$1),
                title: Text(item.$2),
                subtitle: const Text('Backend (Firebase) ulangandan keyin ishlaydi'),
                onTap: () {
                  Navigator.pop(ctx);
                  snack(context, 'Bu funksiya keyingi bosqichda qo\'shiladi');
                },
              ),
          ],
        ),
      ),
    );
  }
}

class _EmptyChat extends StatelessWidget {
  const _EmptyChat({required this.title, required this.isDm});
  final String title;
  final bool isDm;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(isDm ? Icons.waving_hand_rounded : Icons.tag, size: 48, color: NX.dim),
            const SizedBox(height: 12),
            Text(
              isDm ? trf('{title} bilan suhbat', {'title': tr(title)}) : trf('#{title} ga xush kelibsiz!', {'title': tr(title)}),
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 6),
            const Text(
              'Bu yerda hali xabarlar yo\'q. Birinchi bo\'lib yozing!',
              style: TextStyle(color: NX.muted),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

class _DaySeparator extends StatelessWidget {
  const _DaySeparator(this.time);
  final DateTime time;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        children: [
          const Expanded(child: Divider(color: NX.divider)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text(
              fmtDay(time),
              style: const TextStyle(
                color: NX.dim,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const Expanded(child: Divider(color: NX.divider)),
        ],
      ),
    );
  }
}

// ------------------------------------------------------------------ Xabar

class MessageTile extends StatelessWidget {
  const MessageTile({
    super.key,
    required this.msg,
    required this.head,
    required this.chatKey,
    required this.onReply,
    this.server,
  });

  final Message msg;
  final bool head;
  final String chatKey;
  final Server? server;
  final void Function(Message) onReply;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final author = s.member(msg.authorId);
    final color = s.nameColor(msg.authorId, server);
    final reply = msg.replyToId == null ? null : s.findMessage(chatKey, msg.replyToId!);

    void actions() => showMessageActions(
          context,
          msg: msg,
          chatKey: chatKey,
          onReply: onReply,
        );

    return InkWell(
      onLongPress: actions,
      onSecondaryTap: actions,
      child: Container(
        color: msg.pinned ? NX.gold.withAlpha(20) : null,
        padding: EdgeInsets.fromLTRB(16, head ? 8 : 1, 16, 1),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 40,
              child: head
                  ? GestureDetector(
                      onTap: () => showMemberProfile(context, author.id),
                      child: Avatar(member: author, size: 40),
                    )
                  : null,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (msg.replyToId != null) _replyPreview(s, reply),
                  if (head)
                    Row(
                      children: [
                        Flexible(
                          child: GestureDetector(
                            onTap: () => showMemberProfile(context, author.id),
                            child: Text(
                              author.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: color,
                                fontWeight: FontWeight.w700,
                                fontSize: 15,
                              ),
                            ),
                          ),
                        ),
                        if (author.isBot) ...[
                          const SizedBox(width: 6),
                          const BotTag(),
                        ],
                        const SizedBox(width: 8),
                        Text(
                          '${fmtDay(msg.time)}, ${fmtTime(msg.time)}',
                          style: const TextStyle(color: NX.dim, fontSize: 11.5),
                        ),
                        if (msg.pinned) ...[
                          const SizedBox(width: 6),
                          const Icon(Icons.push_pin, size: 13, color: NX.gold),
                        ],
                      ],
                    ),
                  Text.rich(
                    TextSpan(
                      children: [
                        TextSpan(text: tr(msg.text)),
                        if (msg.edited)
                          TextSpan(
                            text: tr('  (tahrirlangan)'),
                            style: TextStyle(color: NX.dim, fontSize: 11),
                          ),
                      ],
                    ),
                    style: const TextStyle(fontSize: 15, height: 1.35),
                  ),
                  if (msg.reactions.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Wrap(
                        spacing: 4,
                        runSpacing: 4,
                        children: [
                          for (final e in msg.reactions.entries)
                            _ReactionChip(
                              emoji: e.key,
                              count: e.value.length,
                              mine: e.value.contains('me'),
                              onTap: () => s.toggleReaction(chatKey, msg.id, e.key),
                            ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _replyPreview(AppState s, Message? reply) {
    final name = reply == null ? '' : s.member(reply.authorId).name;
    return Padding(
      padding: const EdgeInsets.only(bottom: 3),
      child: Row(
        children: [
          const Icon(Icons.subdirectory_arrow_right_rounded, size: 16, color: NX.dim),
          const SizedBox(width: 4),
          Flexible(
            child: Text(
              reply == null ? "Asl xabar o'chirilgan" : '$name: ${tr(reply.text)}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: NX.dim,
                fontSize: 12.5,
                fontStyle: reply == null ? FontStyle.italic : FontStyle.normal,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ReactionChip extends StatelessWidget {
  const _ReactionChip({
    required this.emoji,
    required this.count,
    required this.mine,
    required this.onTap,
  });

  final String emoji;
  final int count;
  final bool mine;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
          color: mine ? NX.accent.withAlpha(60) : NX.raised,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: mine ? NX.accent : Colors.transparent),
        ),
        child: Text(
          '$emoji $count',
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            color: mine ? Colors.white : NX.muted,
          ),
        ),
      ),
    );
  }
}

// --------------------------------------------------------- Xabar amallari

void showMessageActions(
  BuildContext context, {
  required Message msg,
  required String chatKey,
  required void Function(Message) onReply,
}) {
  final s = AppScope.read(context);
  final sv = s.serverOfChannel(chatKey);
  final isMine = msg.authorId == 'me';
  final canManage = sv != null && sv.can('me', Permission.manageMessages);
  final canPin = chatKey.startsWith('dm_') || canManage;

  showModalBottomSheet<void>(
    context: context,
    builder: (ctx) => SafeArea(
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  for (final e in const ['👍', '❤️', '😂', '🔥', '😮', '😢'])
                    InkWell(
                      borderRadius: BorderRadius.circular(20),
                      onTap: () {
                        Navigator.pop(ctx);
                        s.toggleReaction(chatKey, msg.id, e);
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(6),
                        child: Text(e, style: const TextStyle(fontSize: 28)),
                      ),
                    ),
                ],
              ),
            ),
            const Divider(height: 1),
            ListTile(
              leading: const Icon(Icons.reply_rounded),
              title: const Text('Javob yozish'),
              onTap: () {
                Navigator.pop(ctx);
                onReply(msg);
              },
            ),
            ListTile(
              leading: const Icon(Icons.copy_rounded),
              title: const Text('Nusxa olish'),
              onTap: () {
                Navigator.pop(ctx);
                Clipboard.setData(ClipboardData(text: msg.text));
                snack(context, 'Nusxa olindi');
              },
            ),
            if (canPin)
              ListTile(
                leading: Icon(msg.pinned ? Icons.push_pin : Icons.push_pin_outlined),
                title: Text(msg.pinned ? 'Mahkamlashni bekor qilish' : 'Mahkamlash'),
                onTap: () {
                  Navigator.pop(ctx);
                  s.togglePin(chatKey, msg.id);
                },
              ),
            if (isMine)
              ListTile(
                leading: const Icon(Icons.edit_outlined),
                title: const Text('Tahrirlash'),
                onTap: () async {
                  Navigator.pop(ctx);
                  final t = await promptText(
                    context,
                    title: 'Xabarni tahrirlash',
                    initial: msg.text,
                  );
                  if (t != null) s.editMessage(chatKey, msg.id, t);
                },
              ),
            if (isMine || canManage)
              ListTile(
                leading: const Icon(Icons.delete_outline_rounded, color: NX.red),
                title: const Text("O'chirish", style: TextStyle(color: NX.red)),
                onTap: () {
                  Navigator.pop(ctx);
                  s.deleteMessage(chatKey, msg.id);
                },
              ),
          ],
        ),
      ),
    ),
  );
}

void showPinned(BuildContext context, String chatKey) {
  final s = AppScope.read(context);
  final pins = (s.messages[chatKey] ?? const <Message>[]).where((m) => m.pinned).toList();
  showModalBottomSheet<void>(
    context: context,
    builder: (ctx) => SafeArea(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxHeight: 420),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'Mahkamlangan xabarlar',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
              ),
            ),
            if (pins.isEmpty)
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 0, 16, 24),
                child: Text(
                  "Hozircha mahkamlangan xabar yo'q.\nXabarni bosib turing va «Mahkamlash» ni tanlang.",
                  textAlign: TextAlign.center,
                  style: TextStyle(color: NX.muted),
                ),
              )
            else
              Flexible(
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    for (final m in pins)
                      ListTile(
                        leading: Avatar(member: s.member(m.authorId), size: 36),
                        title: Text(s.member(m.authorId).name),
                        subtitle: Text(m.text, maxLines: 4, overflow: TextOverflow.ellipsis),
                      ),
                  ],
                ),
              ),
          ],
        ),
      ),
    ),
  );
}
