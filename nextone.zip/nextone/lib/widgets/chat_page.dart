import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart' hide Text;
import 'package:record/record.dart';
import 'tr_text.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../util.dart';
import 'common.dart';
import 'member_pane.dart';
import 'voice.dart';

const _emojis = [
  '😀', '😂', '🤣', '😊', '😍', '😘', '😎', '🤔',
  '😮', '😢', '😭', '😡', '🥳', '😴', '🤯', '🙄',
  '👍', '👎', '👏', '🙌', '🙏', '💪', '👋', '🤝',
  '❤️', '💔', '🔥', '⭐', '🎉', '🎮', '🎵', '💻',
  '☕', '🍕', '🍔', '⚽', '🚀', '💡', '✅', '❌',
];

/// Bitta chat (kanal yoki shaxsiy suhbat): xabarlar + yozish paneli.
class ChatPage extends StatefulWidget {
  const ChatPage({
    super.key,
    required this.chatKey,
    required this.title,
    this.isDm = false,
    this.canPost = true,
    this.lockedHint = '',
  });

  final String chatKey;
  final String title;
  final bool isDm;
  final bool canPost;
  final String lockedHint;

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final _controller = TextEditingController();
  final _focus = FocusNode();
  Message? _replyTo;
  final _rec = AudioRecorder();
  bool _recording = false;
  int _recSecs = 0;
  Timer? _recTimer;
  String? _recPath;

  Future<void> _startRec() async {
    try {
      if (!await _rec.hasPermission()) {
        if (mounted) snack(context, 'Mikrofonga ruxsat bering');
        return;
      }
      final path =
          '${Directory.systemTemp.path}/nx_${DateTime.now().millisecondsSinceEpoch}.m4a';
      await _rec.start(const RecordConfig(encoder: AudioEncoder.aacLc),
          path: path);
      _recPath = path;
      _recSecs = 0;
      _recTimer?.cancel();
      _recTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted) return;
        setState(() => _recSecs++);
        if (_recSecs >= 300) _stopRec(send: true);
      });
      setState(() => _recording = true);
    } catch (e) {
      debugPrint('rec: $e');
      if (mounted) snack(context, 'Yozib bo\'lmadi');
    }
  }

  Future<void> _stopRec({required bool send}) async {
    _recTimer?.cancel();
    final secs = _recSecs;
    if (mounted) setState(() => _recording = false);
    try {
      final path = await _rec.stop();
      final f = File(path ?? _recPath ?? '');
      if (send && secs >= 1 && await f.exists()) {
        final bytes = await f.readAsBytes();
        if (!mounted) return;
        final reply = _replyTo?.id;
        setState(() => _replyTo = null);
        await AppScope.read(context).sendFile(
            widget.chatKey, bytes, 'voice_$secs.m4a',
            replyTo: reply);
      }
      if (await f.exists()) await f.delete();
    } catch (e) {
      debugPrint('rec stop: $e');
    }
  }

  AppState? _st;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _st = AppScope.read(context);
      _st!.typingStart(widget.chatKey);
    });
  }

  @override
  void didUpdateWidget(covariant ChatPage old) {
    super.didUpdateWidget(old);
    if (old.chatKey != widget.chatKey) {
      _st?.typingStop(old.chatKey);
      _st?.typingStart(widget.chatKey);
    }
  }

  @override
  void dispose() {
    _st?.typingStop(widget.chatKey);
    _recTimer?.cancel();
    _rec.dispose();
    _controller.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _send() {
    final t = _controller.text.trim();
    if (t.isEmpty) return;
    AppScope.read(context).send(widget.chatKey, t, replyTo: _replyTo?.id);
    _controller.clear();
    setState(() => _replyTo = null);
  }

  void _insert(String e) {
    final t = _controller.text;
    final sel = _controller.selection;
    final start = sel.isValid ? sel.start : t.length;
    final end = sel.isValid ? sel.end : t.length;
    _controller.value = TextEditingValue(
      text: t.replaceRange(start, end, e),
      selection: TextSelection.collapsed(offset: start + e.length),
    );
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final list = s.messages[widget.chatKey] ?? const <Message>[];
    final server = s.serverOfChannel(widget.chatKey);

    return Column(
      children: [
        Expanded(
          child: list.isEmpty
              ? _EmptyChat(title: widget.title, isDm: widget.isDm)
              : ListView.builder(
                  reverse: true,
                  padding: const EdgeInsets.only(top: 12, bottom: 8),
                  itemCount: list.length,
                  itemBuilder: (ctx, i) {
                    final idx = list.length - 1 - i;
                    final msg = list[idx];
                    final prev = idx > 0 ? list[idx - 1] : null;
                    final newDay = prev == null || !sameDay(prev.time, msg.time);
                    final head = prev == null ||
                        newDay ||
                        prev.authorId != msg.authorId ||
                        msg.time.difference(prev.time).inMinutes >= 5 ||
                        msg.replyToId != null;
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        if (newDay) _DaySeparator(msg.time),
                        MessageTile(
                          msg: msg,
                          head: head,
                          chatKey: widget.chatKey,
                          server: server,
                          onReply: (m) {
                            setState(() => _replyTo = m);
                            _focus.requestFocus();
                          },
                        ),
                      ],
                    );
                  },
                ),
        ),
        if (_replyTo != null) _replyBar(s),
        _typingBar(s),
        _hints(s),
        _inputBar(),
      ],
    );
  }

  Widget _typingBar(AppState s) {
    final names = s.typingNames(widget.chatKey);
    if (names.isEmpty) return const SizedBox.shrink();
    final text = names.length == 1
        ? trf('{name} yozmoqda...', {'name': names.first})
        : tr('Bir nechta kishi yozmoqda...');
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 0, 18, 2),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Text(text,
            style: const TextStyle(
                color: NX.muted, fontSize: 12, fontStyle: FontStyle.italic)),
      ),
    );
  }

  Widget _replyBar(AppState s) {
    final r = _replyTo!;
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 0),
      padding: const EdgeInsets.fromLTRB(12, 8, 4, 8),
      decoration: const BoxDecoration(
        color: NX.side,
        borderRadius: BorderRadius.vertical(top: Radius.circular(10)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text.rich(
              TextSpan(
                children: [
                  TextSpan(
                    text: tr('Javob: '),
                    style: TextStyle(color: NX.dim),
                  ),
                  TextSpan(
                    text: s.member(r.authorId).name,
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  TextSpan(
                    text: '  ${tr(r.text)}',
                    style: const TextStyle(color: NX.muted),
                  ),
                ],
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          IconButton(
            iconSize: 18,
            visualDensity: VisualDensity.compact,
            onPressed: () => setState(() => _replyTo = null),
            icon: const Icon(Icons.close_rounded),
          ),
        ],
      ),
    );
  }

  Widget _hints(AppState s) {
    final t = _controller.text;
    if (!t.startsWith('/') || t.contains(' ')) return const SizedBox.shrink();
    final list = s.commandsFor(widget.chatKey, t.substring(1));
    if (list.isEmpty) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 6),
      constraints: const BoxConstraints(maxHeight: 190),
      decoration: BoxDecoration(
        color: NX.side,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: NX.divider),
      ),
      child: ListView(
        shrinkWrap: true,
        padding: EdgeInsets.zero,
        children: [
          for (final h in list)
            ListTile(
              dense: true,
              leading: Avatar(member: s.member(h.bot.id), size: 28),
              title: Text('/${h.cmd.name} ${tr(h.cmd.usage)}'.trim()),
              subtitle: Text(h.cmd.description),
              onTap: () {
                _controller.value = TextEditingValue(
                  text: '/${h.cmd.name} ',
                  selection: TextSelection.collapsed(
                    offset: h.cmd.name.length + 2,
                  ),
                );
                setState(() {});
                _focus.requestFocus();
              },
            ),
        ],
      ),
    );
  }

  Widget _inputBar() {
    if (!widget.canPost) {
      return Container(
        margin: const EdgeInsets.fromLTRB(12, 4, 12, 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: NX.raised,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            const Icon(Icons.lock_outline_rounded, size: 18, color: NX.dim),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                widget.lockedHint,
                style: const TextStyle(color: NX.dim),
              ),
            ),
          ],
        ),
      );
    }

    final hint = widget.isDm
        ? trf('{title} ga xabar yozing', {'title': tr(widget.title)})
        : trf('#{title} ga xabar yozing', {'title': tr(widget.title)});

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
      child: Container(
        decoration: BoxDecoration(
          color: NX.raised,
          borderRadius: _replyTo != null
              ? const BorderRadius.vertical(bottom: Radius.circular(10))
              : BorderRadius.circular(10),
        ),
        child: _recording
            ? Row(
                children: [
                  IconButton(
                    tooltip: tr('Bekor qilish'),
                    onPressed: () => _stopRec(send: false),
                    icon: const Icon(Icons.delete_rounded, color: NX.muted),
                  ),
                  const Icon(Icons.fiber_manual_record_rounded,
                      color: Colors.redAccent, size: 14),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(fmtDur(_recSecs),
                        style: const TextStyle(
                            fontWeight: FontWeight.w700, fontSize: 16)),
                  ),
                  IconButton(
                    tooltip: tr('Yuborish'),
                    onPressed: () => _stopRec(send: true),
                    icon: const Icon(Icons.send_rounded, color: NX.accent),
                  ),
                ],
              )
            : Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            IconButton(
              tooltip: tr("Biriktirish"),
              onPressed: _attachSheet,
              icon: const Icon(Icons.add_circle_rounded, color: NX.muted),
            ),
            Expanded(
              child: CallbackShortcuts(
                bindings: {
                  const SingleActivator(LogicalKeyboardKey.enter): _send,
                },
                child: TextField(
                  controller: _controller,
                  focusNode: _focus,
                  minLines: 1,
                  maxLines: 5,
                  textCapitalization: TextCapitalization.sentences,
                  onChanged: (_) {
                    setState(() {});
                    _st?.typingPing(widget.chatKey);
                  },
                  decoration: InputDecoration(
                    hintText: hint,
                    hintStyle: const TextStyle(color: NX.dim),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                ),
              ),
            ),
            IconButton(
              tooltip: tr('Emoji'),
              onPressed: _emojiSheet,
              icon: const Icon(Icons.emoji_emotions_outlined, color: NX.muted),
            ),
            _controller.text.trim().isEmpty
                ? IconButton(
                    tooltip: tr('Ovozli xabar'),
                    onPressed: _startRec,
                    icon: const Icon(Icons.mic_rounded, color: NX.accent),
                  )
                : IconButton(
                    tooltip: tr('Yuborish'),
                    onPressed: _send,
                    icon: const Icon(Icons.send_rounded, color: NX.accent),
                  ),
          ],
        ),
      ),
    );
  }

  void _emojiSheet() {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: SizedBox(
          height: 260,
          child: GridView.count(
            crossAxisCount: 8,
            padding: const EdgeInsets.all(12),
            children: [
              for (final e in _emojis)
                InkWell(
                  borderRadius: BorderRadius.circular(8),
                  onTap: () {
                    Navigator.pop(ctx);
                    _insert(e);
                  },
                  child: Center(
                    child: Text(e, style: const TextStyle(fontSize: 24)),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickFile() async {
    final s = AppScope.read(context);
    final key = widget.chatKey;
    final reply = _replyTo?.id;
    final caption = _controller.text;
    try {
      final r = await FilePicker.platform.pickFiles(withData: true);
      if (r == null || r.files.isEmpty) return;
      final f = r.files.first;
      final bytes = f.bytes;
      if (bytes == null) return;
      if (bytes.length > 20 * 1024 * 1024) {
        s.toast = tr("Fayl 20 MB dan kichik bo'lsin");
        s.notifyListeners();
        return;
      }
      _controller.clear();
      if (mounted) setState(() => _replyTo = null);
      await s.sendFile(key, bytes, f.name, caption: caption, replyTo: reply);
    } catch (e) {
      s.toast = tr("Faylni yuborib bo'lmadi");
      s.notifyListeners();
    }
  }

  Future<void> _pickImage(ImageSource src) async {
    final s = AppScope.read(context);
    final key = widget.chatKey;
    final reply = _replyTo?.id;
    final caption = _controller.text;
    try {
      final f = await ImagePicker().pickImage(
          source: src, maxWidth: 1600, maxHeight: 1600, imageQuality: 82);
      if (f == null) return;
      final bytes = await f.readAsBytes();
      final dot = f.name.lastIndexOf('.');
      final ext = dot < 0 ? 'jpg' : f.name.substring(dot + 1).toLowerCase();
      _controller.clear();
      if (mounted) setState(() => _replyTo = null);
      await s.sendImage(key, bytes, ext, caption: caption, replyTo: reply);
    } catch (e) {
      s.toast = tr('Rasm yuborib bo\'lmadi');
      s.notifyListeners();
    }
  }

  void _attachSheet() {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.image_outlined),
              title: Text(tr('Galereyadan rasm')),
              onTap: () {
                Navigator.pop(ctx);
                _pickImage(ImageSource.gallery);
              },
            ),
            ListTile(
              leading: const Icon(Icons.attach_file_rounded),
              title: Text(tr('Fayl yuborish')),
              onTap: () {
                Navigator.pop(ctx);
                _pickFile();
              },
            ),
            ListTile(
              leading: const Icon(Icons.poll_outlined),
              title: Text(tr("So'rovnoma")),
              onTap: () {
                Navigator.pop(ctx);
                showPollDialog(context, widget.chatKey);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: Text(tr('Kameradan rasm')),
              onTap: () {
                Navigator.pop(ctx);
                _pickImage(ImageSource.camera);
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyChat extends StatelessWidget {
  const _EmptyChat({required this.title, required this.isDm});
  final String title;
  final bool isDm;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(isDm ? Icons.waving_hand_rounded : Icons.tag, size: 48, color: NX.dim),
            const SizedBox(height: 12),
            Text(
              isDm ? trf('{title} bilan suhbat', {'title': tr(title)}) : trf('#{title} ga xush kelibsiz!', {'title': tr(title)}),
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 6),
            const Text(
              'Bu yerda hali xabarlar yo\'q. Birinchi bo\'lib yozing!',
              style: TextStyle(color: NX.muted),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

class _DaySeparator extends StatelessWidget {
  const _DaySeparator(this.time);
  final DateTime time;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        children: [
          const Expanded(child: Divider(color: NX.divider)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text(
              fmtDay(time),
              style: const TextStyle(
                color: NX.dim,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const Expanded(child: Divider(color: NX.divider)),
        ],
      ),
    );
  }
}

// ------------------------------------------------------------------ Xabar

class MessageTile extends StatelessWidget {
  const MessageTile({
    super.key,
    required this.msg,
    required this.head,
    required this.chatKey,
    required this.onReply,
    this.server,
  });

  final Message msg;
  final bool head;
  final String chatKey;
  final Server? server;
  final void Function(Message) onReply;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final author = s.member(msg.authorId);
    final color = s.nameColor(msg.authorId, server);
    final reply = msg.replyToId == null ? null : s.findMessage(chatKey, msg.replyToId!);

    void actions() => showMessageActions(
          context,
          msg: msg,
          chatKey: chatKey,
          onReply: onReply,
        );

    return InkWell(
      onLongPress: actions,
      onSecondaryTap: actions,
      child: Container(
        color: msg.pinned ? NX.gold.withAlpha(20) : null,
        padding: EdgeInsets.fromLTRB(16, head ? 8 : 1, 16, 1),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 40,
              child: head
                  ? GestureDetector(
                      onTap: () => showMemberProfile(context, author.id),
                      child: Avatar(member: author, size: 40),
                    )
                  : null,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (msg.replyToId != null) _replyPreview(s, reply),
                  if (head)
                    Row(
                      children: [
                        Flexible(
                          child: GestureDetector(
                            onTap: () => showMemberProfile(context, author.id),
                            child: Text(
                              author.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: color,
                                fontWeight: FontWeight.w700,
                                fontSize: 15,
                              ),
                            ),
                          ),
                        ),
                        if (author.isBot) ...[
                          const SizedBox(width: 6),
                          const BotTag(),
                        ],
                        if (author.plan != 'free') ...[
                          const SizedBox(width: 6),
                          PlanBadge(author.plan),
                        ],
                        const SizedBox(width: 8),
                        Text(
                          '${fmtDay(msg.time)}, ${fmtTime(msg.time)}',
                          style: const TextStyle(color: NX.dim, fontSize: 11.5),
                        ),
                        if (msg.pinned) ...[
                          const SizedBox(width: 6),
                          const Icon(Icons.push_pin, size: 13, color: NX.gold),
                        ],
                      ],
                    ),
                  if (msg.imageUrl != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 4, bottom: 4),
                      child: GestureDetector(
                        onTap: () => showDialog<void>(
                          context: context,
                          builder: (_) => Dialog(
                            backgroundColor: Colors.black,
                            insetPadding: EdgeInsets.zero,
                            child: InteractiveViewer(
                              child: Image.network(msg.imageUrl!),
                            ),
                          ),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: ConstrainedBox(
                            constraints: const BoxConstraints(
                                maxWidth: 260, maxHeight: 320),
                            child: Image.network(
                              msg.imageUrl!,
                              fit: BoxFit.cover,
                              loadingBuilder: (c, w, p) => p == null
                                  ? w
                                  : const SizedBox(
                                      width: 160,
                                      height: 120,
                                      child: Center(
                                          child: CircularProgressIndicator(
                                              strokeWidth: 2))),
                              errorBuilder: (_, __, ___) => const Icon(
                                  Icons.broken_image_outlined,
                                  color: NX.dim),
                            ),
                          ),
                        ),
                      ),
                    ),
                  if (msg.poll != null) PollCard(msg: msg, chatKey: chatKey),
                  if (msg.fileUrl != null && isVoiceName(msg.fileName))
                    VoiceBubble(
                        url: msg.fileUrl!, secs: voiceSecs(msg.fileName)),
                  if (msg.fileUrl != null && !isVoiceName(msg.fileName))
                    Padding(
                      padding: const EdgeInsets.only(top: 4, bottom: 4),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(12),
                        onTap: () => launchUrl(Uri.parse(msg.fileUrl!),
                            mode: LaunchMode.externalApplication),
                        child: Container(
                          constraints: const BoxConstraints(maxWidth: 280),
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: NX.raised,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: NX.divider),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.insert_drive_file_rounded,
                                  color: NX.accent2, size: 30),
                              const SizedBox(width: 10),
                              Flexible(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(msg.fileName ?? 'file',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                            fontWeight: FontWeight.w700)),
                                    Text(_fmtSize(msg.fileSize ?? 0),
                                        style: const TextStyle(
                                            color: NX.dim, fontSize: 12)),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              const Icon(Icons.download_rounded,
                                  color: NX.muted, size: 20),
                            ],
                          ),
                        ),
                      ),
                    ),
                  if (msg.text.isNotEmpty)
                  Text.rich(
                    TextSpan(
                      children: [
                        TextSpan(text: tr(msg.text)),
                        if (msg.edited)
                          TextSpan(
                            text: tr('  (tahrirlangan)'),
                            style: TextStyle(color: NX.dim, fontSize: 11),
                          ),
                      ],
                    ),
                    style: const TextStyle(fontSize: 15, height: 1.35),
                  ),
                  if (msg.reactions.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Wrap(
                        spacing: 4,
                        runSpacing: 4,
                        children: [
                          for (final e in msg.reactions.entries)
                            _ReactionChip(
                              emoji: e.key,
                              count: e.value.length,
                              mine: e.value.contains('me'),
                              onTap: () => s.toggleReaction(chatKey, msg.id, e.key),
                            ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _replyPreview(AppState s, Message? reply) {
    final name = reply == null ? '' : s.member(reply.authorId).name;
    return Padding(
      padding: const EdgeInsets.only(bottom: 3),
      child: Row(
        children: [
          const Icon(Icons.subdirectory_arrow_right_rounded, size: 16, color: NX.dim),
          const SizedBox(width: 4),
          Flexible(
            child: Text(
              reply == null ? "Asl xabar o'chirilgan" : '$name: ${tr(reply.text)}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: NX.dim,
                fontSize: 12.5,
                fontStyle: reply == null ? FontStyle.italic : FontStyle.normal,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ReactionChip extends StatelessWidget {
  const _ReactionChip({
    required this.emoji,
    required this.count,
    required this.mine,
    required this.onTap,
  });

  final String emoji;
  final int count;
  final bool mine;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
          color: mine ? NX.accent.withAlpha(60) : NX.raised,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: mine ? NX.accent : Colors.transparent),
        ),
        child: Text(
          '$emoji $count',
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            color: mine ? Colors.white : NX.muted,
          ),
        ),
      ),
    );
  }
}

// --------------------------------------------------------- Xabar amallari

void showMessageActions(
  BuildContext context, {
  required Message msg,
  required String chatKey,
  required void Function(Message) onReply,
}) {
  final s = AppScope.read(context);
  final sv = s.serverOfChannel(chatKey);
  final isMine = msg.authorId == 'me';
  final canManage = sv != null && sv.can('me', Permission.manageMessages);
  final canPin = chatKey.startsWith('dm_') || canManage;

  showModalBottomSheet<void>(
    context: context,
    builder: (ctx) => SafeArea(
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  for (final e in const ['👍', '❤️', '😂', '🔥', '😮', '😢'])
                    InkWell(
                      borderRadius: BorderRadius.circular(20),
                      onTap: () {
                        Navigator.pop(ctx);
                        s.toggleReaction(chatKey, msg.id, e);
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(6),
                        child: Text(e, style: const TextStyle(fontSize: 28)),
                      ),
                    ),
                ],
              ),
            ),
            const Divider(height: 1),
            ListTile(
              leading: const Icon(Icons.reply_rounded),
              title: const Text('Javob yozish'),
              onTap: () {
                Navigator.pop(ctx);
                onReply(msg);
              },
            ),
            ListTile(
              leading: const Icon(Icons.forward_rounded),
              title: const Text('Boshqa chatga yuborish'),
              onTap: () {
                Navigator.pop(ctx);
                showForwardPicker(context, msg);
              },
            ),
            ListTile(
              leading: const Icon(Icons.ios_share_rounded),
              title: const Text('Ulashish'),
              onTap: () {
                Navigator.pop(ctx);
                final body = msg.text.isNotEmpty
                    ? msg.text
                    : (msg.imageUrl ?? msg.fileUrl ?? '');
                launchUrl(
                    Uri.https('t.me', '/share/url', {
                      'url': 'https://retwobehruz.github.io/media/',
                      'text': body,
                    }),
                    mode: LaunchMode.externalApplication);
              },
            ),
            ListTile(
              leading: const Icon(Icons.copy_rounded),
              title: const Text('Nusxa olish'),
              onTap: () {
                Navigator.pop(ctx);
                Clipboard.setData(ClipboardData(text: msg.text));
                snack(context, 'Nusxa olindi');
              },
            ),
            if (!isMine)
              ListTile(
                leading: const Icon(Icons.flag_outlined),
                title: const Text('Shikoyat qilish'),
                onTap: () {
                  Navigator.pop(ctx);
                  showReportDialog(context, msg.authorId, messageId: msg.id);
                },
              ),
            if (canPin)
              ListTile(
                leading: Icon(msg.pinned ? Icons.push_pin : Icons.push_pin_outlined),
                title: Text(msg.pinned ? 'Mahkamlashni bekor qilish' : 'Mahkamlash'),
                onTap: () {
                  Navigator.pop(ctx);
                  s.togglePin(chatKey, msg.id);
                },
              ),
            if (isMine)
              ListTile(
                leading: const Icon(Icons.edit_outlined),
                title: const Text('Tahrirlash'),
                onTap: () async {
                  Navigator.pop(ctx);
                  final t = await promptText(
                    context,
                    title: 'Xabarni tahrirlash',
                    initial: msg.text,
                  );
                  if (t != null) s.editMessage(chatKey, msg.id, t);
                },
              ),
            if (isMine || canManage)
              ListTile(
                leading: const Icon(Icons.delete_outline_rounded, color: NX.red),
                title: const Text("O'chirish", style: TextStyle(color: NX.red)),
                onTap: () {
                  Navigator.pop(ctx);
                  s.deleteMessage(chatKey, msg.id);
                },
              ),
          ],
        ),
      ),
    ),
  );
}

void showPollDialog(BuildContext context, String chatKey) {
  final q = TextEditingController();
  final opts = List.generate(4, (_) => TextEditingController());
  showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(tr("So'rovnoma")),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: q,
              maxLength: 150,
              decoration: InputDecoration(hintText: tr('Savol')),
            ),
            for (var i = 0; i < opts.length; i++)
              TextField(
                controller: opts[i],
                maxLength: 60,
                decoration: InputDecoration(
                    hintText: '${tr('Variant')} ${i + 1}', counterText: ''),
              ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: Text(tr('Bekor qilish')),
        ),
        FilledButton(
          onPressed: () {
            final list = [for (final c in opts) c.text];
            if (q.text.trim().isEmpty ||
                list.where((e) => e.trim().isNotEmpty).length < 2) {
              snack(context, "Savol va kamida 2 ta variant kiriting");
              return;
            }
            Navigator.pop(ctx);
            AppScope.read(context).sendPoll(chatKey, q.text, list);
          },
          child: Text(tr('Yuborish')),
        ),
      ],
    ),
  );
}

class PollCard extends StatelessWidget {
  const PollCard({super.key, required this.msg, required this.chatKey});
  final Message msg;
  final String chatKey;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final opts = [for (final o in (msg.poll!['opts'] as List)) o.toString()];
    final total = msg.votes.length;
    final mine = msg.votes['me'];
    return Container(
      constraints: const BoxConstraints(maxWidth: 320),
      margin: const EdgeInsets.only(top: 4, bottom: 4),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: NX.raised,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: NX.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('📊 ${msg.poll!['q']}',
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
          const SizedBox(height: 8),
          for (var i = 0; i < opts.length; i++)
            Builder(builder: (_) {
              final n = msg.votes.values.where((v) => v == i).length;
              final frac = total == 0 ? 0.0 : n / total;
              return Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: InkWell(
                  borderRadius: BorderRadius.circular(8),
                  onTap: () => s.votePoll(chatKey, msg, i),
                  child: Stack(
                    children: [
                      Positioned.fill(
                        child: FractionallySizedBox(
                          alignment: Alignment.centerLeft,
                          widthFactor: frac == 0 ? 0.001 : frac,
                          child: Container(
                            decoration: BoxDecoration(
                              color: (mine == i ? NX.accent : NX.accent2)
                                  .withAlpha(90),
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                              color: mine == i ? NX.accent : NX.divider),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(opts[i],
                                  style: TextStyle(
                                      fontWeight: mine == i
                                          ? FontWeight.w800
                                          : FontWeight.w500)),
                            ),
                            Text('$n',
                                style: const TextStyle(
                                    color: NX.muted, fontSize: 12)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          Text('$total ${tr('ovoz')}',
              style: const TextStyle(color: NX.dim, fontSize: 12)),
        ],
      ),
    );
  }
}

void showForwardPicker(BuildContext context, Message msg) {
  final s = AppScope.read(context);
  final dests = <MapEntry<String, String>>[
    for (final id in s.dmIds) MapEntry('dm_$id', s.member(id).name),
    for (final sv in s.servers)
      for (final c in sv.allChannels)
        if (c.type != ChannelType.voice) MapEntry(c.id, '${sv.name} / #${c.name}'),
  ];
  final body = [
    if (msg.text.isNotEmpty) msg.text,
    if (msg.imageUrl != null) msg.imageUrl!,
    if (msg.fileUrl != null) msg.fileUrl!,
  ].join('\n');
  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => SafeArea(
      child: ConstrainedBox(
        constraints:
            BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.7),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('Qayerga yuborilsin?',
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            ),
            Flexible(
              child: ListView(
                shrinkWrap: true,
                children: [
                  for (final d in dests)
                    ListTile(
                      leading: Icon(
                          d.key.startsWith('dm_')
                              ? Icons.person_rounded
                              : Icons.tag,
                          color: NX.muted),
                      title: Text(d.value,
                          maxLines: 1, overflow: TextOverflow.ellipsis),
                      onTap: () {
                        Navigator.pop(ctx);
                        s.send(d.key,
                            '↪ ${s.member(msg.authorId).name}: $body');
                        snack(context, 'Yuborildi');
                      },
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

void showChatSearch(BuildContext context, String chatKey) {
  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => _SearchSheet(chatKey: chatKey),
  );
}

class _SearchSheet extends StatefulWidget {
  const _SearchSheet({required this.chatKey});
  final String chatKey;

  @override
  State<_SearchSheet> createState() => _SearchSheetState();
}

class _SearchSheetState extends State<_SearchSheet> {
  Timer? _t;
  List<Message> _res = [];
  bool _busy = false;
  bool _done = false;

  void _onChanged(String q) {
    _t?.cancel();
    if (q.trim().isEmpty) {
      setState(() {
        _res = [];
        _done = false;
      });
      return;
    }
    _t = Timer(const Duration(milliseconds: 400), () async {
      setState(() => _busy = true);
      final r = await AppScope.read(context).searchMessages(widget.chatKey, q);
      if (!mounted) return;
      setState(() {
        _res = r;
        _busy = false;
        _done = true;
      });
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.read(context);
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(
              maxHeight: MediaQuery.of(context).size.height * 0.75),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: TextField(
                  autofocus: true,
                  onChanged: _onChanged,
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.search_rounded),
                    hintText: tr('Xabarlarni qidirish'),
                  ),
                ),
              ),
              if (_busy) const LinearProgressIndicator(minHeight: 2),
              if (_done && _res.isEmpty)
                Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text('Hech narsa topilmadi',
                      style: const TextStyle(color: NX.muted)),
                ),
              Flexible(
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    for (final m in _res)
                      ListTile(
                        leading: Avatar(member: s.member(m.authorId), size: 36),
                        title: Text(s.member(m.authorId).name),
                        subtitle: Text(m.text.isNotEmpty ? m.text : '📎',
                            maxLines: 3, overflow: TextOverflow.ellipsis),
                        trailing: Text(
                            '${m.time.day.toString().padLeft(2, '0')}.${m.time.month.toString().padLeft(2, '0')}',
                            style:
                                const TextStyle(color: NX.dim, fontSize: 12)),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

void showPinned(BuildContext context, String chatKey) {
  final s = AppScope.read(context);
  final pins = (s.messages[chatKey] ?? const <Message>[]).where((m) => m.pinned).toList();
  showModalBottomSheet<void>(
    context: context,
    builder: (ctx) => SafeArea(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxHeight: 420),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'Mahkamlangan xabarlar',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
              ),
            ),
            if (pins.isEmpty)
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 0, 16, 24),
                child: Text(
                  "Hozircha mahkamlangan xabar yo'q.\nXabarni bosib turing va «Mahkamlash» ni tanlang.",
                  textAlign: TextAlign.center,
                  style: TextStyle(color: NX.muted),
                ),
              )
            else
              Flexible(
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    for (final m in pins)
                      ListTile(
                        leading: Avatar(member: s.member(m.authorId), size: 36),
                        title: Text(s.member(m.authorId).name),
                        subtitle: Text(m.text, maxLines: 4, overflow: TextOverflow.ellipsis),
                      ),
                  ],
                ),
              ),
          ],
        ),
      ),
    ),
  );
}

String _fmtSize(int b) {
  if (b >= 1024 * 1024) return '${(b / 1024 / 1024).toStringAsFixed(1)} MB';
  if (b >= 1024) return '${(b / 1024).toStringAsFixed(0)} KB';
  return '$b B';
}
