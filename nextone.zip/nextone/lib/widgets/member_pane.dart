import 'package:flutter/material.dart' hide Text;
import 'tr_text.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../util.dart';
import 'common.dart';

/// O'ngdagi a'zolar ro'yxati (rollar bo'yicha guruhlangan).
class MemberPane extends StatelessWidget {
  const MemberPane({super.key, this.onNavigate});

  final VoidCallback? onNavigate;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final server = s.server;
    if (server == null) return const SizedBox.shrink();
    final groups = s.memberGroups(server);

    return Container(
      color: NX.side,
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: 16),
          children: [
            for (final g in groups) ...[
              SectionLabel(
                '${tr(g.title)} — ${g.ids.length}',
                padding: const EdgeInsets.fromLTRB(16, 18, 16, 6),
              ),
              for (final id in g.ids)
                _MemberRow(
                  memberId: id,
                  server: server,
                  onNavigate: onNavigate,
                ),
            ],
          ],
        ),
      ),
    );
  }
}

class _MemberRow extends StatelessWidget {
  const _MemberRow({
    required this.memberId,
    required this.server,
    this.onNavigate,
  });

  final String memberId;
  final Server server;
  final VoidCallback? onNavigate;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final m = s.member(memberId);
    final offline = m.status == PresenceStatus.offline && !m.isBot;
    final color = s.nameColor(memberId, server);

    return InkWell(
      onTap: () => showMemberProfile(context, memberId, onDm: onNavigate),
      child: Opacity(
        opacity: offline ? 0.5 : 1,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
          child: Row(
            children: [
              Avatar(member: m, size: 34, showStatus: true),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            m.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: color,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        if (m.isBot) ...[
                          const SizedBox(width: 6),
                          const BotTag(),
                        ],
                      ],
                    ),
                    if (m.customStatus.isNotEmpty)
                      Text(
                        m.customStatus,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: NX.dim, fontSize: 12),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ------------------------------------------------------------ Profil oynasi

Future<void> showMemberProfile(
  BuildContext context,
  String memberId, {
  VoidCallback? onDm,
}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => _ProfileSheet(memberId: memberId, onDm: onDm),
  );
}

class _ProfileSheet extends StatelessWidget {
  const _ProfileSheet({required this.memberId, this.onDm});

  final String memberId;
  final VoidCallback? onDm;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final m = s.member(memberId);
    final server = s.server;
    final inServer = server != null && server.memberRoles.containsKey(memberId);
    final canManageRoles =
        server != null && inServer && server.can('me', Permission.manageRoles);

    final roles = <Role>[];
    if (server != null && inServer) {
      for (final r in server.roles) {
        if (r.id != 'everyone' &&
            (server.memberRoles[memberId]?.contains(r.id) ?? false)) {
          roles.add(r);
        }
      }
    }

    return SafeArea(
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Container(
                  height: 92,
                  decoration: BoxDecoration(
                    color: m.banner,
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(16),
                    ),
                  ),
                ),
                Positioned(
                  left: 16,
                  bottom: -38,
                  child: Avatar(
                    member: m,
                    size: 84,
                    showStatus: true,
                    ringColor: NX.side,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 46),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          m.name,
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      if (m.isBot) ...[
                        const SizedBox(width: 8),
                        const BotTag(),
                      ],
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(
                    m.customStatus.isEmpty
                        ? m.status.label
                        : '${tr(m.status.label)} · ${tr(m.customStatus)}',
                    style: const TextStyle(color: NX.muted),
                  ),
                  const Divider(height: 28),
                  if (m.bio.isNotEmpty) ...[
                    const _Label('HAQIDA'),
                    Text(m.bio),
                    const SizedBox(height: 14),
                  ],
                  const _Label("A'ZO BO'LGAN SANA"),
                  Text(fmtDate(m.joined)),
                  if (inServer) ...[
                    const SizedBox(height: 14),
                    const _Label('ROLLAR'),
                    if (roles.isEmpty)
                      const Text("Rol yo'q", style: TextStyle(color: NX.dim))
                    else
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: [
                          for (final r in roles)
                            Chip(
                              visualDensity: VisualDensity.compact,
                              avatar: CircleAvatar(backgroundColor: r.color, radius: 6),
                              label: Text(r.name),
                            ),
                        ],
                      ),
                  ],
                  if (canManageRoles && server != null) ...[
                    const SizedBox(height: 14),
                    const _Label('ROLLARNI BOSHQARISH'),
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: [
                        for (final r in server.roles)
                          if (r.id != 'everyone')
                            FilterChip(
                              visualDensity: VisualDensity.compact,
                              selected: server.memberRoles[memberId]?.contains(r.id) ?? false,
                              avatar: CircleAvatar(backgroundColor: r.color, radius: 6),
                              label: Text(r.name),
                              onSelected: (_) =>
                                  s.toggleMemberRole(server, memberId, r.id),
                            ),
                      ],
                    ),
                  ],
                  const SizedBox(height: 18),
                  if (memberId != 'me')
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: () {
                          Navigator.pop(context);
                          s.openDm(memberId);
                          onDm?.call();
                        },
                        icon: const Icon(Icons.chat_bubble_outline_rounded),
                        label: const Text('Xabar yozish'),
                      ),
                    ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Label extends StatelessWidget {
  const _Label(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Text(
        text,
        style: const TextStyle(
          color: NX.dim,
          fontSize: 12,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.5,
        ),
      ),
    );
  }
}
