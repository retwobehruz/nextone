import 'package:flutter/material.dart' hide Text;
import '../state.dart';
import 'tr_text.dart';

import '../models.dart';
import '../theme.dart';

/// Doira shaklidagi avatar (ixtiyoriy holat nuqtasi bilan).
class Avatar extends StatelessWidget {
  const Avatar({
    super.key,
    required this.member,
    this.size = 40,
    this.showStatus = false,
    this.ringColor = NX.side,
  });

  final Member member;
  final double size;
  final bool showStatus;
  final Color ringColor;

  @override
  Widget build(BuildContext context) {
    final avatar = Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(color: member.color, shape: BoxShape.circle),
      child: member.isBot
          ? Icon(Icons.smart_toy_rounded, size: size * 0.52, color: Colors.white)
          : (member.avatarUrl != null && member.avatarUrl!.isNotEmpty)
              ? ClipOval(
                  child: Image.network(
                    member.avatarUrl!,
                    width: size,
                    height: size,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Center(
                      child: Text(
                        member.initials,
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: size * 0.4,
                        ),
                      ),
                    ),
                  ),
                )
              : Text(
                  member.initials,
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: size * 0.4,
                  ),
                ),
    );
    if (!showStatus) return avatar;
    final dot = size * 0.38;
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          avatar,
          Positioned(
            right: -2,
            bottom: -2,
            child: Container(
              width: dot,
              height: dot,
              decoration: BoxDecoration(
                color: member.status.color,
                shape: BoxShape.circle,
                border: Border.all(color: ringColor, width: 2.5),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class BotTag extends StatelessWidget {
  const BotTag({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
      decoration: BoxDecoration(
        color: NX.accent,
        borderRadius: BorderRadius.circular(4),
      ),
      child: const Text(
        'BOT',
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w800,
          color: Colors.white,
        ),
      ),
    );
  }
}

class UnreadBadge extends StatelessWidget {
  const UnreadBadge(this.count, {super.key});
  final int count;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
      padding: const EdgeInsets.symmetric(horizontal: 5),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: NX.red,
        borderRadius: BorderRadius.circular(9),
        border: Border.all(color: NX.rail, width: 2),
      ),
      child: Text(
        count > 99 ? '99+' : '$count',
        style: const TextStyle(
          color: Colors.white,
          fontSize: 11,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class SectionLabel extends StatelessWidget {
  const SectionLabel(this.text, {super.key, this.padding});
  final String text;
  final EdgeInsetsGeometry? padding;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: padding ?? const EdgeInsets.fromLTRB(16, 16, 16, 6),
      child: Text(
        text,
        style: const TextStyle(
          color: NX.dim,
          fontSize: 12,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.5,
        ),
      ),
    );
  }
}

/// Rang tanlash uchun palitra.
class ColorPicker extends StatelessWidget {
  const ColorPicker({super.key, required this.value, required this.onChanged});
  final Color value;
  final ValueChanged<Color> onChanged;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: [
        for (final c in NX.palette)
          GestureDetector(
            onTap: () => onChanged(c),
            child: Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: c,
                shape: BoxShape.circle,
                border: Border.all(
                  color: c == value ? Colors.white : Colors.transparent,
                  width: 3,
                ),
              ),
              child: c == value
                  ? const Icon(Icons.check, size: 18, color: Colors.white)
                  : null,
            ),
          ),
      ],
    );
  }
}

Future<String?> promptText(
  BuildContext context, {
  required String title,
  String hint = '',
  String initial = '',
  String action = 'Saqlash',
}) {
  final c = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: c,
        autofocus: true,
        decoration: InputDecoration(hintText: tr(hint)),
        onSubmitted: (v) => Navigator.pop(ctx, v),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: const Text('Bekor qilish'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, c.text),
          child: Text(action),
        ),
      ],
    ),
  );
}

Future<bool> confirmDialog(
  BuildContext context, {
  required String title,
  required String body,
  String action = 'Ha',
  bool danger = false,
}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(body),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: const Text('Bekor qilish'),
        ),
        FilledButton(
          style: danger ? FilledButton.styleFrom(backgroundColor: NX.red) : null,
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(action),
        ),
      ],
    ),
  );
  return r ?? false;
}

void snack(BuildContext context, String text) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(text)));
}

/// Til tanlash: ingliz, o'zbek, rus (yangi til L10n.names ga qo'shilsa, shu yerda ham chiqadi).
class LanguagePicker extends StatelessWidget {
  const LanguagePicker({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final e in L10n.names.entries)
          ChoiceChip(
            selected: s.lang == e.key,
            label: Text(e.value),
            onSelected: (_) => s.setLang(e.key),
          ),
      ],
    );
  }
}
