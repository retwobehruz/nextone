import 'dart:async';

import 'package:flutter/foundation.dart' show debugPrint;
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart' as sb;

import 'bots.dart';
import 'l10n.dart';
import 'models.dart';
import 'supabase_config.dart';
import 'theme.dart';

/// Ilovaning umumiy holatiga (AppState) har qanday joydan kirish uchun.
class AppScope extends InheritedNotifier<AppState> {
  const AppScope({
    super.key,
    required AppState state,
    required super.child,
  }) : super(notifier: state);

  /// build ichida: holat o'zgarganda vidjet qayta chiziladi.
  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope topilmadi');
    return scope!.notifier!;
  }

  /// Tugma bosilganda va hodisalarda: qayta chizishni talab qilmaydi.
  static AppState read(BuildContext context) {
    final scope = context.getInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope topilmadi');
    return scope!.notifier!;
  }
}

class MemberGroup {
  const MemberGroup(this.title, this.ids);
  final String title;
  final List<String> ids;
}

typedef CommandHint = ({BotInfo bot, BotCommand cmd});

/// Haqiqiy onlayn holat: Supabase (Google bilan kirish, baza, real vaqt).
///
/// Eslatma: interfeys joriy foydalanuvchini doim 'me' kaliti bilan biladi.
/// Bazadagi haqiqiy id <-> 'me' o'giruvi `_k` va `_u` funksiyalarida.
class AppState extends ChangeNotifier {
  AppState() {
    _init();
  }

  sb.SupabaseClient get _db => sb.Supabase.instance.client;

  // ---------------- Ma'lumotlar ----------------
  final Map<String, Member> members = {};
  final List<Server> servers = [];
  final Map<String, List<Message>> messages = {};
  final Map<String, int> unread = {};
  final Map<String, Set<String>> voice = {};
  final List<String> dmIds = [];
  Member me = Member(id: 'me', name: '', color: NX.accent);

  // ---------------- Holat ----------------
  bool loggedIn = false;
  bool loading = true;
  String? error;
  String? toast; // oxirgi amal xatosi: interfeys bir marta ko'rsatadi
  String? myId;
  String? serverId; // null = bosh sahifa (DM)
  String? channelId;
  String? dmId;
  bool micMuted = false;
  bool deafened = false;
  bool camera = false;
  String? voiceChannelId;
  final List<String> musicQueue = [];

  final Map<String, String> _dmByOther = {}; // boshqa foydalanuvchi id -> dm id
  final Map<String, String> _dmOther = {}; // dm id -> boshqa foydalanuvchi id
  final Map<String, PresenceStatus> _pref = {};
  Set<String> _online = {};
  final Map<String, Timer> _roleTimers = {};

  StreamSubscription<sb.AuthState>? _authSub;
  sb.RealtimeChannel? _dbChannel;
  sb.RealtimeChannel? _presenceChannel;
  Timer? _reloadT;
  bool _disposed = false;

  Member get _unknown => Member(id: '?', name: tr("Noma'lum"), color: NX.dim);

  String get lang => L10n.lang;

  void setLang(String code) {
    L10n.set(code);
    notifyListeners();
  }

  // ---------------- Id o'giruvi ----------------
  String _k(String uid) => uid == myId ? 'me' : uid;
  String _u(String key) => key == 'me' ? (myId ?? key) : key;

  Color _c(dynamic v, Color fallback) =>
      v is int ? Color(0xFF000000 | (v & 0xFFFFFF)) : fallback;
  int _ci(Color c) => c.value & 0xFFFFFF;

  PresenceStatus _ps(String? s) => PresenceStatus.values.firstWhere(
        (e) => e.name == s,
        orElse: () => PresenceStatus.online,
      );

  // ---------------- Getterlar ----------------
  Server? get server => serverById(serverId);

  Channel? get channel {
    final sv = server;
    if (sv == null) return null;
    for (final ch in sv.allChannels) {
      if (ch.id == channelId) return ch;
    }
    return null;
  }

  /// Hozir ochiq turgan chat kaliti (ovozli kanal bo'lsa null).
  String? get activeKey {
    if (dmId != null) return 'dm_$dmId';
    final ch = channel;
    if (ch != null && ch.type != ChannelType.voice) return ch.id;
    return null;
  }

  Member member(String id) => members[id] ?? _unknown;

  Server? serverById(String? id) {
    if (id == null) return null;
    for (final s in servers) {
      if (s.id == id) return s;
    }
    return null;
  }

  Server? serverOfChannel(String chId) {
    for (final s in servers) {
      for (final ch in s.allChannels) {
        if (ch.id == chId) return s;
      }
    }
    return null;
  }

  int serverUnread(Server sv) {
    var n = 0;
    for (final ch in sv.allChannels) {
      n += unread[ch.id] ?? 0;
    }
    return n;
  }

  bool canPost(Channel ch, Server sv) {
    if (ch.type == ChannelType.announcement) {
      return sv.can('me', Permission.manageChannels);
    }
    return sv.can('me', Permission.sendMessages);
  }

  Color nameColor(String memberId, Server? sv) =>
      sv?.topRole(memberId)?.color ?? NX.text;

  Message? findMessage(String key, String id) {
    final list = messages[key];
    if (list == null) return null;
    for (final m in list) {
      if (m.id == id) return m;
    }
    return null;
  }

  void touch() => notifyListeners();

  void _fail(Object e) {
    debugPrint('Nextone xato: $e');
    error = _msgOf(e);
    toast = error;
    notifyListeners();
  }

  String _msgOf(Object e) {
    if (e is sb.PostgrestException) return e.message;
    if (e is sb.AuthException) return e.message;
    return e.toString();
  }

  // ---------------- Kirish / chiqish ----------------
  void _init() {
    _authSub = _db.auth.onAuthStateChange.listen((data) {
      final user = data.session?.user;
      if (user != null) {
        if (myId != user.id) _startSession(user.id);
      } else if (loggedIn || myId != null) {
        _clear();
      } else if (loading) {
        loading = false;
        notifyListeners();
      }
    });
    final u = _db.auth.currentUser;
    if (u != null) {
      _startSession(u.id);
    } else {
      loading = false;
    }
  }

  Future<void> signInWithGoogle() async {
    error = null;
    notifyListeners();
    try {
      await _db.auth.signInWithOAuth(
        sb.OAuthProvider.google,
        redirectTo: kAuthRedirect,
      );
    } catch (e) {
      _fail(e);
    }
  }

  Future<void> _startSession(String uid) async {
    myId = uid;
    loading = true;
    error = null;
    notifyListeners();
    try {
      await _loadMe();
      await _loadServers();
      await _loadDms();
      _subscribe();
      loggedIn = true;
      if (servers.isNotEmpty) {
        selectServer(servers.first.id);
      } else {
        selectHome();
      }
    } catch (e) {
      debugPrint('Nextone kirish xatosi: $e');
      error = _msgOf(e);
    }
    loading = false;
    notifyListeners();
  }

  Future<void> logout() async {
    leaveVoice();
    try {
      await _db.auth.signOut();
    } catch (e) {
      debugPrint('$e');
    }
    _clear();
  }

  void _clear() {
    _unsubscribe();
    loggedIn = false;
    loading = false;
    myId = null;
    serverId = null;
    channelId = null;
    dmId = null;
    voiceChannelId = null;
    members.clear();
    servers.clear();
    messages.clear();
    unread.clear();
    voice.clear();
    dmIds.clear();
    _dmByOther.clear();
    _dmOther.clear();
    _pref.clear();
    _online = {};
    notifyListeners();
  }

  // ---------------- Yuklash ----------------
  Member _memberFrom(Map<String, dynamic> p) {
    final uid = p['id'] as String;
    final m = Member(
      id: _k(uid),
      name: (p['display_name'] as String?) ?? 'User',
      color: _c(p['color'], NX.accent),
      customStatus: (p['custom_status'] as String?) ?? '',
      bio: (p['bio'] as String?) ?? '',
      banner: _c(p['banner'], NX.accent),
      avatarUrl: p['avatar_url'] as String?,
      status: PresenceStatus.offline,
    );
    _pref[uid] = _ps(p['status'] as String?);
    if (uid == myId) m.status = _pref[uid]!;
    return m;
  }

  Future<void> _loadMe() async {
    var row = await _db.from('profiles').select().eq('id', myId!).maybeSingle();
    if (row == null) {
      final u = _db.auth.currentUser;
      final meta = u?.userMetadata ?? {};
      final name = (meta['full_name'] ?? meta['name'] ?? 'User').toString();
      await _db.from('profiles').upsert({
        'id': myId,
        'display_name': name,
        'avatar_url': meta['avatar_url'],
      });
      row = await _db.from('profiles').select().eq('id', myId!).single();
    }
    me = _memberFrom(row);
    members['me'] = me;
  }

  Future<void> _ensureProfiles(Iterable<String> uids) async {
    final missing = [
      for (final u in uids)
        if (!members.containsKey(_k(u))) u,
    ];
    if (missing.isEmpty) return;
    final rows = await _db.from('profiles').select().inFilter('id', missing);
    for (final r in rows) {
      final m = _memberFrom(r);
      members[m.id] = m;
    }
    _applyPresence();
  }

  Future<void> _loadServers() async {
    final svRows = await _db.from('servers').select();
    final chRows = await _db.from('channels').select().order('position');
    final roRows = await _db.from('roles').select().order('position');
    final smRows = await _db.from('server_members').select();
    final mrRows = await _db.from('member_roles').select();

    await _ensureProfiles([for (final r in smRows) r['user_id'] as String]);

    final list = <Server>[];
    for (final r in svRows) {
      final id = r['id'] as String;

      final cats = <Category>[];
      for (final c in chRows) {
        if (c['server_id'] != id) continue;
        final catName = (c['category'] as String?) ?? 'KANALLAR';
        Category? cat;
        for (final x in cats) {
          if (x.name == catName) cat = x;
        }
        if (cat == null) {
          cat = Category(id: '$id/$catName', name: catName);
          cats.add(cat);
        }
        cat.channels.add(
          Channel(
            id: c['id'] as String,
            name: c['name'] as String,
            type: _chType(c['type'] as String?),
            topic: (c['topic'] as String?) ?? '',
          ),
        );
      }

      final roles = <Role>[
        for (final ro in roRows)
          if (ro['server_id'] == id)
            Role(
              id: ro['id'] as String,
              name: ro['name'] as String,
              color: _c(ro['color'], NX.muted),
              hoist: ro['hoist'] == true,
              permissions: _perms(ro['permissions']),
            ),
        Role(
          id: 'everyone',
          name: '@everyone',
          color: NX.muted,
          permissions: _perms(r['everyone_permissions']),
        ),
      ];

      final sv = Server(
        id: id,
        name: r['name'] as String,
        color: _c(r['color'], NX.accent),
        ownerId: _k(r['owner_id'] as String),
        description: (r['description'] as String?) ?? '',
        roles: roles,
        categories: cats,
      );
      sv.inviteCode = (r['invite_code'] as String?) ?? '';
      for (final m in smRows) {
        if (m['server_id'] == id) {
          sv.memberRoles[_k(m['user_id'] as String)] = <String>{};
        }
      }
      for (final m in mrRows) {
        if (m['server_id'] == id) {
          sv.memberRoles
              .putIfAbsent(_k(m['user_id'] as String), () => <String>{})
              .add(m['role_id'] as String);
        }
      }
      list.add(sv);
    }
    servers
      ..clear()
      ..addAll(list);

    if (serverId != null && serverById(serverId) == null) {
      serverId = null;
      channelId = null;
    }
    final sv = server;
    if (sv != null && channel == null) {
      final first = _firstText(sv);
      channelId = first?.id;
      if (first != null) loadMessages(first.id);
    }
  }

  Future<void> _loadDms() async {
    final rows = await _db.from('dms').select();
    final others = <String>[];
    for (final r in rows) {
      final a = r['user_a'] as String;
      final b = r['user_b'] as String;
      final other = a == myId ? b : a;
      _dmByOther[other] = r['id'] as String;
      _dmOther[r['id'] as String] = other;
      others.add(other);
    }
    await _ensureProfiles(others);
    for (final o in others) {
      if (!dmIds.contains(o)) dmIds.add(o);
    }
  }

  ChannelType _chType(String? t) {
    switch (t) {
      case 'voice':
        return ChannelType.voice;
      case 'announcement':
        return ChannelType.announcement;
      default:
        return ChannelType.text;
    }
  }

  Set<Permission> _perms(dynamic v) {
    final out = <Permission>{};
    if (v is List) {
      for (final x in v) {
        for (final p in Permission.values) {
          if (p.name == x) out.add(p);
        }
      }
    }
    return out;
  }

  Channel? _firstText(Server sv) {
    for (final ch in sv.allChannels) {
      if (ch.type != ChannelType.voice) return ch;
    }
    return null;
  }

  // ---------------- Real vaqt ----------------
  void _subscribe() {
    _unsubscribe();
    final ch = _db.channel('nextone-db');
    void pg(String table, void Function(sb.PostgresChangePayload) cb) {
      ch.onPostgresChanges(
        event: sb.PostgresChangeEvent.all,
        schema: 'public',
        table: table,
        callback: cb,
      );
    }

    pg('messages', _onMessage);
    pg('reactions', _onReaction);
    pg('profiles', _onProfile);
    pg('dms', (_) async {
      await _loadDms();
      notifyListeners();
    });
    for (final t in const [
      'servers',
      'channels',
      'roles',
      'member_roles',
      'server_members',
    ]) {
      pg(t, (_) => _scheduleReload());
    }
    ch.subscribe();
    _dbChannel = ch;

    final pc = _db.channel(
      'presence-global',
      opts: sb.RealtimeChannelConfig(key: myId ?? ''),
    );
    pc.onPresenceSync((_) {
      final ids = <String>{};
      for (final st in pc.presenceState()) {
        ids.add(st.key);
      }
      _online = ids;
      _applyPresence();
      notifyListeners();
    });
    pc.subscribe((status, [err]) async {
      if (status == sb.RealtimeSubscribeStatus.subscribed) {
        await pc.track({'at': DateTime.now().toIso8601String()});
      }
    });
    _presenceChannel = pc;
  }

  void _unsubscribe() {
    _reloadT?.cancel();
    final a = _dbChannel;
    final b = _presenceChannel;
    _dbChannel = null;
    _presenceChannel = null;
    try {
      if (a != null) _db.removeChannel(a);
      if (b != null) _db.removeChannel(b);
    } catch (e) {
      debugPrint('$e');
    }
  }

  void _applyPresence() {
    for (final e in members.entries) {
      if (e.key == 'me') continue;
      final uid = _u(e.key);
      final pref = _pref[uid] ?? PresenceStatus.online;
      e.value.status = (_online.contains(uid) && pref != PresenceStatus.offline)
          ? pref
          : PresenceStatus.offline;
    }
  }

  void _scheduleReload() {
    _reloadT?.cancel();
    _reloadT = Timer(const Duration(milliseconds: 600), () async {
      if (_disposed || myId == null) return;
      if (_roleTimers.isNotEmpty) {
        _scheduleReload();
        return;
      }
      try {
        await _loadServers();
        _applyPresence();
        notifyListeners();
      } catch (e) {
        debugPrint('$e');
      }
    });
  }

  void _onProfile(sb.PostgresChangePayload p) {
    final r = p.newRecord;
    if (r.isEmpty) return;
    final uid = r['id'] as String?;
    if (uid == null || uid == myId) return;
    final k = _k(uid);
    final m = members[k];
    if (m == null) return;
    m.name = (r['display_name'] as String?) ?? m.name;
    m.bio = (r['bio'] as String?) ?? '';
    m.customStatus = (r['custom_status'] as String?) ?? '';
    m.color = _c(r['color'], m.color);
    m.banner = _c(r['banner'], m.banner);
    m.avatarUrl = r['avatar_url'] as String?;
    _pref[uid] = _ps(r['status'] as String?);
    _applyPresence();
    notifyListeners();
  }

  // ---------------- Navigatsiya ----------------
  void selectHome() {
    serverId = null;
    channelId = null;
    if (dmId == null && dmIds.isNotEmpty) dmId = dmIds.first;
    if (dmId != null) {
      unread.remove('dm_$dmId');
      loadMessages('dm_$dmId');
    }
    notifyListeners();
  }

  void selectServer(String id) {
    final sv = serverById(id);
    if (sv == null) return;
    serverId = id;
    dmId = null;
    final first = _firstText(sv);
    channelId = first?.id;
    if (first != null) {
      unread.remove(first.id);
      loadMessages(first.id);
    }
    notifyListeners();
  }

  void selectChannel(String id) {
    channelId = id;
    dmId = null;
    unread.remove(id);
    loadMessages(id);
    notifyListeners();
  }

  Future<void> openDm(String memberId) async {
    serverId = null;
    channelId = null;
    dmId = memberId;
    if (!dmIds.contains(memberId)) dmIds.insert(0, memberId);
    unread.remove('dm_$memberId');
    notifyListeners();
    try {
      await _ensureDm(memberId);
      await loadMessages('dm_$memberId');
    } catch (e) {
      _fail(e);
    }
  }

  Future<String> _ensureDm(String memberKey) async {
    final other = _u(memberKey);
    final known = _dmByOther[other];
    if (known != null) return known;
    final id = await _db.rpc('open_dm', params: {'p_other': other}) as String;
    _dmByOther[other] = id;
    _dmOther[id] = other;
    return id;
  }

  // ---------------- Xabarlar ----------------
  Message _msg(Map<String, dynamic> r) {
    final m = Message(
      id: r['id'] as String,
      authorId: _k(r['author_id'] as String),
      text: r['content'] as String,
      time: DateTime.parse(r['created_at'] as String).toLocal(),
      replyToId: r['reply_to'] as String?,
    );
    m.edited = r['edited'] == true;
    m.pinned = r['pinned'] == true;
    final rx = r['reactions'];
    if (rx is List) {
      for (final e in rx) {
        m.reactions
            .putIfAbsent(e['emoji'] as String, () => <String>{})
            .add(_k(e['user_id'] as String));
      }
    }
    return m;
  }

  void _addMsg(String key, Message msg) {
    final list = messages.putIfAbsent(key, () => []);
    if (list.any((m) => m.id == msg.id)) return;
    list.add(msg);
    list.sort((a, b) => a.time.compareTo(b.time));
  }

  /// Chatning oxirgi xabarlarini bazadan yuklaydi.
  Future<void> loadMessages(String key) async {
    try {
      final isDm = key.startsWith('dm_');
      final col = isDm ? 'dm_id' : 'channel_id';
      String id = key;
      if (isDm) {
        id = await _ensureDm(key.substring(3));
      } else {
        final sv = serverOfChannel(key);
        final ch = sv?.allChannels.where((c) => c.id == key).toList();
        if (ch == null || ch.isEmpty || ch.first.type == ChannelType.voice) {
          return;
        }
      }
      final rows = await _db
          .from('messages')
          .select('*, reactions(user_id, emoji)')
          .eq(col, id)
          .order('created_at', ascending: false)
          .limit(80);
      await _ensureProfiles([for (final r in rows) r['author_id'] as String]);
      final list = [for (final r in rows) _msg(r)];
      list.sort((a, b) => a.time.compareTo(b.time));
      messages[key] = list;
      notifyListeners();
    } catch (e) {
      debugPrint('loadMessages: $e');
    }
  }

  Future<void> send(String key, String text, {String? replyTo}) async {
    final t = text.trim();
    if (t.isEmpty || myId == null) return;
    try {
      final isDm = key.startsWith('dm_');
      final row = <String, dynamic>{
        'author_id': myId,
        'content': t,
        if (replyTo != null) 'reply_to': replyTo,
      };
      if (isDm) {
        row['dm_id'] = await _ensureDm(key.substring(3));
      } else {
        row['channel_id'] = key;
      }
      final r = await _db.from('messages').insert(row).select().single();
      _addMsg(key, _msg(r));
      notifyListeners();
    } catch (e) {
      _fail(e);
    }
  }

  Future<void> toggleReaction(String key, String msgId, String emoji) async {
    final m = findMessage(key, msgId);
    if (m == null || myId == null) return;
    final set = m.reactions.putIfAbsent(emoji, () => <String>{});
    final had = set.contains('me');
    if (had) {
      set.remove('me');
      if (set.isEmpty) m.reactions.remove(emoji);
    } else {
      set.add('me');
    }
    notifyListeners();
    try {
      if (had) {
        await _db
            .from('reactions')
            .delete()
            .eq('message_id', msgId)
            .eq('user_id', myId!)
            .eq('emoji', emoji);
      } else {
        await _db.from('reactions').insert({
          'message_id': msgId,
          'user_id': myId,
          'emoji': emoji,
        });
      }
    } catch (e) {
      _fail(e);
    }
  }

  Future<void> deleteMessage(String key, String msgId) async {
    messages[key]?.removeWhere((m) => m.id == msgId);
    notifyListeners();
    try {
      await _db.from('messages').delete().eq('id', msgId);
    } catch (e) {
      _fail(e);
    }
  }

  Future<void> editMessage(String key, String msgId, String text) async {
    final m = findMessage(key, msgId);
    final t = text.trim();
    if (m == null || t.isEmpty) return;
    m.text = t;
    m.edited = true;
    notifyListeners();
    try {
      await _db
          .from('messages')
          .update({'content': t, 'edited': true}).eq('id', msgId);
    } catch (e) {
      _fail(e);
    }
  }

  Future<void> togglePin(String key, String msgId) async {
    final m = findMessage(key, msgId);
    if (m == null) return;
    m.pinned = !m.pinned;
    notifyListeners();
    try {
      await _db.from('messages').update({'pinned': m.pinned}).eq('id', msgId);
    } catch (e) {
      _fail(e);
    }
  }

  String? _msgKey(Map<String, dynamic> r) {
    final ch = r['channel_id'] as String?;
    if (ch != null) return ch;
    final dm = r['dm_id'] as String?;
    if (dm == null) return null;
    final other = _dmOther[dm];
    return other == null ? null : 'dm_$other';
  }

  void _onMessage(sb.PostgresChangePayload p) {
    switch (p.eventType) {
      case sb.PostgresChangeEvent.insert:
        _onMsgInsert(p.newRecord);
        break;
      case sb.PostgresChangeEvent.update:
        _onMsgUpdate(p.newRecord);
        break;
      case sb.PostgresChangeEvent.delete:
        final id = p.oldRecord['id'];
        if (id != null) {
          for (final l in messages.values) {
            l.removeWhere((m) => m.id == id);
          }
          notifyListeners();
        }
        break;
      default:
        break;
    }
  }

  Future<void> _onMsgInsert(Map<String, dynamic> r) async {
    try {
      var key = _msgKey(r);
      if (key == null && r['dm_id'] != null) {
        await _loadDms();
        key = _msgKey(r);
      }
      if (key == null) return;
      final authorUid = r['author_id'] as String;
      if (messages[key] != null) {
        await _ensureProfiles([authorUid]);
        _addMsg(key, _msg(r));
      }
      if (authorUid != myId && activeKey != key) {
        unread[key] = (unread[key] ?? 0) + 1;
      }
      notifyListeners();
    } catch (e) {
      debugPrint('$e');
    }
  }

  void _onMsgUpdate(Map<String, dynamic> r) {
    final key = _msgKey(r);
    if (key == null) return;
    final m = findMessage(key, r['id'] as String);
    if (m == null) return;
    m.text = (r['content'] as String?) ?? m.text;
    m.edited = r['edited'] == true;
    m.pinned = r['pinned'] == true;
    notifyListeners();
  }

  void _onReaction(sb.PostgresChangePayload p) {
    final isDel = p.eventType == sb.PostgresChangeEvent.delete;
    final r = isDel ? p.oldRecord : p.newRecord;
    final mid = r['message_id'];
    final emoji = r['emoji'] as String?;
    final uid = r['user_id'] as String?;
    if (mid == null || emoji == null || uid == null) return;
    final who = _k(uid);
    for (final l in messages.values) {
      for (final m in l) {
        if (m.id != mid) continue;
        if (isDel) {
          m.reactions[emoji]?.remove(who);
          if (m.reactions[emoji]?.isEmpty ?? false) m.reactions.remove(emoji);
        } else {
          m.reactions.putIfAbsent(emoji, () => <String>{}).add(who);
        }
        notifyListeners();
        return;
      }
    }
  }

  // ---------------- Botlar (haqiqiy versiyada yo'q) ----------------
  List<BotInfo> botsFor(String key) => const [];
  List<CommandHint> commandsFor(String key, String prefix) => const [];
  void addBot(Server sv, String botId) {}
  void removeBot(Server sv, String botId) {}

  // ---------------- Serverlar va kanallar ----------------
  Future<void> createServer(String name) async {
    try {
      final color = NX.palette[servers.length % NX.palette.length];
      final id = await _db.rpc(
        'create_server',
        params: {'p_name': name, 'p_color': _ci(color)},
      ) as String;
      await _loadServers();
      selectServer(id);
    } catch (e) {
      _fail(e);
    }
  }

  /// Taklif kodi bilan qo'shiladi. Xato bo'lsa matnini qaytaradi.
  Future<String?> joinServer(String code) async {
    final c = code.trim();
    if (c.isEmpty) return 'Kod kiriting';
    try {
      final id = await _db.rpc('join_server', params: {'p_code': c}) as String;
      await _loadServers();
      selectServer(id);
      return null;
    } catch (e) {
      return _msgOf(e);
    }
  }

  Future<void> removeServer(Server sv) async {
    if (voiceChannelId != null &&
        sv.allChannels.any((c) => c.id == voiceChannelId)) {
      leaveVoice();
    }
    try {
      if (sv.ownerId == 'me') {
        await _db.from('servers').delete().eq('id', sv.id);
      } else {
        await _db
            .from('server_members')
            .delete()
            .eq('server_id', sv.id)
            .eq('user_id', myId!);
      }
      for (final ch in sv.allChannels) {
        messages.remove(ch.id);
        unread.remove(ch.id);
        voice.remove(ch.id);
      }
      servers.removeWhere((s) => s.id == sv.id);
      if (serverId == sv.id) {
        if (servers.isNotEmpty) {
          selectServer(servers.first.id);
        } else {
          selectHome();
        }
      } else {
        notifyListeners();
      }
    } catch (e) {
      _fail(e);
    }
  }

  Future<void> createChannel(
    Server sv,
    String rawName,
    ChannelType type, {
    Category? category,
  }) async {
    final trimmed = rawName.trim();
    if (trimmed.isEmpty) return;
    final name = type == ChannelType.voice
        ? trimmed
        : trimmed.toLowerCase().replaceAll(RegExp(r'\s+'), '-');
    final cat = category?.name ??
        (type == ChannelType.voice ? 'OVOZLI KANALLAR' : 'MATN KANALLARI');
    try {
      final r = await _db
          .from('channels')
          .insert({
            'server_id': sv.id,
            'name': name,
            'type': type.name,
            'category': cat,
            'position': sv.allChannels.length,
          })
          .select()
          .single();
      await _loadServers();
      if (type != ChannelType.voice && serverId == sv.id) {
        selectChannel(r['id'] as String);
      } else {
        notifyListeners();
      }
    } catch (e) {
      _fail(e);
    }
  }

  Future<void> deleteChannel(Server sv, Channel ch) async {
    try {
      await _db.from('channels').delete().eq('id', ch.id);
      messages.remove(ch.id);
      unread.remove(ch.id);
      voice.remove(ch.id);
      if (voiceChannelId == ch.id) voiceChannelId = null;
      if (channelId == ch.id) channelId = null;
      await _loadServers();
      notifyListeners();
    } catch (e) {
      _fail(e);
    }
  }

  // ---------------- Rollar ----------------
  Future<Role?> createRole(Server sv, String name) async {
    try {
      final color = NX.palette[sv.roles.length % NX.palette.length];
      final r = await _db
          .from('roles')
          .insert({
            'server_id': sv.id,
            'name': name,
            'color': _ci(color),
            'position': sv.roles.length,
          })
          .select()
          .single();
      final role = Role(
        id: r['id'] as String,
        name: name,
        color: color,
        permissions: _perms(r['permissions']),
      );
      final idx = sv.roles.indexWhere((x) => x.id == 'everyone');
      sv.roles.insert(idx < 0 ? sv.roles.length : idx, role);
      notifyListeners();
      return role;
    } catch (e) {
      _fail(e);
      return null;
    }
  }

  /// Rol o'zgarishlarini (nomi, rangi, ruxsatlari) biroz kutib, bazaga yozadi.
  void saveRole(Server sv, Role r) {
    notifyListeners();
    _roleTimers[r.id]?.cancel();
    _roleTimers[r.id] = Timer(const Duration(milliseconds: 500), () async {
      _roleTimers.remove(r.id);
      try {
        final perms = [for (final p in r.permissions) p.name];
        if (r.id == 'everyone') {
          await _db
              .from('servers')
              .update({'everyone_permissions': perms}).eq('id', sv.id);
        } else {
          await _db.from('roles').update({
            'name': r.name,
            'color': _ci(r.color),
            'hoist': r.hoist,
            'permissions': perms,
          }).eq('id', r.id);
        }
      } catch (e) {
        _fail(e);
      }
    });
  }

  Future<void> deleteRole(Server sv, Role r) async {
    if (r.id == 'everyone') return;
    sv.roles.remove(r);
    for (final set in sv.memberRoles.values) {
      set.remove(r.id);
    }
    notifyListeners();
    try {
      await _db.from('roles').delete().eq('id', r.id);
    } catch (e) {
      _fail(e);
    }
  }

  Future<void> reorderRoles(Server sv, int oldIndex, int newIndex) async {
    final list = sv.roles.where((r) => r.id != 'everyone').toList();
    if (oldIndex < 0 || oldIndex >= list.length) return;
    final item = list.removeAt(oldIndex);
    final target = newIndex.clamp(0, list.length).toInt();
    list.insert(target, item);
    final every = sv.everyone;
    sv.roles
      ..clear()
      ..addAll(list)
      ..add(every);
    notifyListeners();
    try {
      for (var i = 0; i < list.length; i++) {
        await _db.from('roles').update({'position': i}).eq('id', list[i].id);
      }
    } catch (e) {
      _fail(e);
    }
  }

  Future<void> toggleMemberRole(
    Server sv,
    String memberId,
    String roleId,
  ) async {
    final set = sv.memberRoles.putIfAbsent(memberId, () => <String>{});
    final had = set.contains(roleId);
    if (had) {
      set.remove(roleId);
    } else {
      set.add(roleId);
    }
    notifyListeners();
    try {
      if (had) {
        await _db
            .from('member_roles')
            .delete()
            .eq('role_id', roleId)
            .eq('user_id', _u(memberId));
      } else {
        await _db.from('member_roles').insert({
          'server_id': sv.id,
          'user_id': _u(memberId),
          'role_id': roleId,
        });
      }
    } catch (e) {
      _fail(e);
    }
  }

  // ---------------- Ovoz (hozircha faqat interfeys) ----------------
  void joinVoice(String chId) {
    if (voiceChannelId != null) voice[voiceChannelId!]?.remove('me');
    voice.putIfAbsent(chId, () => <String>{}).add('me');
    voiceChannelId = chId;
    channelId = chId;
    dmId = null;
    notifyListeners();
  }

  void leaveVoice() {
    if (voiceChannelId != null) voice[voiceChannelId!]?.remove('me');
    voiceChannelId = null;
    notifyListeners();
  }

  void toggleMic() {
    micMuted = !micMuted;
    if (!micMuted) deafened = false;
    notifyListeners();
  }

  void toggleDeafen() {
    deafened = !deafened;
    if (deafened) micMuted = true;
    notifyListeners();
  }

  void toggleCamera() {
    camera = !camera;
    notifyListeners();
  }

  // ---------------- Profil ----------------
  Future<void> updateProfile({
    String? name,
    String? bio,
    String? customStatus,
    PresenceStatus? status,
    Color? color,
    Color? banner,
  }) async {
    if (name != null && name.trim().isNotEmpty) me.name = name.trim();
    if (bio != null) me.bio = bio.trim();
    if (customStatus != null) me.customStatus = customStatus.trim();
    if (status != null) {
      me.status = status;
      if (myId != null) _pref[myId!] = status;
    }
    if (color != null) me.color = color;
    if (banner != null) me.banner = banner;
    notifyListeners();
    try {
      await _db.from('profiles').update({
        'display_name': me.name,
        'bio': me.bio,
        'custom_status': me.customStatus,
        'status': me.status.name,
        'color': _ci(me.color),
        'banner': _ci(me.banner),
        'lang': L10n.lang,
      }).eq('id', myId!);
    } catch (e) {
      _fail(e);
    }
  }

  // ---------------- A'zolar guruhlari ----------------
  List<MemberGroup> memberGroups(Server sv) {
    bool isBot(String id) => members[id]?.isBot ?? false;
    bool online(String id) =>
        (members[id]?.status ?? PresenceStatus.offline) !=
        PresenceStatus.offline;

    final placed = <String>{};
    final groups = <MemberGroup>[];

    for (final r in sv.roles) {
      if (!r.hoist || r.id == 'everyone') continue;
      final ids = <String>[];
      for (final e in sv.memberRoles.entries) {
        if (e.value.contains(r.id) &&
            !placed.contains(e.key) &&
            !isBot(e.key) &&
            online(e.key)) {
          ids.add(e.key);
        }
      }
      if (ids.isNotEmpty) {
        placed.addAll(ids);
        groups.add(MemberGroup(tr(r.name).toUpperCase(), ids));
      }
    }

    final onlineRest = [
      for (final id in sv.memberRoles.keys)
        if (!placed.contains(id) && !isBot(id) && online(id)) id,
    ];
    final offline = [
      for (final id in sv.memberRoles.keys)
        if (!isBot(id) && !online(id)) id,
    ];
    if (onlineRest.isNotEmpty) groups.add(MemberGroup('ONLAYN', onlineRest));
    if (offline.isNotEmpty) groups.add(MemberGroup('OFLAYN', offline));
    return groups;
  }

  @override
  void dispose() {
    _disposed = true;
    _authSub?.cancel();
    _unsubscribe();
    for (final t in _roleTimers.values) {
      t.cancel();
    }
    super.dispose();
  }
}
