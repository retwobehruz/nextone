import 'package:flutter/material.dart';

enum PresenceStatus { online, idle, dnd, offline }

extension PresenceX on PresenceStatus {
  String get label {
    switch (this) {
      case PresenceStatus.online:
        return 'Onlayn';
      case PresenceStatus.idle:
        return 'Band emas';
      case PresenceStatus.dnd:
        return 'Bezovta qilmang';
      case PresenceStatus.offline:
        return "Ko'rinmas";
    }
  }

  Color get color {
    switch (this) {
      case PresenceStatus.online:
        return const Color(0xFF23A55A);
      case PresenceStatus.idle:
        return const Color(0xFFF0B232);
      case PresenceStatus.dnd:
        return const Color(0xFFF23F43);
      case PresenceStatus.offline:
        return const Color(0xFF80848E);
    }
  }
}

enum ChannelType { text, voice, announcement }

enum Permission {
  sendMessages('Xabar yuborish'),
  manageMessages('Xabarlarni boshqarish'),
  manageChannels('Kanallarni boshqarish'),
  manageRoles('Rollarni boshqarish'),
  manageBots('Botlarni boshqarish'),
  admin('Administrator');

  const Permission(this.label);
  final String label;
}

String initialsOf(String name, {int single = 1}) {
  final parts = name
      .trim()
      .split(RegExp(r'\s+'))
      .where((p) => p.isNotEmpty)
      .toList();
  if (parts.isEmpty) return '?';
  if (parts.length == 1) {
    final p = parts.first;
    final n = single < p.length ? single : p.length;
    return p.substring(0, n).toUpperCase();
  }
  return (parts[0][0] + parts[1][0]).toUpperCase();
}

class Role {
  Role({
    required this.id,
    required this.name,
    required this.color,
    this.hoist = false,
    Set<Permission>? permissions,
  }) : permissions = permissions ?? {Permission.sendMessages};

  final String id;
  String name;
  Color color;
  bool hoist;
  Set<Permission> permissions;
}

class Member {
  Member({
    required this.id,
    required this.name,
    required this.color,
    this.isBot = false,
    this.status = PresenceStatus.online,
    this.customStatus = '',
    this.bio = '',
    DateTime? joined,
    this.banner = const Color(0xFF5865F2),
    this.avatarUrl,
    this.plan = 'free',
    this.isAdmin = false,
    this.username = '',
  }) : joined = joined ?? DateTime(2026, 1, 1);

  final String id;
  String name;
  Color color;
  final bool isBot;
  PresenceStatus status;
  String customStatus;
  String bio;
  final DateTime joined;
  Color banner;
  String? avatarUrl;
  String plan; // free | plus | prime
  bool isAdmin;
  String username;

  String get initials => initialsOf(name);
}

class Channel {
  Channel({
    required this.id,
    required this.name,
    this.type = ChannelType.text,
    this.topic = '',
  });

  final String id;
  String name;
  ChannelType type;
  String topic;
}

class Category {
  Category({required this.id, required this.name, List<Channel>? channels})
      : channels = channels ?? [];

  final String id;
  String name;
  final List<Channel> channels;
}

class Message {
  Message({
    required this.id,
    required this.authorId,
    required this.text,
    DateTime? time,
    this.replyToId,
    this.imageUrl,
  }) : time = time ?? DateTime.now();

  final String id;
  final String authorId;
  String text;
  final DateTime time;
  final String? replyToId;
  final String? imageUrl;
  bool edited = false;
  bool pinned = false;
  final Map<String, Set<String>> reactions = {};
}

class Server {
  Server({
    required this.id,
    required this.name,
    required this.color,
    required this.ownerId,
    this.description = '',
    required this.roles,
    required this.categories,
  });

  final String id;
  String name;
  Color color;
  final String ownerId;
  String description;
  String inviteCode = '';
  String? iconUrl;

  /// Rollar tartibi: tepadagisi eng yuqori. `everyone` doim oxirida.
  final List<Role> roles;
  final List<Category> categories;

  /// memberId -> unga berilgan rol idlari.
  final Map<String, Set<String>> memberRoles = {};

  String get initials => initialsOf(name, single: 2);

  Role get everyone => roles.firstWhere((r) => r.id == 'everyone');

  Set<Permission> permsOf(String memberId) {
    if (memberId == ownerId) return Permission.values.toSet();
    final p = <Permission>{};
    for (final r in roles) {
      final has = r.id == 'everyone' ||
          (memberRoles[memberId]?.contains(r.id) ?? false);
      if (has) p.addAll(r.permissions);
    }
    if (p.contains(Permission.admin)) return Permission.values.toSet();
    return p;
  }

  bool can(String memberId, Permission perm) => permsOf(memberId).contains(perm);

  Role? topRole(String memberId) {
    final mine = memberRoles[memberId];
    if (mine == null) return null;
    for (final r in roles) {
      if (r.id != 'everyone' && mine.contains(r.id)) return r;
    }
    return null;
  }

  List<Channel> get allChannels =>
      [for (final c in categories) ...c.channels];
}
