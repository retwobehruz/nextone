# Nextone

Discord-like messaging app for people from all countries (Flutter + Supabase).
English and Uzbek are the main languages; Russian is included.

## Real online version (v0.2)

- Google sign-in (browser OAuth, returns via `nextone://login-callback`)
- Real accounts, servers, channels, roles, messages, reactions, pins, edits (Supabase Postgres + RLS)
- Real-time chat and presence (Supabase Realtime)
- Create a server, invite friends with a code, join with a code
- Direct messages between real users
- Voice channels: interface only (next step)

Backend: Supabase project `nextone` (config in `lib/supabase_config.dart`). The anon key is public by design; data is protected by row level security.

## Build

GitHub Actions runs `ci/build.sh` (creates the Android project, adds INTERNET permission and the deep link, builds the APK).

## O'zbekcha

Nextone endi haqiqiy onlayn ilova: Google bilan kirish, real odamlar, real vaqtli chat, serverlar, rollar, taklif kodi va shaxsiy xabarlar.
