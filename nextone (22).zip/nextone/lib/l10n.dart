import 'dart:ui' show PlatformDispatcher;

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';

import 'l10n_strings.dart';

/// Nextone ko'p tilli: matnlar kodda o'zbekcha yoziladi (kalit sifatida),
/// boshqa tillar uchun jadval [kEn], [kRu] ... dan olinadi.
///
/// Yangi til qo'shish: `l10n_strings.dart` ga yangi jadval (masalan `kTr`)
/// qo'shing va uni [L10n.tables] hamda [L10n.names] ga yozing.
class L10n {
  L10n._();

  /// Til kodi -> ilovada ko'rinadigan nomi.
  static const names = <String, String>{
    'en': 'English',
    'uz': "O'zbekcha",
    'ru': 'Русский',
  };

  /// Tarjima jadvallari. 'uz' kerak emas: kalitlarning o'zi o'zbekcha.
  static const tables = <String, Map<String, String>>{
    'en': kEn,
    'ru': kRu,
  };

  static String lang = _detect();

  /// Til o'zgarganda ilovaning ildizini qayta chizish uchun.
  static final ValueNotifier<String> notifier = ValueNotifier<String>(lang);

  static String _detect() {
    final code = PlatformDispatcher.instance.locale.languageCode;
    return names.containsKey(code) ? code : 'en';
  }

  static void set(String code) {
    if (!names.containsKey(code) || code == lang) return;
    lang = code;
    notifier.value = code;
  }
}

/// Matnni joriy tilga tarjima qiladi. Topilmasa, kalitning o'zini qaytaradi.
String tr(String key) {
  if (L10n.lang == 'uz') return key;
  return L10n.tables[L10n.lang]?[key] ?? key;
}

/// Shablonli tarjima: `{nom}` o'rniga qiymat qo'yiladi.
String trf(String key, Map<String, Object> args) {
  var s = tr(key);
  args.forEach((k, v) => s = s.replaceAll('{$k}', '$v'));
  return s;
}

/// Til o'zgarganda `Text` vidjetlarini qayta chizadi.
class LangScope extends InheritedWidget {
  const LangScope({super.key, required this.lang, required super.child});

  final String lang;

  @override
  bool updateShouldNotify(LangScope oldWidget) => oldWidget.lang != lang;
}
