import 'package:flutter/material.dart';

import 'models.dart';

class BotCommand {
  const BotCommand(this.name, this.description, [this.usage = '']);
  final String name;
  final String description;
  final String usage;
}

class BotInfo {
  const BotInfo({
    required this.id,
    required this.name,
    required this.description,
    required this.color,
    required this.commands,
  });

  final String id;
  final String name;
  final String description;
  final Color color;
  final List<BotCommand> commands;

  Member toMember() => Member(
        id: id,
        name: name,
        color: color,
        isBot: true,
        bio: description,
        joined: DateTime(2026, 1, 1),
      );
}

/// Serverga qo'shish mumkin bo'lgan botlar katalogi.
const botCatalog = <BotInfo>[
  BotInfo(
    id: 'bot_nextbot',
    name: 'NextBot',
    description: "Asosiy yordamchi bot: o'yinlar va foydali buyruqlar.",
    color: Color(0xFF5865F2),
    commands: [
      BotCommand('help', "Barcha buyruqlar ro'yxati"),
      BotCommand('ping', 'Bot javob tezligi'),
      BotCommand('roll', 'Zar tashlash', '[son]'),
      BotCommand('coin', 'Tanga tashlash'),
      BotCommand('8ball', 'Sehrli shar', '<savol>'),
      BotCommand('time', 'Hozirgi vaqt'),
      BotCommand('about', 'Nextone haqida'),
    ],
  ),
  BotInfo(
    id: 'bot_music',
    name: 'MusicBot',
    description: "Musiqa navbatini boshqaradi (hozircha demo, ovozsiz).",
    color: Color(0xFFEB459E),
    commands: [
      BotCommand('play', "Qo'shiqni navbatga qo'shish", '<nom>'),
      BotCommand('queue', "Navbatni ko'rsatish"),
      BotCommand('skip', "Joriy qo'shiqni o'tkazish"),
      BotCommand('stop', 'Navbatni tozalash'),
    ],
  ),
  BotInfo(
    id: 'bot_mod',
    name: 'ModBot',
    description: "Moderatsiya: qoidalar va xabarlarni tozalash.",
    color: Color(0xFF3BA55D),
    commands: [
      BotCommand('rules', 'Server qoidalari'),
      BotCommand('clear', "Oxirgi xabarlarni o'chirish", '<son>'),
    ],
  ),
];

BotInfo? botById(String id) {
  for (final b in botCatalog) {
    if (b.id == id) return b;
  }
  return null;
}
