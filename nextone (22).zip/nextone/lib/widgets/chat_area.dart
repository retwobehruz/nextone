import 'package:flutter/material.dart' hide Text;
import 'tr_text.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import 'chat_page.dart';
import 'voice_view.dart';

/// O'ng tarafdagi asosiy maydon: sarlavha + chat / ovozli kanal / xush kelibsiz.
class ChatArea extends StatelessWidget {
  const ChatArea({
    super.key,
    this.onMenu,
    this.onMembers,
    this.membersOpen = false,
  });

  final VoidCallback? onMenu;
  final VoidCallback? onMembers;
  final bool membersOpen;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final server = s.server;
    final ch = s.channel;
    final dm = s.dmId == null ? null : s.members[s.dmId!];

    if (dm != null) {
      final key = 'dm_${dm.id}';
      return Column(
        children: [
          ChatHeader(
            icon: dm.isBot ? Icons.smart_toy_rounded : Icons.alternate_email,
            title: dm.name,
            subtitle: dm.customStatus.isEmpty ? dm.status.label : dm.customStatus,
            chatKey: key,
            onMenu: onMenu,
          ),
          Expanded(
            child: ChatPage(
              key: ValueKey(key),
              chatKey: key,
              title: dm.name,
              isDm: true,
            ),
          ),
        ],
      );
    }

    if (server != null && ch != null) {
      if (ch.type == ChannelType.voice) {
        return Column(
          children: [
            ChatHeader(
              icon: Icons.volume_up_rounded,
              title: ch.name,
              onMenu: onMenu,
              onMembers: onMembers,
              membersOpen: membersOpen,
            ),
            Expanded(child: VoiceView(channel: ch)),
          ],
        );
      }
      final canPost = s.canPost(ch, server);
      return Column(
        children: [
          ChatHeader(
            icon: ch.type == ChannelType.announcement
                ? Icons.campaign_rounded
                : Icons.tag,
            title: ch.name,
            subtitle: ch.topic,
            chatKey: ch.id,
            onMenu: onMenu,
            onMembers: onMembers,
            membersOpen: membersOpen,
          ),
          Expanded(
            child: ChatPage(
              key: ValueKey(ch.id),
              chatKey: ch.id,
              title: ch.name,
              canPost: canPost,
              lockedHint: ch.type == ChannelType.announcement
                  ? "Bu kanalda faqat kanal boshqaruvchilari yoza oladi"
                  : "Bu kanalga yozish uchun ruxsatingiz yo'q",
            ),
          ),
        ],
      );
    }

    return Column(
      children: [
        ChatHeader(icon: Icons.home_rounded, title: 'Nextone', onMenu: onMenu),
        const Expanded(child: _Welcome()),
      ],
    );
  }
}

class ChatHeader extends StatelessWidget {
  const ChatHeader({
    super.key,
    required this.icon,
    required this.title,
    this.subtitle = '',
    this.chatKey,
    this.onMenu,
    this.onMembers,
    this.membersOpen = false,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final String? chatKey;
  final VoidCallback? onMenu;
  final VoidCallback? onMembers;
  final bool membersOpen;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 52,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      decoration: BoxDecoration(
        color: NX.main,
        border: Border(bottom: BorderSide(color: Colors.black.withAlpha(70))),
      ),
      child: Row(
        children: [
          if (onMenu != null)
            IconButton(
              tooltip: tr('Menyu'),
              onPressed: onMenu,
              icon: const Icon(Icons.menu_rounded),
            )
          else
            const SizedBox(width: 8),
          Icon(icon, size: 22, color: NX.dim),
          const SizedBox(width: 6),
          Flexible(
            child: Text(
              title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
            ),
          ),
          if (subtitle.isNotEmpty) ...[
            Container(
              width: 1,
              height: 20,
              margin: const EdgeInsets.symmetric(horizontal: 10),
              color: NX.divider,
            ),
            Expanded(
              child: Text(
                subtitle,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: NX.dim, fontSize: 13),
              ),
            ),
          ] else
            const Spacer(),
          if (chatKey != null)
            IconButton(
              tooltip: tr('Xabarlarni qidirish'),
              onPressed: () => showChatSearch(context, chatKey!),
              icon: const Icon(Icons.search_rounded, color: NX.dim),
            ),
          if (chatKey != null)
            IconButton(
              tooltip: tr('Mahkamlangan xabarlar'),
              onPressed: () => showPinned(context, chatKey!),
              icon: const Icon(Icons.push_pin_outlined, color: NX.dim),
            ),
          if (onMembers != null)
            IconButton(
              tooltip: tr("A'zolar"),
              onPressed: onMembers,
              icon: Icon(
                Icons.people_alt_rounded,
                color: membersOpen ? NX.text : NX.dim,
              ),
            ),
        ],
      ),
    );
  }
}

class _Welcome extends StatelessWidget {
  const _Welcome();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: Image.asset('assets/icon.png', width: 96, height: 96),
            ),
            const SizedBox(height: 16),
            const Text(
              "Nextone'ga xush kelibsiz",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 8),
            const Text(
              'Chap tarafdan server yoki suhbatni tanlang.',
              textAlign: TextAlign.center,
              style: TextStyle(color: NX.muted),
            ),
          ],
        ),
      ),
    );
  }
}
