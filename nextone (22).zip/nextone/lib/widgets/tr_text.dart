import 'package:flutter/widgets.dart' hide Text;
import 'package:flutter/widgets.dart' as w show Text;

import '../l10n.dart';

export '../l10n.dart';

/// Flutter'ning `Text` o'rniga ishlatiladi: matnni joriy tilga tarjima qiladi.
/// Jadvalda topilmagan matn (masalan, foydalanuvchi yozgan xabar) o'zgarmaydi.
/// Fayllarda `import 'package:flutter/material.dart' hide Text;` yoziladi.
class Text extends StatelessWidget {
  const Text(
    this.data, {
    super.key,
    this.style,
    this.maxLines,
    this.overflow,
    this.textAlign,
  }) : span = null;

  const Text.rich(
    InlineSpan this.span, {
    super.key,
    this.style,
    this.maxLines,
    this.overflow,
    this.textAlign,
  }) : data = null;

  final String? data;
  final InlineSpan? span;
  final TextStyle? style;
  final int? maxLines;
  final TextOverflow? overflow;
  final TextAlign? textAlign;

  @override
  Widget build(BuildContext context) {
    // Til o'zgarganda qayta chizilishi uchun.
    context.dependOnInheritedWidgetOfExactType<LangScope>();
    final sp = span;
    if (sp != null) {
      return w.Text.rich(
        sp,
        style: style,
        maxLines: maxLines,
        overflow: overflow,
        textAlign: textAlign,
      );
    }
    return w.Text(
      tr(data ?? ''),
      style: style,
      maxLines: maxLines,
      overflow: overflow,
      textAlign: textAlign,
    );
  }
}
