import 'dart:async';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart' hide Text;

import '../theme.dart';
import 'tr_text.dart';

/// Ovozli xabar: fayl nomi `voice_<soniya>.m4a` ko'rinishida bo'ladi.
bool isVoiceName(String? n) =>
    n != null && n.startsWith('voice_') && n.endsWith('.m4a');

int voiceSecs(String? n) {
  if (!isVoiceName(n)) return 0;
  return int.tryParse(n!.substring(6, n.length - 4)) ?? 0;
}

String fmtDur(int s) {
  final m = s ~/ 60;
  final r = s % 60;
  return '$m:${r.toString().padLeft(2, '0')}';
}

class VoiceBubble extends StatefulWidget {
  const VoiceBubble({super.key, required this.url, required this.secs});
  final String url;
  final int secs;

  @override
  State<VoiceBubble> createState() => _VoiceBubbleState();
}

class _VoiceBubbleState extends State<VoiceBubble> {
  AudioPlayer? _p;
  final _subs = <StreamSubscription<dynamic>>[];
  bool _playing = false;
  Duration _pos = Duration.zero;
  Duration _total = Duration.zero;

  Future<void> _toggle() async {
    try {
      if (_p == null) {
        final p = AudioPlayer();
        _p = p;
        _subs.add(p.onPlayerStateChanged.listen((st) {
          if (!mounted) return;
          setState(() => _playing = st == PlayerState.playing);
        }));
        _subs.add(p.onPositionChanged.listen((d) {
          if (mounted) setState(() => _pos = d);
        }));
        _subs.add(p.onDurationChanged.listen((d) {
          if (mounted) setState(() => _total = d);
        }));
        _subs.add(p.onPlayerComplete.listen((_) {
          if (mounted) {
            setState(() {
              _playing = false;
              _pos = Duration.zero;
            });
          }
        }));
        await p.play(UrlSource(widget.url));
      } else if (_playing) {
        await _p!.pause();
      } else {
        await _p!.resume();
      }
    } catch (e) {
      debugPrint('voice: $e');
    }
  }

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    _p?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final totalMs = _total.inMilliseconds > 0
        ? _total.inMilliseconds
        : widget.secs * 1000;
    final value = totalMs > 0
        ? (_pos.inMilliseconds / totalMs).clamp(0.0, 1.0).toDouble()
        : 0.0;
    final shown = _playing || _pos > Duration.zero
        ? _pos.inSeconds
        : widget.secs;
    return Container(
      constraints: const BoxConstraints(maxWidth: 260),
      padding: const EdgeInsets.fromLTRB(6, 6, 14, 6),
      margin: const EdgeInsets.only(top: 4, bottom: 4),
      decoration: BoxDecoration(
        color: NX.raised,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: NX.divider),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          InkWell(
            borderRadius: BorderRadius.circular(20),
            onTap: _toggle,
            child: Container(
              width: 40,
              height: 40,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                gradient: NX.gradient,
              ),
              child: Icon(
                _playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                color: Colors.white,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: value,
                minHeight: 5,
                backgroundColor: NX.divider,
                valueColor: const AlwaysStoppedAnimation(NX.accent2),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Text(fmtDur(shown),
              style: const TextStyle(color: NX.muted, fontSize: 12)),
        ],
      ),
    );
  }
}
