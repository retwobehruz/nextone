import 'l10n.dart';

const _monthsUz = [
  'yanvar', 'fevral', 'mart', 'aprel', 'may', 'iyun',
  'iyul', 'avgust', 'sentabr', 'oktabr', 'noyabr', 'dekabr',
];

const _monthsEn = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
];

const _monthsRu = [
  'января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
  'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря',
];

String two(int n) => n.toString().padLeft(2, '0');

String fmtTime(DateTime t) => '${two(t.hour)}:${two(t.minute)}';

String fmtDate(DateTime t) {
  final i = t.month - 1;
  switch (L10n.lang) {
    case 'uz':
      return '${t.day}-${_monthsUz[i]}, ${t.year}';
    case 'ru':
      return '${t.day} ${_monthsRu[i]} ${t.year}';
    default:
      return '${_monthsEn[i]} ${t.day}, ${t.year}';
  }
}

bool sameDay(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;

String fmtDay(DateTime t) {
  final now = DateTime.now();
  final today = DateTime(now.year, now.month, now.day);
  final d = DateTime(t.year, t.month, t.day);
  final diff = today.difference(d).inDays;
  if (diff == 0) return tr('Bugun');
  if (diff == 1) return tr('Kecha');
  return fmtDate(t);
}
