/// Supabase (onlayn baza) sozlamalari. Bu "anon" kalit ochiq bo'lishi uchun
/// mo'ljallangan: ma'lumotlarni himoya qiladigan narsa bazadagi RLS qoidalari.
const String kSupabaseUrl = 'https://wgufjdcopzeeskezrwup.supabase.co';
const String kSupabaseAnonKey =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndndWZqZGNvcHplZXNrZXpyd3VwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTUwNDkyNTMsImV4cCI6MjExMDYyNTI1M30.B2KMRSH02LNw_mLuoRw5f-HZPsCE7arh8Mgq142ncc8';

/// Google kirishdan keyin ilovaga qaytish manzili (AndroidManifest va Supabase'da bir xil bo'lishi shart).
const String kAuthRedirect = 'nextone://login-callback';
