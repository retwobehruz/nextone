import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart' show debugPrint;

/// Push bildirishnomalar. Firebase sozlanmagan bo'lsa jimgina o'tkazib yuboradi.
Future<void> initPush(Future<void> Function(String token) register) async {
  try {
    await Firebase.initializeApp();
    final fm = FirebaseMessaging.instance;
    await fm.requestPermission();
    final t = await fm.getToken();
    if (t != null) await register(t);
    fm.onTokenRefresh.listen((n) {
      register(n).catchError((e) => debugPrint('$e'));
    });
  } catch (e) {
    debugPrint('Push o\'chiq: $e');
  }
}
