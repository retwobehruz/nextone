import 'package:flutter/material.dart';

/// Nextone ranglari (Discord'ga o'xshash qorong'u tema).
class NX {
  NX._();

  static const rail = Color(0xFF0D0A1F);
  static const side = Color(0xFF15112B);
  static const main = Color(0xFF1B1636);
  static const raised = Color(0xFF2A2352);
  static const panel = Color(0xFF110D26);
  static const accent = Color(0xFF7C5CFF);
  static const green = Color(0xFF23A55A);
  static const red = Color(0xFFF23F43);
  static const gold = Color(0xFFF0B232);
  static const text = Color(0xFFF4F2FF);
  static const muted = Color(0xFFBDB6DD);
  static const dim = Color(0xFF8A82B3);
  static const divider = Color(0xFF302A5C);

  static const accent2 = Color(0xFF3FA9FF);
  static const gradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF8B5CFF), Color(0xFF3FA9FF)],
  );

  static const palette = <Color>[
    Color(0xFF5865F2),
    Color(0xFF3BA55D),
    Color(0xFFEB459E),
    Color(0xFFFAA61A),
    Color(0xFFED4245),
    Color(0xFF3B82F6),
    Color(0xFF9B59B6),
    Color(0xFF1ABC9C),
    Color(0xFFE67E22),
    Color(0xFF95A5A6),
  ];
}

ThemeData buildTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: NX.main,
    colorScheme: base.colorScheme.copyWith(
      primary: NX.accent,
      secondary: NX.accent,
      surface: NX.side,
    ),
    dividerColor: NX.divider,
    appBarTheme: const AppBarTheme(
      backgroundColor: NX.main,
      elevation: 0,
      scrolledUnderElevation: 0,
    ),
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: NX.side,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
    ),
    pageTransitionsTheme: const PageTransitionsTheme(builders: {
      TargetPlatform.android: ZoomPageTransitionsBuilder(),
    }),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: NX.rail,
      indicatorColor: NX.accent.withOpacity(0.28),
      labelTextStyle: const WidgetStatePropertyAll(
          TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
    ),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
  );
}
