import 'package:flutter/material.dart' hide Text;

import '../l10n.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/tr_text.dart';

/// Birinchi kirishda 4 ekranli tanishtiruv.
class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _page = PageController();
  final _code = TextEditingController();
  int _i = 0;
  bool _busy = false;

  static const _pages = [
    (Icons.waving_hand_rounded, 'Nextone\'ga xush kelibsiz!',
        "Do'stlar, jamoa va jamiyat uchun makon. Serverlar, kanallar va real vaqtdagi suhbatlar."),
    (Icons.dns_rounded, 'Serverlar va kanallar',
        "O'z serveringizni yarating yoki taklif kodi orqali boshqalarning serveriga qo'shiling. Rasmiy Nextone serveri sizni kutmoqda."),
    (Icons.person_search_rounded, "Do'stlarni toping",
        "@username orqali do'stlaringizni qidiring, ularga shaxsiy xabar yozing va do'stlik so'rovi yuboring."),
  ];

  @override
  void dispose() {
    _page.dispose();
    _code.dispose();
    super.dispose();
  }

  Future<void> _finish() async {
    final s = AppScope.read(context);
    setState(() => _busy = true);
    if (_code.text.trim().isNotEmpty && !s.referred) {
      final err = await s.claimReferral(_code.text);
      if (err != null && mounted) snack(context, err);
    }
    await s.finishOnboarding();
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final last = _i == _pages.length;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: _busy ? null : _finish,
                child: const Text("O'tkazib yuborish"),
              ),
            ),
            Expanded(
              child: PageView(
                controller: _page,
                onPageChanged: (v) => setState(() => _i = v),
                children: [
                  for (final p in _pages)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 32),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 120,
                            height: 120,
                            decoration: BoxDecoration(
                              gradient: NX.gradient,
                              borderRadius: BorderRadius.circular(34),
                            ),
                            child: Icon(p.$1, size: 60, color: Colors.white),
                          ),
                          const SizedBox(height: 32),
                          Text(p.$2,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                  fontSize: 26, fontWeight: FontWeight.w900)),
                          const SizedBox(height: 12),
                          Text(p.$3,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                  color: NX.muted, fontSize: 15, height: 1.4)),
                        ],
                      ),
                    ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 32),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.card_giftcard_rounded,
                            size: 72, color: NX.accent2),
                        const SizedBox(height: 24),
                        const Text("Do'stingiz taklif qildimi?",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 24, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 10),
                        const Text(
                          "Uning taklif kodini kiriting, do'stingiz bepul Plus oladi. Kod bo'lmasa, o'tkazib yuboring.",
                          textAlign: TextAlign.center,
                          style: TextStyle(color: NX.muted, height: 1.4),
                        ),
                        const SizedBox(height: 20),
                        TextField(
                          controller: _code,
                          textCapitalization: TextCapitalization.characters,
                          textAlign: TextAlign.center,
                          decoration: InputDecoration(
                            hintText: tr('Taklif kodi'),
                            border: const OutlineInputBorder(),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                for (var k = 0; k <= _pages.length; k++)
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    margin: const EdgeInsets.all(4),
                    width: k == _i ? 22 : 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: k == _i ? NX.accent : NX.divider,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: SizedBox(
                width: double.infinity,
                height: 50,
                child: FilledButton(
                  onPressed: _busy
                      ? null
                      : () {
                          if (last) {
                            _finish();
                          } else {
                            _page.nextPage(
                              duration: const Duration(milliseconds: 300),
                              curve: Curves.easeOut,
                            );
                          }
                        },
                  child: Text(last ? 'Boshlash' : 'Keyingi'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
