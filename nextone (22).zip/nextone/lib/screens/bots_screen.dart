import 'package:flutter/material.dart' hide Text;
import '../widgets/tr_text.dart';

import '../bots.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// Serverdagi botlarni boshqarish: o'rnatilganlar va katalog.
class BotsScreen extends StatelessWidget {
  const BotsScreen({super.key, required this.serverId});

  final String serverId;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final server = s.serverById(serverId);
    if (server == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Botlar')),
        body: const Center(child: Text('Server topilmadi')),
      );
    }
    final installed = [
      for (final b in botCatalog)
        if (server.memberRoles.containsKey(b.id)) b,
    ];
    final available = [
      for (final b in botCatalog)
        if (!server.memberRoles.containsKey(b.id)) b,
    ];

    return Scaffold(
      appBar: AppBar(title: Text(trf('Botlar · {name}', {'name': server.name}))),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 32),
        children: [
          const SectionLabel("O'RNATILGAN BOTLAR"),
          if (installed.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Text("Hozircha bot yo'q.", style: TextStyle(color: NX.dim)),
            ),
          for (final b in installed)
            _BotCard(
              bot: b,
              installed: true,
              onPressed: () => s.removeBot(server, b.id),
            ),
          const SectionLabel('BOTLAR KATALOGI'),
          if (available.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Text("Barcha botlar o'rnatilgan.", style: TextStyle(color: NX.dim)),
            ),
          for (final b in available)
            _BotCard(
              bot: b,
              installed: false,
              onPressed: () {
                s.addBot(server, b.id);
                snack(context, trf('{name} serverga qo\'shildi', {'name': b.name}));
              },
            ),
        ],
      ),
    );
  }
}

class _BotCard extends StatelessWidget {
  const _BotCard({
    required this.bot,
    required this.installed,
    required this.onPressed,
  });

  final BotInfo bot;
  final bool installed;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Card(
      color: NX.side,
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Avatar(member: bot.toMember(), size: 44),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            bot.name,
                            style: const TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 16,
                            ),
                          ),
                          const SizedBox(width: 6),
                          const BotTag(),
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        bot.description,
                        style: const TextStyle(color: NX.muted, fontSize: 13),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                for (final c in bot.commands)
                  Tooltip(
                    message: tr(c.description),
                    child: Chip(
                      visualDensity: VisualDensity.compact,
                      label: Text(
                        '/${c.name}${c.usage.isEmpty ? '' : ' ${tr(c.usage)}'}',
                        style: const TextStyle(fontSize: 12),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 10),
            Align(
              alignment: Alignment.centerRight,
              child: installed
                  ? OutlinedButton(
                      style: OutlinedButton.styleFrom(foregroundColor: NX.red),
                      onPressed: onPressed,
                      child: const Text("O'chirish"),
                    )
                  : FilledButton(
                      onPressed: onPressed,
                      child: const Text("Qo'shish"),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
