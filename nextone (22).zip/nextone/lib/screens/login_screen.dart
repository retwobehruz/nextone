import 'package:flutter/material.dart' hide Text;
import '../widgets/tr_text.dart';

import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF1F1B6B), NX.rail],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 380),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(28),
                      child: Image.asset('assets/icon.png', width: 110, height: 110),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'Nextone',
                      style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      "Do'stlar, jamoa va jamiyat uchun makon",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: NX.muted),
                    ),
                    const SizedBox(height: 28),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        style: FilledButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          backgroundColor: Colors.white,
                          foregroundColor: Colors.black87,
                        ),
                        onPressed: () => AppScope.read(context).signInWithGoogle(),
                        icon: const Icon(Icons.g_mobiledata_rounded, size: 34),
                        label: const Text('Google bilan kirish'),
                      ),
                    ),
                    if (AppScope.of(context).error != null) ...[
                      const SizedBox(height: 14),
                      Text(
                        AppScope.of(context).error!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: NX.red, fontSize: 12),
                      ),
                    ],
                    const SizedBox(height: 16),
                    const Text(
                      "Kirish uchun Google hisobingiz yetarli. Hamma narsa onlayn: haqiqiy odamlar bilan real vaqtda yozishasiz.",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: NX.dim, fontSize: 12),
                    ),
                    const SizedBox(height: 20),
                    const LanguagePicker(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
