import 'package:flutter/material.dart' hide Text;

import '../l10n.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/tr_text.dart';

/// Ommaviy serverlar katalogi.
class CatalogScreen extends StatefulWidget {
  const CatalogScreen({super.key});

  @override
  State<CatalogScreen> createState() => _CatalogScreenState();
}

class _CatalogScreenState extends State<CatalogScreen> {
  List<Map<String, dynamic>>? _rows;
  String? _joining;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final r = await AppScope.read(context).publicServers();
    if (mounted) setState(() => _rows = r);
  }

  Future<void> _join(Map<String, dynamic> r) async {
    final s = AppScope.read(context);
    setState(() => _joining = r['id'] as String);
    final err = await s.joinServer(r['invite_code'] as String);
    if (!mounted) return;
    setState(() => _joining = null);
    if (err != null) {
      snack(context, err);
    } else {
      Navigator.pop(context, true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final rows = _rows;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Serverlar katalogi'),
        actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))],
      ),
      body: rows == null
          ? const Center(child: CircularProgressIndicator())
          : rows.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(
                      "Hozircha ommaviy serverlar yo'q. O'z serveringizni Server sozlamalarida «Ommaviy server» qilib qo'ying.",
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: NX.dim),
                    ),
                  ),
                )
              : ListView(
                  padding: const EdgeInsets.all(12),
                  children: [
                    for (final r in rows)
                      Card(
                        color: NX.raised,
                        margin: const EdgeInsets.only(bottom: 10),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(
                            children: [
                              Container(
                                width: 52,
                                height: 52,
                                clipBehavior: Clip.antiAlias,
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                  color: Color(0xFF000000 |
                                      (((r['color'] as num?)?.toInt() ?? 0x5865F2) &
                                          0xFFFFFF)),
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: (r['icon_url'] != null &&
                                        (r['icon_url'] as String).isNotEmpty)
                                    ? Image.network(r['icon_url'] as String,
                                        width: 52, height: 52, fit: BoxFit.cover)
                                    : Text(
                                        initialsOf(r['name'] as String, single: 2),
                                        style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.w800)),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(r['name'] as String,
                                        style: const TextStyle(
                                            fontWeight: FontWeight.w800,
                                            fontSize: 16)),
                                    if ((r['description'] as String).isNotEmpty)
                                      Text(r['description'] as String,
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                              color: NX.muted, fontSize: 13)),
                                    Text(
                                        trf("{n} a'zo",
                                            {'n': '${r['members']}'}),
                                        style: const TextStyle(
                                            color: NX.dim, fontSize: 12)),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              s.servers.any((x) => x.id == r['id'])
                                  ? Text(tr("Qo'shilgansiz"),
                                      style: const TextStyle(color: NX.green))
                                  : FilledButton(
                                      onPressed: _joining != null
                                          ? null
                                          : () => _join(r),
                                      child: _joining == r['id']
                                          ? const SizedBox(
                                              width: 16,
                                              height: 16,
                                              child: CircularProgressIndicator(
                                                  strokeWidth: 2))
                                          : const Text("Qo'shilish"),
                                    ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
    );
  }
}
