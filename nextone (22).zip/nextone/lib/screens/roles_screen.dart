import 'package:flutter/material.dart' hide Text;
import '../widgets/tr_text.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// Server rollari: yaratish, tartiblash (tepadagisi yuqori), tahrirlash.
class RolesScreen extends StatelessWidget {
  const RolesScreen({super.key, required this.serverId});

  final String serverId;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final server = s.serverById(serverId);
    if (server == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Rollar')),
        body: const Center(child: Text('Server topilmadi')),
      );
    }
    final roles = server.roles.where((r) => r.id != 'everyone').toList();
    final everyone = server.everyone;

    int countOf(Role r) => server.memberRoles.values.where((x) => x.contains(r.id)).length;

    return Scaffold(
      appBar: AppBar(title: const Text('Rollar')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final name = await promptText(
            context,
            title: 'Yangi rol',
            hint: 'Rol nomi',
            action: 'Yaratish',
          );
          if (name == null || name.trim().isEmpty) return;
          final r = await s.createRole(server, name.trim());
          if (r == null || !context.mounted) return;
          Navigator.push(
            context,
            MaterialPageRoute<void>(
              builder: (_) => RoleEditor(serverId: server.id, roleId: r.id),
            ),
          );
        },
        icon: const Icon(Icons.add_rounded),
        label: const Text('Rol yaratish'),
      ),
      body: Column(
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Text(
              "Rollarni ushlab turib tartiblang: yuqoridagi rol yuqori hisoblanadi.",
              style: TextStyle(color: NX.dim, fontSize: 13),
            ),
          ),
          Expanded(
            child: ReorderableListView(
              padding: const EdgeInsets.only(bottom: 90),
              onReorder: (oldIndex, newIndex) {
                if (newIndex > oldIndex) newIndex -= 1;
                s.reorderRoles(server, oldIndex, newIndex);
              },
              children: [
                for (final r in roles)
                  ListTile(
                    key: ValueKey(r.id),
                    leading: CircleAvatar(backgroundColor: r.color, radius: 14),
                    title: Text(r.name),
                    subtitle: Text(
                      trf('{n} a\'zo · {p} ruxsat', {'n': countOf(r), 'p': r.permissions.length}) + (r.hoist ? tr(' · alohida ko\'rsatiladi') : ''),
                    ),
                    trailing: const Icon(Icons.drag_handle_rounded, color: NX.dim),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute<void>(
                        builder: (_) => RoleEditor(serverId: server.id, roleId: r.id),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const Divider(height: 1),
          ListTile(
            leading: CircleAvatar(backgroundColor: everyone.color, radius: 14),
            title: const Text('@everyone'),
            subtitle: Text(trf('Barcha a\'zolar uchun · {p} ruxsat', {'p': everyone.permissions.length})),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute<void>(
                builder: (_) => RoleEditor(serverId: server.id, roleId: everyone.id),
              ),
            ),
          ),
          const SizedBox(height: 70),
        ],
      ),
    );
  }
}

class RoleEditor extends StatefulWidget {
  const RoleEditor({super.key, required this.serverId, required this.roleId});

  final String serverId;
  final String roleId;

  @override
  State<RoleEditor> createState() => _RoleEditorState();
}

class _RoleEditorState extends State<RoleEditor> {
  late final TextEditingController _name;

  Role? _find(AppState s) {
    final sv = s.serverById(widget.serverId);
    if (sv == null) return null;
    for (final r in sv.roles) {
      if (r.id == widget.roleId) return r;
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: _find(AppScope.read(context))?.name ?? '');
  }

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final server = s.serverById(widget.serverId);
    final role = _find(s);
    if (server == null || role == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Rol')),
        body: const Center(child: Text('Rol topilmadi')),
      );
    }
    final isEveryone = role.id == 'everyone';

    return Scaffold(
      appBar: AppBar(title: Text(role.name)),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          if (!isEveryone) ...[
            TextField(
              controller: _name,
              decoration: InputDecoration(
                labelText: tr('Rol nomi'),
                border: OutlineInputBorder(),
              ),
              onChanged: (v) {
                if (v.trim().isEmpty) return;
                role.name = v.trim();
                s.saveRole(server, role);
              },
            ),
            const SectionLabel('RANG', padding: EdgeInsets.fromLTRB(0, 20, 0, 8)),
            ColorPicker(
              value: role.color,
              onChanged: (c) {
                role.color = c;
                s.saveRole(server, role);
              },
            ),
            const SizedBox(height: 8),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text("A'zolar ro'yxatida alohida ko'rsatish"),
              value: role.hoist,
              onChanged: (v) {
                role.hoist = v;
                s.saveRole(server, role);
              },
            ),
          ],
          const SectionLabel('RUXSATLAR', padding: EdgeInsets.fromLTRB(0, 16, 0, 4)),
          for (final p in Permission.values)
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(p.label),
              subtitle: p == Permission.admin
                  ? const Text("Barcha ruxsatlarni beradi. Ehtiyot bo'ling!")
                  : null,
              value: role.permissions.contains(p),
              onChanged: (v) {
                if (v) {
                  role.permissions.add(p);
                } else {
                  role.permissions.remove(p);
                }
                s.saveRole(server, role);
              },
            ),
          if (!isEveryone) ...[
            const SizedBox(height: 20),
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(foregroundColor: NX.red),
              onPressed: () async {
                final ok = await confirmDialog(
                  context,
                  title: "Rolni o'chirish",
                  body: trf('«{name}» roli barcha a\'zolardan olib tashlanadi.', {'name': role.name}),
                  action: "O'chirish",
                  danger: true,
                );
                if (!ok || !context.mounted) return;
                Navigator.pop(context);
                s.deleteRole(server, role);
              },
              icon: const Icon(Icons.delete_outline_rounded),
              label: const Text("Rolni o'chirish"),
            ),
          ],
        ],
      ),
    );
  }
}
