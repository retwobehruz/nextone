import 'package:flutter/material.dart' hide Text;

import '../l10n.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/member_pane.dart';
import '../widgets/tr_text.dart';
import 'referral_screen.dart';

/// Do'stlar: ro'yxat, so'rovlar va username bo'yicha qo'shish.
class FriendsScreen extends StatefulWidget {
  const FriendsScreen({super.key});

  @override
  State<FriendsScreen> createState() => _FriendsScreenState();
}

class _FriendsScreenState extends State<FriendsScreen> {
  final _q = TextEditingController();
  List<Member> _res = [];
  int _seq = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) AppScope.read(context).loadSocial();
    });
  }

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  Future<void> _search(String v) async {
    final id = ++_seq;
    if (v.trim().isEmpty) {
      setState(() => _res = []);
      return;
    }
    await Future.delayed(const Duration(milliseconds: 300));
    if (id != _seq || !mounted) return;
    final r = await AppScope.read(context).searchUsers(v);
    if (id != _seq || !mounted) return;
    setState(() => _res = r.where((m) => m.id != 'me').toList());
  }

  Widget _tile(BuildContext context, String key, {Widget? trailing}) {
    final s = AppScope.of(context);
    final m = s.member(key);
    return ListTile(
      leading: Avatar(member: m, size: 40, showStatus: true),
      title: Text(m.name),
      subtitle: m.username.isEmpty ? null : Text('@${m.username}'),
      trailing: trailing,
      onTap: () =>
          showMemberProfile(context, key, onDm: () => Navigator.pop(context)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final friends = s.friendKeys.toList()
      ..sort((a, b) => s.member(a).name.compareTo(s.member(b).name));
    final incoming = s.incomingReq.toList();
    final outgoing = s.outgoingReq.toList();

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Do'stlar"),
          actions: [
            IconButton(
              tooltip: tr("Do'stlarni taklif qilish"),
              icon: const Icon(Icons.card_giftcard_rounded, color: NX.accent2),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute<void>(builder: (_) => const ReferralScreen()),
              ),
            ),
          ],
          bottom: TabBar(
            tabs: [
              Tab(child: Text("Do'stlar")),
              Tab(
                child: Text(incoming.isEmpty
                    ? "So'rovlar"
                    : "${tr("So'rovlar")} (${incoming.length})"),
              ),
              Tab(child: Text("Qo'shish")),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            // Do'stlar
            friends.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(
                        "Hozircha do'stlar yo'q. «Qo'shish» bo'limida username bo'yicha qidiring yoki do'stlaringizni taklif qiling.",
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: NX.dim),
                      ),
                    ),
                  )
                : ListView(children: [
                    for (final k in friends) _tile(context, k),
                  ]),
            // So'rovlar
            ListView(children: [
              for (final k in incoming)
                _tile(
                  context,
                  k,
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.check_circle, color: NX.green),
                        onPressed: () => s.friendRespond(k, true),
                      ),
                      IconButton(
                        icon: const Icon(Icons.cancel, color: NX.red),
                        onPressed: () => s.friendRespond(k, false),
                      ),
                    ],
                  ),
                ),
              for (final k in outgoing)
                _tile(
                  context,
                  k,
                  trailing: Text(tr('Kutilmoqda'),
                      style: const TextStyle(color: NX.dim, fontSize: 12)),
                ),
              if (incoming.isEmpty && outgoing.isEmpty)
                Padding(
                  padding: const EdgeInsets.all(24),
                  child: Center(
                    child: Text("So'rovlar yo'q",
                        style: const TextStyle(color: NX.dim)),
                  ),
                ),
            ]),
            // Qo'shish
            ListView(
              children: [
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: TextField(
                    controller: _q,
                    autocorrect: false,
                    onChanged: _search,
                    decoration: InputDecoration(
                      hintText: tr("Username bo'yicha do'st qidirish"),
                      prefixIcon: const Icon(Icons.search),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                ),
                for (final m in _res)
                  _tile(
                    context,
                    m.id,
                    trailing: switch (s.friendStatus(m.id)) {
                      'friends' =>
                        const Icon(Icons.check_circle, color: NX.green),
                      'outgoing' => Text(tr('Kutilmoqda'),
                          style: const TextStyle(color: NX.dim, fontSize: 12)),
                      'incoming' => IconButton(
                          icon: const Icon(Icons.check_circle_outline),
                          onPressed: () => s.friendRespond(m.id, true),
                        ),
                      _ => IconButton(
                          icon: const Icon(Icons.person_add_alt_1_rounded,
                              color: NX.accent),
                          onPressed: () async {
                            final err = await s.friendRequest(m.id);
                            if (context.mounted) {
                              snack(context,
                                  err ?? tr("Do'stlik so'rovi yuborildi"));
                            }
                          },
                        ),
                    },
                  ),
                if (_q.text.trim().isNotEmpty && _res.isEmpty)
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(tr('Hech kim topilmadi'),
                        style: const TextStyle(color: NX.dim)),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
