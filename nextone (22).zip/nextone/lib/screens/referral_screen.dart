import 'package:flutter/material.dart' hide Text;
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../l10n.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/tr_text.dart';

const _apkUrl =
    'https://github.com/retwobehruz/nextone/releases/download/latest/Nextone.apk';

/// Do'stlarni taklif qilish: har bir do'st uchun 3 kun bepul Plus.
class ReferralScreen extends StatefulWidget {
  const ReferralScreen({super.key});

  @override
  State<ReferralScreen> createState() => _ReferralScreenState();
}

class _ReferralScreenState extends State<ReferralScreen> {
  final _code = TextEditingController();
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) AppScope.read(context).loadSocial();
    });
  }

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  String _shareText(String code) =>
      'Join me on Nextone, a new chat app for communities! '
      'Use my invite code $code when you sign up. '
      'Download: $_apkUrl  Channel: https://t.me/nextoneapp';

  Future<void> _claim() async {
    final s = AppScope.read(context);
    setState(() => _busy = true);
    final err = await s.claimReferral(_code.text);
    if (!mounted) return;
    setState(() => _busy = false);
    snack(context, err ?? tr("Kod qabul qilindi. Rahmat!"));
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final code = s.myRefCode;
    return Scaffold(
      appBar: AppBar(title: const Text("Do'stlarni taklif qilish")),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: NX.gradient,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              children: [
                const Icon(Icons.card_giftcard_rounded,
                    size: 44, color: Colors.white),
                const SizedBox(height: 8),
                const Text(
                  "Har bir taklif qilingan do'st uchun 3 kun bepul Nextone Plus!",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: Colors.white),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const SectionLabel('SIZNING TAKLIF KODINGIZ',
              padding: EdgeInsets.only(bottom: 8)),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 18),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: NX.raised,
              borderRadius: BorderRadius.circular(14),
            ),
            child: SelectableText(
              code.isEmpty ? '...' : code,
              style: const TextStyle(
                fontFamily: 'monospace',
                fontSize: 32,
                fontWeight: FontWeight.w900,
                letterSpacing: 4,
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: code.isEmpty
                      ? null
                      : () async {
                          await Clipboard.setData(
                              ClipboardData(text: _shareText(code)));
                          if (context.mounted) {
                            snack(context, tr('Taklif matni nusxalandi'));
                          }
                        },
                  icon: const Icon(Icons.copy_rounded),
                  label: const Text('Nusxalash'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton.icon(
                  onPressed: code.isEmpty
                      ? null
                      : () => launchUrl(
                            Uri.parse(
                                'https://t.me/share/url?url=${Uri.encodeComponent(_apkUrl)}&text=${Uri.encodeComponent(_shareText(code))}'),
                            mode: LaunchMode.externalApplication,
                          ),
                  icon: const Icon(Icons.send_rounded),
                  label: const Text('Telegram'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: NX.raised,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _stat('${s.referralCount}', tr("Taklif qilingan do'stlar")),
                _stat('${s.referralCount * 3}', tr('Ishlangan kunlar')),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            "Qanday ishlaydi: do'stingiz Nextone'ni yuklab, ro'yxatdan o'tadi va sizning kodingizni kiritadi. Shundan so'ng sizga darhol 3 kunlik Plus beriladi. Kod faqat yangi akkauntlar uchun amal qiladi.",
            style: TextStyle(color: NX.muted, height: 1.4),
          ),
          if (!s.referred) ...[
            const SizedBox(height: 24),
            const SectionLabel("DO'STINGIZNING KODI BORMI?",
                padding: EdgeInsets.only(bottom: 8)),
            TextField(
              controller: _code,
              textCapitalization: TextCapitalization.characters,
              decoration: InputDecoration(
                hintText: tr('Taklif kodi'),
                border: const OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: _busy ? null : _claim,
                child: const Text('Kodni qo\'llash'),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _stat(String n, String label) => Column(
        children: [
          Text(n,
              style:
                  const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          const SizedBox(height: 2),
          Text(label, style: const TextStyle(color: NX.dim, fontSize: 12)),
        ],
      );
}
