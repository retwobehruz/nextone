import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart' hide Text;
import 'package:url_launcher/url_launcher.dart';

import 'l10n.dart';
import 'theme.dart';
import 'widgets/tr_text.dart';

/// Joriy versiya raqami. CI qurishda `--dart-define=BUILD=<raqam>` beradi.
const int kBuild = int.fromEnvironment('BUILD', defaultValue: 0);

const String _releaseApi =
    'https://api.github.com/repos/retwobehruz/nextone/releases/tags/latest';
const String _fallbackApk =
    'https://github.com/retwobehruz/nextone/releases/download/latest/Nextone.apk';

class UpdateInfo {
  const UpdateInfo(this.build, this.url);
  final int build;
  final String url;
}

/// Yangi versiya bo'lsa to'ladi, aks holda null.
final ValueNotifier<UpdateInfo?> updateAvailable = ValueNotifier(null);

/// GitHub'dagi "latest" relizdan eng so'nggi build raqamini o'qiydi.
Future<void> checkForUpdate() async {
  if (kBuild == 0) return; // ishlab chiqish rejimida tekshirilmaydi
  final client = HttpClient();
  try {
    final req = await client.getUrl(Uri.parse(_releaseApi));
    req.headers.set('Accept', 'application/vnd.github+json');
    final res = await req.close().timeout(const Duration(seconds: 12));
    if (res.statusCode != 200) return;
    final body = await res.transform(utf8.decoder).join();
    final j = jsonDecode(body) as Map<String, dynamic>;
    final notes = (j['body'] as String?) ?? '';
    final m = RegExp(r'build (\d+)').firstMatch(notes);
    if (m == null) return;
    final latest = int.parse(m.group(1)!);
    if (latest <= kBuild) {
      updateAvailable.value = null;
      return;
    }
    var url = _fallbackApk;
    final assets = j['assets'];
    if (assets is List && assets.isNotEmpty) {
      final u = (assets.first as Map<String, dynamic>)['browser_download_url'];
      if (u is String && u.isNotEmpty) url = u;
    }
    updateAvailable.value = UpdateInfo(latest, url);
  } catch (_) {
    // tarmoq xatosi: keyingi safar qayta uriniladi
  } finally {
    client.close(force: true);
  }
}

/// Ekranning tepasida "Yangilash" chizig'i.
class UpdateBanner extends StatefulWidget {
  const UpdateBanner({super.key});

  @override
  State<UpdateBanner> createState() => _UpdateBannerState();
}

class _UpdateBannerState extends State<UpdateBanner> {
  bool _busy = false;
  String? _status;

  Future<void> _start(UpdateInfo info) async {
    setState(() {
      _busy = true;
      _status = tr('Yuklab olish boshlandi. Yuklangan faylni oching.');
    });
    try {
      final ok = await launchUrl(
        Uri.parse(info.url),
        mode: LaunchMode.externalApplication,
      );
      if (!ok && mounted) {
        setState(() => _status = trf('Yangilashda xato: {e}', {'e': 'launch'}));
      }
    } catch (e) {
      if (mounted) {
        setState(() => _status = trf('Yangilashda xato: {e}', {'e': '$e'}));
      }
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<UpdateInfo?>(
      valueListenable: updateAvailable,
      builder: (context, info, _) {
        if (info == null) return const SizedBox.shrink();
        return Material(
          color: NX.accent,
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              child: Row(
                children: [
                  const Icon(Icons.system_update_rounded, color: Colors.white),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      _status ?? 'Yangi versiya mavjud',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: NX.accent,
                    ),
                    onPressed: _busy ? null : () => _start(info),
                    child: const Text('Yangilash'),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
