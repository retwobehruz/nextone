import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:supabase_flutter/supabase_flutter.dart' as sb;

import 'l10n.dart';
import 'screens/home_shell.dart';
import 'screens/login_screen.dart';
import 'state.dart';
import 'supabase_config.dart';
import 'theme.dart';
import 'updater.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await sb.Supabase.initialize(url: kSupabaseUrl, anonKey: kSupabaseAnonKey);
  runApp(const NextoneApp());
  checkForUpdate();
  Timer.periodic(const Duration(minutes: 10), (_) => checkForUpdate());
}

class NextoneApp extends StatefulWidget {
  const NextoneApp({super.key});

  @override
  State<NextoneApp> createState() => _NextoneAppState();
}

class _NextoneAppState extends State<NextoneApp> {
  final AppState _state = AppState();

  @override
  void dispose() {
    _state.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: L10n.notifier,
      builder: (context, lang, _) => LangScope(
        lang: lang,
        child: AppScope(
          state: _state,
          child: MaterialApp(
            title: 'Nextone',
            debugShowCheckedModeBanner: false,
            theme: buildTheme(),
            locale: Locale(lang),
            supportedLocales: [for (final c in L10n.names.keys) Locale(c)],
            localizationsDelegates: const [
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            home: const _Root(),
          ),
        ),
      ),
    );
  }
}

class _Root extends StatelessWidget {
  const _Root();

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    if (s.loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final page = s.loggedIn ? const HomeShell() : const LoginScreen();
    return Column(
      children: [
        const UpdateBanner(),
        Expanded(child: page),
      ],
    );
  }
}
