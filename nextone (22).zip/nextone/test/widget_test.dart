import 'package:flutter_test/flutter_test.dart';
import 'package:nextone/l10n.dart';

void main() {
  test('Every language has the main strings', () {
    for (final table in L10n.tables.values) {
      expect(table.containsKey('Google bilan kirish'), isTrue);
      expect(table.containsKey('Bekor qilish'), isTrue);
    }
  });
}
