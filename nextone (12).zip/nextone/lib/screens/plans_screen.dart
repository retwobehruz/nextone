import 'package:flutter/material.dart' hide Text;
import 'package:flutter/services.dart';
import '../widgets/tr_text.dart';

import '../l10n.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// To'lov qabul qilinadigan karta (UzumBank).

class PlanInfo {
  const PlanInfo(this.id, this.title, this.price, this.color, this.perks);
  final String id;
  final String title;
  final int price;
  final Color color;
  final List<String> perks;
}

const List<PlanInfo> kPlans = [
  PlanInfo('plus', 'Nextone Plus', 6600, Color(0xFF5865F2), [
    'Profilda maxsus yulduzcha nishoni ⭐',
    "Xabar uzunligi: 2000 belgigacha (oddiy: 500)",
    'Chatda «PLUS» nishoni',
  ]),
  PlanInfo('prime', 'Nextone Prime', 12000, Color(0xFFF0B232), [
    'Plus dagi hamma narsa + yulduzcha nishoni ⭐',
    "Xabar uzunligi: 4000 belgigacha",
    "Chatda ismingiz oltin rangda ko'rinadi",
    'Chatda oltin «PRIME» nishoni',
    "Yangi imkoniyatlarni birinchi bo'lib olish",
  ]),
];

String _money(int n) {
  final s = n.toString();
  final b = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) b.write(' ');
    b.write(s[i]);
  }
  return b.toString();
}

class PlansScreen extends StatelessWidget {
  const PlansScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final cur = s.me.plan;
    return Scaffold(
      appBar: AppBar(title: const Text('Nextone obunalari')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (cur != 'free')
            Container(
              padding: const EdgeInsets.all(12),
              margin: const EdgeInsets.only(bottom: 14),
              decoration: BoxDecoration(
                color: NX.raised,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  PlanBadge(cur),
                  const SizedBox(width: 10),
                  const Expanded(child: Text('Sizda obuna faol. Rahmat!')),
                ],
              ),
            ),
          for (final p in kPlans) _PlanCard(plan: p, current: cur == p.id),
          const SizedBox(height: 8),
          const Text(
            "Obuna 30 kunga beriladi. To'lov tekshirilgach (odatda qisqa vaqt ichida) obuna avtomatik faollashadi.",
            style: TextStyle(color: NX.dim, fontSize: 12),
          ),
          if (s.me.isAdmin) ...[
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute<void>(builder: (_) => const AdminPaymentsScreen()),
              ),
              icon: const Icon(Icons.fact_check_outlined),
              label: const Text("To'lov so'rovlari (admin)"),
            ),
          ],
        ],
      ),
    );
  }
}

class _PlanCard extends StatelessWidget {
  const _PlanCard({required this.plan, required this.current});
  final PlanInfo plan;
  final bool current;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: NX.side,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: plan.color, width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.star_rounded, color: plan.color),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  plan.title,
                  style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20),
                ),
              ),
              Text(
                trf("{n} so'm", {'n': _money(plan.price)}),
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 16,
                  color: plan.color,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          for (final perk in plan.perks)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.check_rounded, size: 18, color: NX.green),
                  const SizedBox(width: 8),
                  Expanded(child: Text(perk)),
                ],
              ),
            ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              style: FilledButton.styleFrom(backgroundColor: plan.color),
              onPressed: () => _pay(context, plan),
              child: Text(current ? 'Muddatni uzaytirish' : 'Sotib olish'),
            ),
          ),
        ],
      ),
    );
  }
}

Future<void> _pay(BuildContext context, PlanInfo p) async {
  final s = AppScope.read(context);
  await s.loadPayInfo();
  if (!context.mounted) return;
  final name = TextEditingController(text: s.me.name);
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(p.title),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              trf("{n} so'm", {'n': _money(p.price)}),
              style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 22),
            ),
            const SizedBox(height: 10),
            const Text("UzumBank kartasiga aynan shu summani o'tkazing:"),
            const SizedBox(height: 8),
            SelectableText(
              s.cardNumber.isEmpty ? '...' : s.cardNumber,
              style: const TextStyle(
                fontFamily: 'monospace',
                fontWeight: FontWeight.w800,
                fontSize: 18,
              ),
            ),
            SelectableText(s.cardHolder),
            TextButton.icon(
              onPressed: () async {
                await Clipboard.setData(
                  ClipboardData(text: s.cardNumber.replaceAll(' ', '')),
                );
                if (ctx.mounted) snack(ctx, tr('Karta raqami nusxalandi'));
              },
              icon: const Icon(Icons.copy_rounded, size: 18),
              label: const Text('Karta raqamini nusxalash'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: name,
              decoration: InputDecoration(
                labelText: tr("Pul yuborgan karta egasining ismi"),
                border: const OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              "O'tkazib bo'lgach «To'lov qildim» ni bosing. To'lov tekshirilgach obuna faollashadi.",
              style: TextStyle(color: NX.dim, fontSize: 12),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: const Text('Bekor qilish'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: const Text("To'lov qildim"),
        ),
      ],
    ),
  );
  if (ok != true) return;
  final err = await s.requestPayment(p.id, name.text);
  if (!context.mounted) return;
  snack(
    context,
    err ?? tr("So'rov yuborildi. To'lov tekshirilgach obuna faollashadi."),
  );
}

/// Faqat admin uchun: to'lov so'rovlarini tasdiqlash.
class AdminPaymentsScreen extends StatefulWidget {
  const AdminPaymentsScreen({super.key});

  @override
  State<AdminPaymentsScreen> createState() => _AdminPaymentsScreenState();
}

class _AdminPaymentsScreenState extends State<AdminPaymentsScreen> {
  List<Map<String, dynamic>>? _rows;
  String? _err;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await AppScope.read(context).pendingRequests();
      if (mounted) setState(() => _rows = r);
    } catch (e) {
      if (mounted) setState(() => _err = e.toString());
    }
  }

  Future<void> _review(String id, bool approve) async {
    final err = await AppScope.read(context).reviewPayment(id, approve);
    if (!mounted) return;
    if (err != null) snack(context, err);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final rows = _rows;
    return Scaffold(
      appBar: AppBar(
        title: const Text("To'lov so'rovlari"),
        actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))],
      ),
      body: _err != null
          ? Center(child: Text(_err!))
          : rows == null
              ? const Center(child: CircularProgressIndicator())
              : rows.isEmpty
                  ? const Center(child: Text("Kutilayotgan so'rov yo'q"))
                  : ListView(
                      children: [
                        for (final r in rows)
                          ListTile(
                            title: Text(
                              '${(r['profiles'] is Map ? r['profiles']['display_name'] : '?')} · ${r['plan']} · ${_money((r['amount'] as num).toInt())}',
                            ),
                            subtitle: Text(
                              '${r['payer_name']} · ${DateTime.parse(r['created_at'] as String).toLocal().toString().substring(0, 16)}',
                            ),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.check_circle, color: NX.green),
                                  onPressed: () => _review(r['id'] as String, true),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.cancel, color: NX.red),
                                  onPressed: () => _review(r['id'] as String, false),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
    );
  }
}
