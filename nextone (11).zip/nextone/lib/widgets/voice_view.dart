import 'package:flutter/material.dart' hide Text;
import 'tr_text.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import 'common.dart';

/// Ovozli kanal ekrani. Hozircha interfeys (haqiqiy ovoz keyingi bosqichda).
class VoiceView extends StatelessWidget {
  const VoiceView({super.key, required this.channel});

  final Channel channel;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final connected = s.voiceChannelId == channel.id;
    final ids = (s.voice[channel.id] ?? <String>{}).toList();

    return Column(
      children: [
        Expanded(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: ids.isEmpty
                  ? const Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.volume_up_rounded, size: 56, color: NX.dim),
                        SizedBox(height: 12),
                        Text(
                          "Hozircha hech kim yo'q",
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          "Birinchi bo'lib qo'shiling!",
                          style: TextStyle(color: NX.muted),
                        ),
                      ],
                    )
                  : Wrap(
                      alignment: WrapAlignment.center,
                      spacing: 12,
                      runSpacing: 12,
                      children: [
                        for (final id in ids)
                          _ParticipantTile(
                            member: s.member(id),
                            muted: id == 'me' && (s.micMuted || s.deafened),
                            deafened: id == 'me' && s.deafened,
                          ),
                      ],
                    ),
            ),
          ),
        ),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          decoration: const BoxDecoration(
            color: NX.panel,
            border: Border(top: BorderSide(color: NX.divider)),
          ),
          child: SafeArea(
            top: false,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (!connected)
                  FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: NX.green,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 28,
                        vertical: 14,
                      ),
                    ),
                    onPressed: () => s.joinVoice(channel.id),
                    icon: const Icon(Icons.call_rounded),
                    label: const Text("Qo'shilish"),
                  )
                else
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _RoundButton(
                        icon: s.micMuted ? Icons.mic_off_rounded : Icons.mic_rounded,
                        active: s.micMuted,
                        tooltip: tr('Mikrofon'),
                        onTap: s.toggleMic,
                      ),
                      _RoundButton(
                        icon: s.deafened
                            ? Icons.headset_off_rounded
                            : Icons.headset_rounded,
                        active: s.deafened,
                        tooltip: tr('Quloqchin'),
                        onTap: s.toggleDeafen,
                      ),
                      _RoundButton(
                        icon: s.camera
                            ? Icons.videocam_rounded
                            : Icons.videocam_off_rounded,
                        active: !s.camera,
                        tooltip: tr('Kamera'),
                        onTap: s.toggleCamera,
                      ),
                      _RoundButton(
                        icon: Icons.screen_share_rounded,
                        tooltip: tr('Ekranni ulashish'),
                        onTap: () =>
                            snack(context, 'Ekranni ulashish keyingi bosqichda'),
                      ),
                      _RoundButton(
                        icon: Icons.call_end_rounded,
                        tooltip: tr('Uzilish'),
                        filled: NX.red,
                        onTap: s.leaveVoice,
                      ),
                    ],
                  ),
                const SizedBox(height: 10),
                const Text(
                  "Haqiqiy ovoz va video keyingi bosqichda (LiveKit / WebRTC) ulanadi.",
                  textAlign: TextAlign.center,
                  style: TextStyle(color: NX.dim, fontSize: 12),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _ParticipantTile extends StatelessWidget {
  const _ParticipantTile({
    required this.member,
    required this.muted,
    required this.deafened,
  });

  final Member member;
  final bool muted;
  final bool deafened;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 150,
      height: 120,
      decoration: BoxDecoration(
        color: NX.raised,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: NX.divider),
      ),
      child: Stack(
        children: [
          Center(child: Avatar(member: member, size: 64)),
          Positioned(
            left: 10,
            bottom: 8,
            right: 30,
            child: Text(
              member.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
            ),
          ),
          if (muted || deafened)
            Positioned(
              right: 8,
              bottom: 8,
              child: Icon(
                deafened ? Icons.headset_off_rounded : Icons.mic_off_rounded,
                size: 16,
                color: NX.red,
              ),
            ),
        ],
      ),
    );
  }
}

class _RoundButton extends StatelessWidget {
  const _RoundButton({
    required this.icon,
    required this.onTap,
    required this.tooltip,
    this.active = false,
    this.filled,
  });

  final IconData icon;
  final VoidCallback onTap;
  final String tooltip;
  final bool active;
  final Color? filled;

  @override
  Widget build(BuildContext context) {
    final bg = filled ?? (active ? Colors.white : NX.raised);
    final fg = filled != null
        ? Colors.white
        : (active ? NX.rail : NX.text);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6),
      child: Tooltip(
        message: tooltip,
        child: Material(
          color: bg,
          shape: const CircleBorder(),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: onTap,
            child: SizedBox(
              width: 48,
              height: 48,
              child: Icon(icon, color: fg),
            ),
          ),
        ),
      ),
    );
  }
}
